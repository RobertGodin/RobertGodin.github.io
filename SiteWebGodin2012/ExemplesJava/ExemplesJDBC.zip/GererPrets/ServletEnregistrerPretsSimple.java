package ExemplesJDBC.GererPrets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class ServletEnregistrerPretsSimple extends HttpServlet {

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    //Chercher le param�tre idUtilisateur de la FORM HTML et cr�er un Utilisateur
    String idUtilisateur = "";
    try { idUtilisateur = request.getParameter("idUtilisateur"); }
    catch (Exception e) { e.printStackTrace(); }
    Utilisateur unUtilisateur = new Utilisateur(idUtilisateur);
    
    //Chercher le param�tre idExemplaire de la FORM HTML et cr�er un Exemplaire
    String idExemplaire = "";
    try { idExemplaire = request.getParameter("idExemplaire"); }
    catch (Exception e) { e.printStackTrace(); }
    Exemplaire unExemplaire = new Exemplaire(idExemplaire);

    // Ent�te de la page de r�ponse HTML
    response.setContentType("text/html");
    OutputStreamWriter unOutputStreamWriter =
      new OutputStreamWriter(response.getOutputStream());
    PrintWriter out = new PrintWriter(unOutputStreamWriter);
    out.println("<html>");
    out.println("<head><title>R�ponse de ServletEnregistrerPrets</title></head>");
    out.println("<body>");

    UsineConnection uneUsineConnection = new UsineConnection();
    Connection uneConnection = null;
    try{
      // Ouvrir une Connection (mode autocommit)
      uneConnection = uneUsineConnection.getConnection(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:ora817i",
            "clerat","oracle");


      // G�n�rer la date du jour et l'objet Pr�tEnCours
      Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
      java.sql.Date dateMaintenant = new java.sql.Date(maintenant.getTime().getTime());
      Pr�tEnCours leNouveauPr�tEnCours =
        new Pr�tEnCours(unUtilisateur,dateMaintenant,unExemplaire);

      // Mat�rialiser le Pr�tEnCours dans la BD

      CourtierBDPr�tEnCours unCourtierBDPr�tEnCours =
          new CourtierBDPr�tEnCours(uneConnection);
      unCourtierBDPr�tEnCours.ins�rerPr�tEnCours(leNouveauPr�tEnCours);

      // Message de confirmation du pr�t
      out.println("Pr�t de l'exemplaire " + idExemplaire +
        " � l'utilisateur " + idUtilisateur + " confirm�.<br>Date :" + dateMaintenant);
    }
    catch(Exception lException){
      out.println(lException.getMessage());
      lException.printStackTrace();
    }
    finally{
      try{
        // Fin de la page HTML
        out.println("</body></html>");
        out.close();
        // Pas besoin de commit
        uneConnection.close();
      }
      catch(Exception lException){
        lException.printStackTrace();
      }
    }
  }
}
