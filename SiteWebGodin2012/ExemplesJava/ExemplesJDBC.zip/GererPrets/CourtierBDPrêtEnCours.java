package ExemplesJDBC.GererPrets;
import java.sql.*;
import java.util.*;

public class CourtierBDPr�tEnCours {
    private Connection uneConnection;
   
    // Constructeur pour connexion pass�e par le cr�ateur
    public CourtierBDPr�tEnCours(Connection laConnection){
        this.uneConnection = laConnection;
    }
    
    public void setConnection(Connection laConnection){
        this.uneConnection = laConnection;
    }

    public void chercherLesPr�tsEnCoursEtExemplaires(Utilisateur unUtilisateur)
    // D�mat�rialiser les Pr�tEnCours d'un Utilisateur ainsi que les Exemplaires correspondants 
    throws Exception{
       // Verrouiller la table des pr�ts en cours pour s�rialisabilit� 
        // (Oracle mode READ COMMITTED)
        PreparedStatement unEnonc�Lock = uneConnection.prepareStatement(
            "LOCK TABLE Pr�tEnCours IN SHARE ROW EXCLUSIVE MODE");
        unEnonc�Lock.execute();
        unEnonc�Lock.close();
        PreparedStatement unEnonc�SQL = uneConnection.prepareStatement
        ("SELECT datePr�t,p.idExemplaire,statut "+
        "FROM Pr�tEnCours p, Exemplaire e WHERE p.idUtilisateur = ? AND p.idExemplaire = e.idExemplaire" );
        String idUtilisateur = unUtilisateur.getIdUtilisateur();
        unEnonc�SQL.setString(1,idUtilisateur);
        ResultSet r�sultatSelect = unEnonc�SQL.executeQuery();
        Vector lesPr�ts = new Vector();
        while (r�sultatSelect.next ()){
            Exemplaire lExemplaire = 
                new Exemplaire(r�sultatSelect.getString(2),r�sultatSelect.getString(3));
            Pr�tEnCours unPr�t = new Pr�tEnCours(unUtilisateur,r�sultatSelect.getDate(1),lExemplaire);
            lesPr�ts.addElement(unPr�t);
        }
        unUtilisateur.setLesPr�ts(lesPr�ts);
        unEnonc�SQL.close();
    }
    public void ins�rerPr�tEnCours (Pr�tEnCours unPr�tEnCours)
    // Mat�rialise un nouveau Pr�tEnCours dans la BD
        throws Exception, SQLException {
        PreparedStatement unEnonc�SQL = uneConnection.prepareStatement
        ("INSERT INTO Pr�tEnCours(idExemplaire,idUtilisateur)"+
        "VALUES(?,?)");
        unEnonc�SQL.setString(1,unPr�tEnCours.getIdExemplaire());
        unEnonc�SQL.setString(2,unPr�tEnCours.getIdUtilisateur());
        //NB la date est g�n�r�e automatiquement par le serveur de BD (default sysdate)
        // et le statut est modifi� par un TRIGGER
        int n = unEnonc�SQL.executeUpdate();
        unEnonc�SQL.close();
        if (n != 1){throw new Exception("Insertion dans Pr�tEnCours a �chou�");}
    }
}