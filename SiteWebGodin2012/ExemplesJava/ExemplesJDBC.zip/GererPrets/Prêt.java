package ExemplesJDBC.GererPrets;
import java.sql.Date;
public class Pr�t {
    protected Utilisateur lUtilisateur;
    protected java.sql.Date datePr�t;
    protected Exemplaire lExemplaire;

    public Pr�t(Utilisateur lUtilisateur,java.sql.Date datePr�t, Exemplaire lExemplaire) {
        this.lUtilisateur = lUtilisateur;
        this.datePr�t = datePr�t;
        this.lExemplaire = lExemplaire;
    }
    public java.sql.Date getDatePr�t(){return datePr�t;}
    public String getIdExemplaire(){return lExemplaire.getIdExemplaire();}
    public String getIdUtilisateur(){return lUtilisateur.getIdUtilisateur();}
}