package ExemplesJDBC.GererPrets;
import java.sql.*;
public class UsineConnection {
    public UsineConnection() {}
    public Connection getConnectionSansAutoCommit(
        String nomPilote,   // "oracle.jdbc.driver.OracleDriver" pour Oracle
        String URLBD,       // exemple : "jdbc:oracle:thin:@localhost:1521:ora817i"
        String authorizationID,
        String password)
        throws Exception {
            Class.forName (nomPilote);
            Connection uneConnection = DriverManager.getConnection (URLBD, authorizationID,password);
            uneConnection.setAutoCommit(false);
            return uneConnection;
    }
    public Connection getConnection(
        String nomPilote,   // "oracle.jdbc.driver.OracleDriver" pour Oracle
        String URLBD,       // exemple : "jdbc:oracle:thin:@localhost:1521:ora817i"
        String authorizationID,
        String password)
        throws Exception {
            Class.forName (nomPilote);
            Connection uneConnection = DriverManager.getConnection (URLBD, authorizationID,password);
            return uneConnection;
    }
}