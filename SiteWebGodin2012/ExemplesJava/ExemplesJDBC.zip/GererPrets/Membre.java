package ExemplesJDBC.GererPrets;
import java.util.*;
public class Membre extends Utilisateur {
    private static int nbMaxPr�ts;
    private static int dur�eMaxPr�t;

    private String t�l�phoneR�sidence;

    public Membre(String idUtilisateur, String motPasse, String nom,
        String pr�nom, String cat�gorie, String t�l�phoneR�sidence){
        super(idUtilisateur, motPasse, nom, pr�nom, cat�gorie);
        this.t�l�phoneR�sidence = t�l�phoneR�sidence;
    }

    public static int getNbMaxPr�ts(){return nbMaxPr�ts;}
    public static int getDur�eMaxPr�t(){return dur�eMaxPr�t;}
    public static void setNbMaxPr�ts(int leNbMaxPr�ts){nbMaxPr�ts = leNbMaxPr�ts;}
    public static void setDur�eMaxPr�ts(int laDur�eMaxPr�t){dur�eMaxPr�t = laDur�eMaxPr�t;}

    public void setT�l�phoneR�sidence(String t�l�phoneR�sidence)
        {this.t�l�phoneR�sidence = t�l�phoneR�sidence;}
    public String getT�l�phoneR�sidence(){return t�l�phoneR�sidence;}
    public int getNbRetards(){
        Enumeration enumerationPr�ts = lesPr�ts.elements();
        int nbRetards = 0;
        Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
        // Soustrait ensuite la dur�e maximale en jours pour obtenir la date minimale 
        // avant laquelle il y a un retard
        maintenant.add(Calendar.DATE,-dur�eMaxPr�t); 
        java.sql.Date dateMinSansRetard = new java.sql.Date(maintenant.getTime().getTime());
        while (enumerationPr�ts.hasMoreElements()){
            Pr�t unPr�t = (Pr�t)enumerationPr�ts.nextElement();
            if (unPr�t instanceof Pr�tEnCours){
                if (dateMinSansRetard.after(unPr�t.getDatePr�t())){
                    nbRetards++;
                }
            }
        }
        return nbRetards;
    }
    public boolean conditionsPr�tAccept�es(){
        return (this.getNbRetards() == 0 && this.getNbPr�tsEnCours() < nbMaxPr�ts);
    }
}