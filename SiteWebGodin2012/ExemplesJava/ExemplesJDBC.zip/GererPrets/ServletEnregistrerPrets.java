package ExemplesJDBC.GererPrets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class ServletEnregistrerPrets extends HttpServlet {

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    //Chercher le param�tre idUtilisateur de la FORM HTML
    String idUtilisateur = "";
    try { idUtilisateur = request.getParameter("idUtilisateur"); }
    catch (Exception e) { e.printStackTrace(); }
    //Chercher le param�tre idExemplaire de la FORM HTML
    String idExemplaire = "";
    try { idExemplaire = request.getParameter("idExemplaire"); }
    catch (Exception e) { e.printStackTrace(); }

    // Ent�te de la page de r�ponse HTML
    response.setContentType("text/html");
    OutputStreamWriter unOutputStreamWriter = new OutputStreamWriter(response.getOutputStream());
    PrintWriter out = new PrintWriter(unOutputStreamWriter);
    out.println("<html>");
    out.println("<head><title>R�ponse de ServletEnregistrerPrets</title></head>");
    out.println("<body>");

    UsineConnection uneUsineConnection = new UsineConnection();
    Connection uneConnection = null;
    try{
      // Ouvrir une Connection
      uneConnection = uneUsineConnection.getConnectionSansAutoCommit(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:ora817i",
            "clerat","oracle");
      // D�mat�rialiser l'Utilisateur et ses Pr�tsEnCours
      Membre unMembre = null;

      // Cr�ation du courtier et d�mat�rialisation de l'Utilisateur
      CourtierBDUtilisateur unCourtierBDUtilisateur =
        new CourtierBDUtilisateur(uneConnection);
      Utilisateur unUtilisateur = unCourtierBDUtilisateur.chercherUtilisateurParIdUtilisateur(idUtilisateur);

      //Cr�ation du courtier et d�mat�rialisation des Pr�tsEnCours
      CourtierBDPr�tEnCours unCourtierBDPr�tEnCours =
        new CourtierBDPr�tEnCours(uneConnection);
      unCourtierBDPr�tEnCours.chercherLesPr�tsEnCoursEtExemplaires(unUtilisateur);

      // Affichage de l'idUtilisateur et du nombre de pr�ts
      out.println("Utilisateur :" + idUtilisateur);
      out.println(" Nombre de pr�ts en cours :" + unUtilisateur.getNbPr�tsEnCours()+"<br>");

      // V�rifier si les conditions pr�alables sont viol�es
      boolean conditionsAccept�es = false;
      if (unUtilisateur instanceof Membre){
        unCourtierBDUtilisateur.chercherVariablesStatiquesDeMembre();
        unMembre = (Membre)unUtilisateur;
        if (!unMembre.conditionsPr�tAccept�es()){
          out.println("Pr�t refus�.<br>Nb de pr�ts :" + unMembre.getNbPr�tsEnCours()+
                ". Maximum :" + Membre.getNbMaxPr�ts() +
                ". Nb de retards :" + unMembre.getNbRetards());
        }else {conditionsAccept�es = true;}
      }else{conditionsAccept�es = true;}// Pas de contrainte pour un employ�
      if(conditionsAccept�es){
        // V�rifier statut de l'exemplaire
        CourtierBDExemplaire unCourtierBDExemplaire =
          new CourtierBDExemplaire(uneConnection);
        Exemplaire unExemplaire = unCourtierBDExemplaire.chercherExemplaireParIdExemplaire(idExemplaire);
        if (unExemplaire.getStatut().equals("disponible")){

          // G�n�rer la date du jour et l'objet Pr�tEnCours
          Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
          java.sql.Date dateMaintenant = new java.sql.Date(maintenant.getTime().getTime());
          Pr�tEnCours leNouveauPr�tEnCours = new Pr�tEnCours(unUtilisateur,dateMaintenant,unExemplaire);

          // Mat�rialiser le Pr�tEnCours dans la BD
          unCourtierBDPr�tEnCours.ins�rerPr�tEnCours(leNouveauPr�tEnCours);

          // Message de confirmation du pr�t
          out.println("Pr�t de l'exemplaire " + idExemplaire +
                " � l'utilisateur " + idUtilisateur + " confirm�.<br>Date :" + dateMaintenant);
        }else{
          // Message indiquant que l'exemplaire n'est pas disponible pour le pr�t
          out.println("Exemplaire non disponible:"+idExemplaire);
        }
      }
    }
    catch(Exception lException){
      out.println(lException.getMessage());
      lException.printStackTrace();
    }
    finally{
      try{
        out.println("</body></html>");
        out.close();
        uneConnection.commit();
        uneConnection.close();
      }
      catch(Exception lException){
      lException.printStackTrace();
      }
    }
  }
}
