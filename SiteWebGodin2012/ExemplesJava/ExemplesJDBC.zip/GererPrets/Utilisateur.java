package ExemplesJDBC.GererPrets;
import java.util.*;
public class Utilisateur extends Personne {
    protected String idUtilisateur;
    protected String motPasse;
    protected String cat�gorie;
    protected Vector lesPr�ts; // Association avec Pr�t

    // Constructeurs pour Utilisateur
    public Utilisateur(String idUtilisateur){
        this.idUtilisateur = idUtilisateur;
    }
    public Utilisateur(String idUtilisateur, String motPasse, String nom,
        String pr�nom, String cat�gorie){
        super(nom,pr�nom);
        this.idUtilisateur = idUtilisateur;
        this.motPasse = motPasse;
        this.cat�gorie =  cat�gorie;
    }
    
    public String getIdUtilisateur(){return idUtilisateur;}
    public String getMotPasse(){return motPasse;}
    public String getCat�gorie(){return cat�gorie;}
    public Vector getLesPr�ts(){return lesPr�ts;}
    public int getNbPr�tsEnCours(){
        Enumeration enumerationPr�ts = lesPr�ts.elements();
        int nbPr�tsEnCours = 0;
        while (enumerationPr�ts.hasMoreElements()){
            Pr�t unPr�t = (Pr�t)enumerationPr�ts.nextElement();
            if (unPr�t instanceof Pr�tEnCours){
                nbPr�tsEnCours++;
            }
        }
        return nbPr�tsEnCours;
    }
    
    public void setIdUtilisateur(String idUtilisateur){this.idUtilisateur = idUtilisateur;}
    public void setMotPasse(String motPasse){this.motPasse = motPasse;}
    public void setCat�gorie(String cat�gorie){this.cat�gorie = cat�gorie;}
    public void setLesPr�ts(Vector lesPr�ts){this.lesPr�ts = lesPr�ts;}
}