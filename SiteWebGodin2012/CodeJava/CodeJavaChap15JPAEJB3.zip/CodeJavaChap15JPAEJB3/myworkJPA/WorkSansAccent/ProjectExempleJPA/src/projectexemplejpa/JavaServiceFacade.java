package projectexemplejpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JavaServiceFacade {
    private EntityManagerFactory emf = Persistence.createEntityManagerFactory("ProjectExempleJPA-1");

    public JavaServiceFacade() {
    }

    public static void main(String [] args) {
        final JavaServiceFacade javaServiceFacade = new JavaServiceFacade();
        //  TODO:  Call methods on javaServiceFacade here...
    }

    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public Object mergeEntity(Object entity) {
        final EntityManager em = getEntityManager();
        try {
            final EntityTransaction et = em.getTransaction();
            try {
                et.begin();
                em.merge(entity);
                et.commit();
            } finally {
                if (et != null && et.isActive()) {
                    entity = null;
                    et.rollback();
                }
            }
        } finally {
            if (em != null && em.isOpen()) {
                em.close();
            }
        }
        return entity;
    }

    public Object persistEntity(Object entity) {
        final EntityManager em = getEntityManager();
        try {
            final EntityTransaction et = em.getTransaction();
            try {
                et.begin();
                em.persist(entity);
                et.commit();
            } finally {
                if (et != null && et.isActive()) {
                    entity = null;
                    et.rollback();
                }
            }
        } finally {
            if (em != null && em.isOpen()) {
                em.close();
            }
        }
        return entity;
    }

    /** <code>select o from Editeur o</code> */
    public List<Editeur> queryEditeurFindAll() {
        return getEntityManager().createNamedQuery("Editeur.findAll").getResultList();
    }

    public void removeEditeur(Editeur editeur) {
        final EntityManager em = getEntityManager();
        try {
            final EntityTransaction et = em.getTransaction();
            try {
                et.begin();
                editeur = em.find(Editeur.class, editeur.getNomEditeur());
                et.commit();
            } finally {
                if (et != null && et.isActive()) {
                    et.rollback();
                }
            }
        } finally {
            if (em != null && em.isOpen()) {
                em.close();
            }
        }
    }

    /** <code>select o from Livre o</code> */
    public List<Livre> queryLivreFindAll() {
        return getEntityManager().createNamedQuery("Livre.findAll").getResultList();
    }

    public void removeLivre(Livre livre) {
        final EntityManager em = getEntityManager();
        try {
            final EntityTransaction et = em.getTransaction();
            try {
                et.begin();
                livre = em.find(Livre.class, livre.getIsbn());
                et.commit();
            } finally {
                if (et != null && et.isActive()) {
                    et.rollback();
                }
            }
        } finally {
            if (em != null && em.isOpen()) {
                em.close();
            }
        }
    }
}
