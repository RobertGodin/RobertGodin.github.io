package projectexemplejpa;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class ExempleEntiteDetache {

        public static void main(String[] args) {
        
            EntityManagerFactory unEMF = Persistence.createEntityManagerFactory("ProjectExempleJPA-1");
            
            System.out.println("Session 1");           
            EntityManager unEM = unEMF.createEntityManager();
            EntityTransaction uneET = unEM.getTransaction();
            
            System.out.println("Transaction 1 : cr�er l'�diteur Presses XYZ");
            uneET.begin();
            Editeur e1 = new Editeur();
            e1.setNomEditeur("Presses XYZ");
            e1.setVille("Une ville");
            unEM.persist(e1); // unEditeur devient g�r�
            uneET.commit();
            unEM.close(); // Contexte de persistance et EntityManager sont supprim�s, l'�diteur devient d�tach�
            System.out.println("Fin session 1 : e1 est d�tach�");
           
            System.out.println("Nom de l'�diteur d�tach� e1:"+e1.getNomEditeur());
            e1.setVille("Une autre ville"); // Modification sur objet d�tach�
            
            System.out.println("Session 2");
            unEM = unEMF.createEntityManager();
            uneET = unEM.getTransaction();
            
            // Chercher l'entit� qui est mat�rialis�
            System.out.println("Transaction 2: chercher l'�diteur tel que mat�rialis�");
            uneET.begin();                
            Editeur lEditeurMaterialise = unEM.find(Editeur.class,"Presses XYZ");
            System.out.println("Nom de l'�diteur mat�rialis�:"+lEditeurMaterialise.getNomEditeur());
            System.out.println("Ville de l'�diteur:"+lEditeurMaterialise.getVille());
            System.out.println("Ville de l'�diteur e1:"+e1.getVille());
            System.out.println("Ville de l'�diteur mat�rialis�:"+lEditeurMaterialise.getVille());
            uneET.commit();
            
            
            System.out.println("Transaction 3: merge int�gre la modification de l'objet d�tach� e1 dans la nouvelle entit� g�r�e e2");
            uneET.begin();
            Editeur e2 = unEM.merge(e1); // e2 devient g�r� et int�gre les modifs sur e1
            uneET.commit();
            
            System.out.println("Transaction 4: chercher l'�diteur tel que mat�rialis�");
            uneET.begin();
            lEditeurMaterialise = unEM.find(Editeur.class,"Presses XYZ");
            System.out.println("Nom de l'�diteur:"+lEditeurMaterialise.getNomEditeur());
            System.out.println("Ville de l'�diteur:"+lEditeurMaterialise.getVille());
            unEM.remove(lEditeurMaterialise);
            uneET.commit();
            unEM.close();
            
        }
    }
