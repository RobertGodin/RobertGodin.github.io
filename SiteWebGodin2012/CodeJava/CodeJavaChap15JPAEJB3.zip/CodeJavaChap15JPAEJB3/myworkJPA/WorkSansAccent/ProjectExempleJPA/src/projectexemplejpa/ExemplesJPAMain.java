package projectexemplejpa;

import java.util.ArrayList;
import java.util.Collection;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class ExemplesJPAMain {

    public static void main(String[] args) {
    
        EntityManagerFactory unEMF = Persistence.createEntityManagerFactory("ProjectExempleJPA-1");
        EntityManager unEM = unEMF.createEntityManager();
        EntityTransaction uneET = unEM.getTransaction();
        
        System.out.println("Transaction 1: Cr�er un �diteur avec deux livres associ�s");
        uneET.begin();
        Editeur unEditeur = new Editeur();
        unEditeur.setNomEditeur("Loze-Dion");
        unEditeur.setVille("Longueuil");
        unEditeur.setLivreCollection(new ArrayList());
        
        Livre unPremierLivre = new Livre();
        unPremierLivre.setIsbn("2-921180-89-8");
        unPremierLivre.setTitre("Syst�mes de gestion de bases de donn�es");
        unPremierLivre.setAnneeParution(new Long(2006));
        unPremierLivre.setCode("101");
        
        // Il faut maintenir les liens bidirectionnels dans l'application de mani�re explicite
        unPremierLivre.setEditeur(unEditeur);
        unEditeur.getLivreCollection().add(unPremierLivre);
        
        Livre unDeuxiemeLivre = new Livre();
        unDeuxiemeLivre.setIsbn("2-921180-70-7");
        unDeuxiemeLivre.setTitre("Programmation des r�seaux sous UNIX");
        unDeuxiemeLivre.setAnneeParution(new Long(2000));
        unDeuxiemeLivre.setCode("101");
        
        unDeuxiemeLivre.setEditeur(unEditeur);
        unEditeur.getLivreCollection().add(unDeuxiemeLivre);
        
        // Les livres deviennent persistants par r�f�rence (cascade = ALL)
        unEM.persist(unEditeur);
        uneET.commit();
                
        System.out.println("Transaction 2: rechercher l'�diteur et ses livres");
        uneET.begin();
        
        Editeur e = unEM.find(Editeur.class,"Loze-Dion");
        System.out.println("Nom de l'�diteur:"+e.getNomEditeur());
        System.out.println("Ville de l'�diteur:"+e.getVille());
        
        assert (unEditeur == e);
        
        Collection<Livre> lesLivres = e.getLivreCollection();
        if (lesLivres == null || lesLivres.size() != 2) {
          throw new RuntimeException("Nombre de livres non conforme: "
                  + ((lesLivres == null)? "null" : "" + lesLivres.size()));
        }
        for (Livre l : lesLivres) { 
           System.out.println(l.getIsbn()); 
           System.out.println(l.getTitre()); 
        }
        uneET.commit();
        
        System.out.println("Transaction 3: rechercher un autre �diteur et ses livres");
        uneET.begin();
        
        e = unEM.find(Editeur.class,"Addison Wesley");
        System.out.println("Nom de l'�diteur:"+e.getNomEditeur());
        System.out.println("Ville de l'�diteur:"+e.getVille());
        
        
        lesLivres = e.getLivreCollection();
        for (Livre l : lesLivres) { 
           System.out.println(l.getIsbn()); 
           System.out.println(l.getTitre()); 
        }
        uneET.commit();
        
        
        System.out.println("Transaction 4: rechercher l'�diteur et ses livres avec Query");
        uneET.begin();
        Query q = unEM.createQuery("SELECT e FROM Editeur e WHERE e.nomEditeur = :unNomEditeur");
            q.setParameter("unNomEditeur", "Loze-Dion");
            
        e = (Editeur)q.getSingleResult();
        System.out.println("Nom de l'�diteur:"+e.getNomEditeur());
        System.out.println("Ville de l'�diteur:"+e.getVille());
        
        lesLivres = e.getLivreCollection();
        for (Livre l : lesLivres) { 
           System.out.println(l.getIsbn()); 
           System.out.println(l.getTitre()); 
        }
        uneET.commit();    

        System.out.println("Transaction 5: ex�cution de la NamedQuery Livre.findAll");
        uneET.begin();
        List<Livre> listeDesLivres;
        listeDesLivres = unEM.createNamedQuery("Livre.findAll").getResultList();
        System.out.println("Liste des livres:"); 
        for (Livre l : listeDesLivres) { 
            System.out.println(l.getIsbn()); 
            System.out.println(l.getTitre());
            System.out.println(l.getAnneeParution());
            System.out.println(l.getCode());
            // Navigation de l'association !
            System.out.println(l.getEditeur().getNomEditeur());
        }  
        uneET.commit();
        
        uneET.begin();
        System.out.println("Transaction 6: modifier l'ann�e de parution d'un livre");
        Query q2 = unEM.createQuery("SELECT leLivre FROM Livre leLivre WHERE leLivre.isbn = :unIsbn");
            q2.setParameter("unIsbn", "2-921180-70-7");
        Livre l = (Livre)q2.getSingleResult();
        l.setAnneeParution(new Long(2003));
        uneET.commit();

        uneET.begin();
        System.out.println("Transaction 7: supprimer l'�diteur et ses livres en cascade");
        Query q3 = unEM.createQuery("SELECT e FROM Editeur e WHERE e.nomEditeur = 'Loze-Dion'");            
        e = (Editeur)q3.getSingleResult();
        unEM.remove(e); // Les livres sont supprim�s en cascade
        uneET.commit();
        
        unEM.close();
    }
}
