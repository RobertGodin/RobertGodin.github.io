package projectexemplejpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name = "Livre.findAll", query = "select o from Livre o")
public class Livre implements Serializable {
    @Column(nullable = false)
    private Long anneeParution;
    @Column(nullable = false)
    private String code;
    @Id
    @Column(nullable = false)
    private String isbn;
    @Column(nullable = false)
    private String titre;
    @ManyToOne
    @JoinColumn(name = "NOMEDITEUR", referencedColumnName = "NOMEDITEUR")
    private Editeur editeur;

    public Livre() {
    }

    public Long getAnneeParution() {
        return anneeParution;
    }
    public void setAnneeParution(Long anneeParution) {
        this.anneeParution = anneeParution;
    }
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public String getIsbn() {
        return isbn;
    }
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
    public String getTitre() {
        return titre;
    }
    public void setTitre(String titre) {
        this.titre = titre;
    }
    public Editeur getEditeur() {
        return editeur;
    }
    public void setEditeur(Editeur editeur) {
        this.editeur = editeur;
    }
}
