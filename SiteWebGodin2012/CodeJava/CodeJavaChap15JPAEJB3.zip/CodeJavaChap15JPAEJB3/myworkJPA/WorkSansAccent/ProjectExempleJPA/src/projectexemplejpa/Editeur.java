package projectexemplejpa;

import java.io.Serializable;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

@Entity
@NamedQuery(name = "Editeur.findAll", query = "select o from Editeur o")
public class Editeur implements Serializable {
    @Id
    @Column(nullable = false)
    private String nomEditeur;
    
    @Column(nullable = false)
    private String ville;
    
    @OneToMany(cascade=CascadeType.ALL, mappedBy ="editeur")
    private Collection<Livre> livreCollection;

    public Editeur() {
    }
    public String getNomEditeur() {
        return nomEditeur;
    }
    public void setNomEditeur(String nomEditeur) {
        this.nomEditeur = nomEditeur;
    }
    public String getVille() {
        return ville;
    }
    public void setVille(String ville) {
        this.ville = ville;
    }
    public Collection<Livre> getLivreCollection() {
        return livreCollection;
    }
    public void setLivreCollection(Collection<Livre> livreCollection) {
        this.livreCollection = livreCollection;
    }
}
