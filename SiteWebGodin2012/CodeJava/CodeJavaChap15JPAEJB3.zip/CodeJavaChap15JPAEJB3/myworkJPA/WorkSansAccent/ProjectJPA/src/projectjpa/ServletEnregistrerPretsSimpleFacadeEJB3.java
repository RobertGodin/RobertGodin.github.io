package projectjpa;

import java.io.IOException;
import java.io.PrintWriter;

import javax.ejb.EJB;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.OutputStreamWriter;
import javax.naming.Context;
import javax.naming.InitialContext;


public class ServletEnregistrerPretsSimpleFacadeEJB3 extends HttpServlet {
        public void init(ServletConfig config) throws ServletException {
            super.init(config);
        }
        public void doPost(HttpServletRequest request, 
                           HttpServletResponse response) throws ServletException, 
                                                                IOException {
            String idUtilisateur = "";
            try { idUtilisateur = request.getParameter("idUtilisateur"); }
            catch (Exception e) { e.printStackTrace(); }
            
            //Chercher le param�tre idExemplaire de la FORM HTML et creer un Exemplaire
            String idExemplaire = "";
            try { idExemplaire = request.getParameter("idExemplaire"); }
            catch (Exception e) { e.printStackTrace(); }

            // Entete de la page de reponse HTML
            response.setContentType("text/html");
            OutputStreamWriter unOutputStreamWriter =
              new OutputStreamWriter(response.getOutputStream());
            PrintWriter out = new PrintWriter(unOutputStreamWriter);
            out.println("<html>");
            out.println("<head><title>Reponse de ServletEnregistrerPretsSimpleFacadeEJB3</title></head>");
            out.println("<body>");

            try {
                // Recherche de la fa�ade session EJB3 sans passer par l'usine � objet
                final Context context = new InitialContext();
                EnregistrerPretSimpleJPASessionEJB enregistrerPretSimpleJPASessionEJB = (EnregistrerPretSimpleJPASessionEJB)context.lookup("EnregistrerPretSimpleJPASessionEJB");

                // Appel de m�thode sur la fa�ade EJB3
                java.sql.Timestamp datePret =   enregistrerPretSimpleJPASessionEJB.insererPretEnCours(  idUtilisateur,  idExemplaire );
                out.println("Pret de l'exemplaire " + idExemplaire +
                  " � l'utilisateur " + idUtilisateur + " confirme.<br>Date :" + datePret);
                  
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            finally{
              try{
                // Fin de la page HTML
                out.println("</body></html>");
                out.close();
              }
              catch(Exception lException){
                lException.printStackTrace();
              }
            }
        }
    }

