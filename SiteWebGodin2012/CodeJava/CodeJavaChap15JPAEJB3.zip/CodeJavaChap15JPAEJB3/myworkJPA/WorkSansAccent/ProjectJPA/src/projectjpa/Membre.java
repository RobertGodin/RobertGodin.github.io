package projectjpa;

import java.io.Serializable;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

@Entity
@DiscriminatorValue("membre")
@NamedQuery(name = "Membre.findAll", query = "select o from Membre o")
public class Membre extends Utilisateur implements Serializable {
    private static int nbMaxPrets;
    private static int dureeMaxPret;

    @Column(nullable = false)
    private String telephoneresidence;

    public Membre() {
    }

    public static int getNbMaxPrets(){return nbMaxPrets;}
    public static int getDureeMaxPret(){return dureeMaxPret;}
    public static void setNbMaxPrets(int leNbMaxPrets){nbMaxPrets = leNbMaxPrets;}
    public static void setDureeMaxPrets(int laDureeMaxPret){dureeMaxPret = laDureeMaxPret;}



    public String getTelephoneresidence() {
        return telephoneresidence;
    }

    public void setTelephoneresidence(String telephoneresidence) {
        this.telephoneresidence = telephoneresidence;
    }


    public int getNbRetards(){
        int nbRetards = 0;
        Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
        // Soustrait ensuite la duree maximale en jours pour obtenir la date minimale 
        // avant laquelle il y a un retard
        maintenant.add(Calendar.DATE,-dureeMaxPret); 
        java.sql.Date dateMinSansRetard = new java.sql.Date(maintenant.getTime().getTime());

        for (PretEnCours p :this.getPretEnCoursSet() ) {
                if (dateMinSansRetard.after(p.getDatepret())){
                    nbRetards++;
                }
                else {}
        }  
        return nbRetards;
    }
    public boolean conditionsPretAcceptees(){
        return (this.getNbRetards() == 0 && this.getNbPretsEnCours() < nbMaxPrets);
    }

}
