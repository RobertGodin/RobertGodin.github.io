package projectjpa;

import java.sql.*;
import java.util.*;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.LockModeType;
import javax.persistence.Persistence;

// Fa�ade pour le cas d'utilisation EnregistrerPrets
// Isole la classe de contr�le des details de la gestion de persistence effectu�e avec JPA
// NB Les methodes de la fa�ade doivent etre appelees en sequence
public class FacadeEnregistrerPretsJPA 
{
  private EntityManagerFactory emf = Persistence.createEntityManagerFactory("ProjectJPA-1");
  private EntityManager em = emf.createEntityManager();
  private EntityTransaction et = em.getTransaction(); 
  private Utilisateur unUtilisateur;
  private Exemplaire unExemplaire;
  
  public FacadeEnregistrerPretsJPA() throws Exception{}
  // Cherche un Utilisateur avec ses PretsEnCours et retourne
  // les donnees necessaires pour EnregistrerPrets (OTDUtilisateurPrets)
  // Une exception est levee si l'Utilisateur n'existe pas
  public OTDUtilisateurPrets chercherOTDUtilisateurPrets(String idUtilisateur)throws Exception {
  
    et.begin(); // D�but explicite de transaction avec JPA
    unUtilisateur = em.find(Utilisateur.class, idUtilisateur);
//    em.lock(unUtilisateur,LockModeType.READ);
 

    // Retourner l'objet de transfert de donnees OTDUtilisateurPrets
    if (unUtilisateur instanceof Membre){
        Membregeneral unMembregeneral;                
        unMembregeneral = em.find(Membregeneral.class,new Long(1));
        Membre.setDureeMaxPrets((int)unMembregeneral.getDureemaxprets());
        Membre.setNbMaxPrets((int)unMembregeneral.getNbmaxprets()); 
        Membre unMembre = (Membre)unUtilisateur;
        return new OTDUtilisateurPrets(
                      unMembre.conditionsPretAcceptees(),
                      unMembre.getNbPretsEnCours(),
                      Membre.getNbMaxPrets(),
                      unMembre.getNbRetards());
    } else {
      return new OTDUtilisateurPrets(
        true,unUtilisateur.getNbPretsEnCours(),0,0);
    }
  }

  public String getStatutExemplaire(String idExemplaire)throws Exception{
    // Chercher l'exemplaire en passant par le courtier et retourner le statut
    
    unExemplaire = em.find(Exemplaire.class,idExemplaire);
    return unExemplaire.getStatut();
  }

  // Insere le pret et retourne la date d'enregistrement
  // NB Suppose que unUtilisateur et unExemplaire ont ete dematerialises
  public Timestamp insererPretEnCours() throws Exception{
    Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
    Timestamp dateMaintenant = new Timestamp(maintenant.getTime().getTime());
    PretEnCours leNouveauPretEnCours = new PretEnCours();
    leNouveauPretEnCours.setUtilisateur(unUtilisateur);
    leNouveauPretEnCours.setDatepret((Timestamp)dateMaintenant);
    leNouveauPretEnCours.setExemplaire(unExemplaire);

    // Materialiser le PretEnCours dans la BD
    em.persist(leNouveauPretEnCours);
    return dateMaintenant;
  }

  // Confirmer la transaction et fermer la Connection
  public void confirmerTransaction()throws Exception{
    et.commit();
  }
}

