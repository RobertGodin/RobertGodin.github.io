package projectjpa;

import java.io.Serializable;
public class OTDUtilisateurPrets implements Serializable
{
  private boolean conditionsPretAcceptees;
  private int nbPretsEnCours;
  private int nbMaxPrets;
  private int nbRetards;
  public OTDUtilisateurPrets() {}
  public OTDUtilisateurPrets(boolean conditionsPretAcceptees,
   int nbPretsEnCours, int nbMaxPrets, int nbRetards) {
    this.conditionsPretAcceptees=conditionsPretAcceptees;
    this.nbPretsEnCours=nbPretsEnCours;
    this.nbMaxPrets=nbMaxPrets;
    this.nbRetards=nbRetards;
   }
   public boolean conditionsPretAcceptees(){return conditionsPretAcceptees;}
   public int getNbPretsEnCours(){return nbPretsEnCours;}
   public int getNbMaxPrets(){return nbMaxPrets;}
   public int getNbRetards(){return nbRetards;}
}