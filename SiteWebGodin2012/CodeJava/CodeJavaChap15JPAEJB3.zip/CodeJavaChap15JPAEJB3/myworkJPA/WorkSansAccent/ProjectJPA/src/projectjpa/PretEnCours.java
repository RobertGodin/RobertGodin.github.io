package projectjpa;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;


@Entity
@NamedQuery(name = "PretEnCours.findAll", 
    query = "select o from PretEnCours o")
public class PretEnCours implements Serializable {
    @Column(nullable = false)
    private Timestamp datepret;
    @Id
    @Column(nullable = false, insertable = false, updatable = false)
    private String idexemplaire;
    @ManyToOne
    @JoinColumn(name = "IDUTILISATEUR", referencedColumnName = "IDUTILISATEUR")
    private Utilisateur utilisateur;
    @OneToOne
    @JoinColumn(name = "IDEXEMPLAIRE", referencedColumnName = "IDEXEMPLAIRE")
    private Exemplaire exemplaire;

    public PretEnCours() {
    }

    public Timestamp getDatepret() {
        return datepret;
    }

    public void setDatepret(Timestamp datepret) {
        this.datepret = datepret;
    }

    public String getIdexemplaire() {
        return idexemplaire;
    }

    public void setIdexemplaire(String idexemplaire) {
        this.idexemplaire = idexemplaire;
    }


    public Utilisateur getUtilisateur() {
        return utilisateur;
    }

    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }

    public Exemplaire getExemplaire() {
        return exemplaire;
    }

    public void setExemplaire(Exemplaire exemplaire) {
        this.exemplaire = exemplaire;
    }

}
