package projectjpa;

import java.sql.Timestamp;

import java.util.List;

import javax.ejb.Local;


@Local
public interface EnregistrerPretSimpleJPASessionEJBLocal {
    Timestamp insererPretEnCours(String idUtilisateur, String idExemplaire);
}
