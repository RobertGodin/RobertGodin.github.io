package projectjpa;

import java.io.Serializable;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
@Inheritance(strategy=InheritanceType.JOINED)
@DiscriminatorColumn(name="categorieutilisateur")
@NamedQuery(name = "Utilisateur.findAll", 
    query = "select o from Utilisateur o")
public class Utilisateur extends Personne implements Serializable {
//    @Column(nullable = false)
//    private String categorieutilisateur;
    @Id
    @Column(nullable = false)
    private String idutilisateur;
    @Column(nullable = false)
    private String motpasse;
    @OneToMany(mappedBy = "utilisateur")
    private Set<PretEnCours> pretEnCoursSet;

    public Utilisateur() {
    }

/*    public String getCategorieutilisateur() {
        return categorieutilisateur;
    }

    public void setCategorieutilisateur(String categorieutilisateur) {
        this.categorieutilisateur = categorieutilisateur;
    }
*/
    public String getIdutilisateur() {
        return idutilisateur;
    }

    public void setIdutilisateur(String idutilisateur) {
        this.idutilisateur = idutilisateur;
    }

    public String getMotpasse() {
        return motpasse;
    }

    public void setMotpasse(String motpasse) {
        this.motpasse = motpasse;
    }

    public Set<PretEnCours> getPretEnCoursSet() {
        return pretEnCoursSet;
    }

    public void setPretEnCoursSet(Set<PretEnCours> pretEnCoursSet) {
        this.pretEnCoursSet = pretEnCoursSet;
    }

    public PretEnCours addPretEnCours(PretEnCours pretEnCours) {
        getPretEnCoursSet().add(pretEnCours);
        pretEnCours.setUtilisateur(this);
        return pretEnCours;
    }

    public PretEnCours removePretEnCours(PretEnCours pretEnCours) {
        getPretEnCoursSet().remove(pretEnCours);
        pretEnCours.setUtilisateur(null);
        return pretEnCours;
    }

    public int getNbPretsEnCours(){
        return this.getPretEnCoursSet().size();
    }

}
