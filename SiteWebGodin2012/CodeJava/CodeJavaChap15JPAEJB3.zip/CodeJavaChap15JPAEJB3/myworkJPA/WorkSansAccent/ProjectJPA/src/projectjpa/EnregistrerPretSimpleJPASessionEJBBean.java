package projectjpa;

import java.sql.Timestamp;

import java.util.Calendar;
import java.util.List;

import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless(name="EnregistrerPretSimpleJPASessionEJB")
public class EnregistrerPretSimpleJPASessionEJBBean implements EnregistrerPretSimpleJPASessionEJB, 
                                                               EnregistrerPretSimpleJPASessionEJBLocal {
    @PersistenceContext(unitName="ProjectJPA-2")
    private EntityManager em;
    private Utilisateur unUtilisateur;
    private Exemplaire unExemplaire;

    public EnregistrerPretSimpleJPASessionEJBBean() {
    }

    public Timestamp insererPretEnCours(String idUtilisateur, String idExemplaire){
        unUtilisateur = em.find(Utilisateur.class, idUtilisateur);
        unExemplaire = em.find(Exemplaire.class,idExemplaire);
        Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
        Timestamp dateMaintenant = new Timestamp(maintenant.getTime().getTime());
        PretEnCours leNouveauPretEnCours = new PretEnCours();
        leNouveauPretEnCours.setUtilisateur(unUtilisateur);
        leNouveauPretEnCours.setDatepret((Timestamp)dateMaintenant);
        leNouveauPretEnCours.setExemplaire(unExemplaire);

        // Materialiser le PretEnCours dans la BD
        em.persist(leNouveauPretEnCours);
        return dateMaintenant;

    }
}
