package projectjpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name = "Membregeneral.findAll", 
    query = "select o from Membregeneral o")
public class Membregeneral implements Serializable {
    @Column(nullable = false)
    private Long dureemaxprets;
    @Column(nullable = false)
    private Long nbmaxprets;
    @Id
    @Column(nullable = false)
    private Long nosequence;

    public Membregeneral() {
    }

    public Long getDureemaxprets() {
        return dureemaxprets;
    }

    public void setDureemaxprets(Long dureemaxprets) {
        this.dureemaxprets = dureemaxprets;
    }

    public Long getNbmaxprets() {
        return nbmaxprets;
    }

    public void setNbmaxprets(Long nbmaxprets) {
        this.nbmaxprets = nbmaxprets;
    }

    public Long getNosequence() {
        return nosequence;
    }

    public void setNosequence(Long nosequence) {
        this.nosequence = nosequence;
    }
}
