package projectjpa;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

@Entity
@NamedQuery(name = "Exemplaire.findAll", query = "select o from Exemplaire o")
public class Exemplaire implements Serializable {
    @Column(nullable = false)
    private Timestamp dateachat;
    @Id
    @Column(nullable = false)
    private String idexemplaire;
    @Column(nullable = false)
    private String statut;
    @ManyToOne
    @JoinColumn(name = "ISBN", referencedColumnName = "ISBN")
    private Livre livre;
    @OneToOne(mappedBy = "exemplaire")
    private PretEnCours pretEnCours;

    public Exemplaire() {
    }

    public Timestamp getDateachat() {
        return dateachat;
    }

    public void setDateachat(Timestamp dateachat) {
        this.dateachat = dateachat;
    }

    public String getIdexemplaire() {
        return idexemplaire;
    }

    public void setIdexemplaire(String idexemplaire) {
        this.idexemplaire = idexemplaire;
    }


    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public Livre getLivre() {
        return livre;
    }

    public void setLivre(Livre livre) {
        this.livre = livre;
    }

    public PretEnCours getPretEnCours() {
        return pretEnCours;
    }

    public void setPretEnCours(PretEnCours pretEnCours) {
        this.pretEnCours = pretEnCours;
    }
}
