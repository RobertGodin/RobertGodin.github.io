package projectjpa;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class EnregistrerPretSimpleJPASessionEJBClient {
    public static void main(String [] args) {
        try {
            final Context context = getInitialContext();
            EnregistrerPretSimpleJPASessionEJB enregistrerPretSimpleJPASessionEJB = (EnregistrerPretSimpleJPASessionEJB)context.lookup("EnregistrerPretSimpleJPASessionEJB");
            // Call any of the Remote methods below to access the EJB
            // enregistrerPretSimpleJPASessionEJB.mergeEntity(  entity );
            // enregistrerPretSimpleJPASessionEJB.persistEntity(  entity );
            // System.out.println( enregistrerPretSimpleJPASessionEJB.queryUtilisateurFindAll(  ) );
            // enregistrerPretSimpleJPASessionEJB.removeUtilisateur(  utilisateur );
            // System.out.println( enregistrerPretSimpleJPASessionEJB.queryEmployeFindAll(  ) );
            // enregistrerPretSimpleJPASessionEJB.removeEmploye(  employe );
            // enregistrerPretSimpleJPASessionEJB.insererPretEnCours(  idUtilisateur,  idExemplaire );
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static Context getInitialContext() throws NamingException {
        // Get InitialContext for Embedded OC4J
        // The embedded server must be running for lookups to succeed.
        return new InitialContext();
    }
}
