package projectjpa;

import java.io.Serializable;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

@Entity
@NamedQuery(name = "Livre.findAll", query = "select o from Livre o")
public class Livre implements Serializable {
    @Column(nullable = false)
    private Long anneeparution;
    @Column(nullable = false)
    private String code;
    @Id
    @Column(nullable = false)
    private String isbn;
    @Column(nullable = false)
    private String nomediteur;
    @Column(nullable = false)
    private String titre;
    @OneToMany(mappedBy = "livre")
    private Set<Exemplaire> exemplaireSet;

    public Livre() {
    }

    public Long getAnneeparution() {
        return anneeparution;
    }

    public void setAnneeparution(Long anneeparution) {
        this.anneeparution = anneeparution;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getNomediteur() {
        return nomediteur;
    }

    public void setNomediteur(String nomediteur) {
        this.nomediteur = nomediteur;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public Set<Exemplaire> getExemplaireSet() {
        return exemplaireSet;
    }

    public void setExemplaireSet(Set<Exemplaire> exemplaireSet) {
        this.exemplaireSet = exemplaireSet;
    }

    public Exemplaire addExemplaire(Exemplaire exemplaire) {
        getExemplaireSet().add(exemplaire);
        exemplaire.setLivre(this);
        return exemplaire;
    }

    public Exemplaire removeExemplaire(Exemplaire exemplaire) {
        getExemplaireSet().remove(exemplaire);
        exemplaire.setLivre(null);
        return exemplaire;
    }
}
