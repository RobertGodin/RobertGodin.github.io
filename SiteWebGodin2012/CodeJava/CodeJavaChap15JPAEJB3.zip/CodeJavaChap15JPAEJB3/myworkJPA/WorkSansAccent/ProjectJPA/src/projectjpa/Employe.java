package projectjpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

@Entity
@DiscriminatorValue("employe")
@NamedQuery(name = "Employe.findAll", query = "select o from Employe o")
public class Employe extends Utilisateur implements Serializable {
    @Column(nullable = false)
    private String codematricule;

    public Employe() {
    }

    public String getCodematricule() {
        return codematricule;
    }

    public void setCodematricule(String codematricule) {
        this.codematricule = codematricule;
    }

}
