
package ExemplesJDBC;
import java.sql.*;
import java.util.*;

public class TestDateComm 
{
  public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    // Connexion � une BD
    Connection uneConnection =
      DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:orcl", "godin", "oracle");

      PreparedStatement unEnonc�SQL = uneConnection.prepareStatement
        ("INSERT INTO Commande(noCommande,dateCommande,noClient) VALUES(?,?,?)");
        unEnonc�SQL.setInt(1,230);
        Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
        java.sql.Date dateMaintenant = 
          new java.sql.Date(maintenant.getTime().getTime());
        unEnonc�SQL.setDate(2,dateMaintenant);
        unEnonc�SQL.setInt(3,10);
//        int n = unEnonc�SQL.executeUpdate();

    unEnonc�SQL = uneConnection.prepareStatement
        ("SELECT noCommande,dateCommande,noClient FROM Commande" );
    ResultSet r�sultatSelect = unEnonc�SQL.executeQuery();
    while (r�sultatSelect.next ()){
        int lenoCommande = r�sultatSelect.getInt("noCommande");
        java.sql.Date laDate = r�sultatSelect.getDate("dateCommande");
        int lenoClient = r�sultatSelect.getInt("noClient");
        
        System.out.println ("noCommande:" + lenoCommande);
        System.out.println ("dateCommande:" + laDate);
        System.out.println("laDate convertie:"+(java.util.Date)laDate);
        System.out.println ("noClient:" + lenoClient);
    }
    // Fermeture de l'�nonc� et de la connexion
    unEnonc�SQL.close();
    uneConnection.close();
  }
}
