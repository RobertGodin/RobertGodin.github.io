package ExemplesJDBC;
import java.sql.*;
import java.util.*;
import java.math.*;

public class TestSum 
{
  public static void main (String args [])
       throws Exception, SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    // Connexion � une BD
    Connection uneConnection =
      DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:orcl", "godin", "oracle");

        BigDecimal montant;

        PreparedStatement unEnonc�SQL = uneConnection.prepareStatement
        ("SELECT 	NVL(SUM(quantit�Livr�e*prixUnitaire),0) AS totalLivraison "+
        "FROM 		D�tailLivraison D, Article A WHERE D.noArticle = A.noArticle "+
        "AND noLivraison = 100 ");
      
        ResultSet r�sultatSelect = unEnonc�SQL.executeQuery();
        if (r�sultatSelect.next()){
            montant = r�sultatSelect.getBigDecimal(1);
            System.out.println("Montant :" + montant);
        }else{
            throw new Exception("SELECT incorrect");
        }

    // Fermeture de l'�nonc� et de la connexion
    unEnonc�SQL.close();
    uneConnection.close();
  }
}
