// Utilisation de java.sql.Timestamp avec le type DATE Oracle (contient date+heure)

package ExemplesJDBC;
import java.sql.*;
import java.util.*;

public class ExempleDateTime 
{
  public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    // Connexion � une BD
    Connection uneConnection =
      DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:orcl", "godin", "oracle");

      PreparedStatement unEnonc�SQL = uneConnection.prepareStatement
        ("INSERT INTO Commande(noCommande,dateCommande,noClient) VALUES(?,?,?)");
        unEnonc�SQL.setInt(1,500);
        Calendar maintenant = Calendar.getInstance(); // cr�e un calendrier gr�gorien avec date actuelle
        // Conversion en un java.sql.Timestamp pour utilisation avec JDBC
        java.sql.Timestamp dateMaintenant = 
          new java.sql.Timestamp(maintenant.getTime().getTime());
        // Calendar.getTime() retourne un java.util.Date
        // java.util.Date.getTime() retourne le temps en long
        unEnonc�SQL.setTimestamp(2,dateMaintenant);
        unEnonc�SQL.setInt(3,10);
        int n = unEnonc�SQL.executeUpdate();

    unEnonc�SQL = uneConnection.prepareStatement
        ("SELECT noCommande,dateCommande,noClient FROM Commande" );
    ResultSet r�sultatSelect = unEnonc�SQL.executeQuery();
    while (r�sultatSelect.next ()){
        int lenoCommande = r�sultatSelect.getInt("noCommande");
        java.sql.Timestamp laDate = r�sultatSelect.getTimestamp("dateCommande");
        int lenoClient = r�sultatSelect.getInt("noClient");
        
        System.out.println ("noCommande:" + lenoCommande);
        System.out.println ("dateCommande:" + laDate);
        System.out.println ("noClient:" + lenoClient);
    }
    // Fermeture de l'�nonc� et de la connexion
    unEnonc�SQL.close();
    uneConnection.close();
  }
}
