package ExemplesJDBC;
import java.sql.*;
import java.util.*;

public class TestDate 
{
  public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    // Connexion � une BD
    Connection uneConnection =
      DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:orcl", "clerat", "oracle");

      PreparedStatement unEnonc�SQL = uneConnection.prepareStatement
        ("INSERT INTO Pr�tEnCours(idExemplaire,datePr�t,idUtilisateur)"+
        "VALUES(?,?,?)");
        unEnonc�SQL.setString(1,"6");
        Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
        java.sql.Date dateMaintenant = 
          new java.sql.Date(maintenant.getTime().getTime());
        unEnonc�SQL.setDate(2,dateMaintenant);
        unEnonc�SQL.setString(3,"2");
        //NB la date est g�n�r�e automatiquement par le serveur de BD (default sysdate)
        // et le statut est modifi� par un TRIGGER
        int n = unEnonc�SQL.executeUpdate();

    unEnonc�SQL = uneConnection.prepareStatement
        ("SELECT idUtilisateur,datePr�t,idExemplaire "+
        "FROM Pr�tEnCours" );
    ResultSet r�sultatSelect = unEnonc�SQL.executeQuery();
    while (r�sultatSelect.next ()){
        String leIdUtilisateur = r�sultatSelect.getString("idUtilisateur");
        java.sql.Date laDate = r�sultatSelect.getDate("datePr�t");
        String leIdExemplaire = r�sultatSelect.getString("idExemplaire");
        
        System.out.println ("idUtilisateur:" + leIdUtilisateur);
        System.out.println ("datePr�t:" + laDate);
        System.out.println ("idExemplaire:" + leIdExemplaire);
    }
    // Fermeture de l'�nonc� et de la connexion
    unEnonc�SQL.close();
    uneConnection.close();
  }
}
