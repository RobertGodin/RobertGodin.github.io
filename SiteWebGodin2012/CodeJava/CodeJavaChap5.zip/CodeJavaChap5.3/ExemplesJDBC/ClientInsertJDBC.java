// Exemple de programme JAVA qui utilise le pilote JDBC OCI8 d'Oracle
// pour ins�rer une ligne dans la table Client

// Il faut importer le paquetage java.sql pour utiliser JDBC
package ExemplesJDBC;
import java.sql.*;

class ClientInsertJDBC
{
  public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    // Connection � une BD
    Connection uneConnection =
      DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:orcl", "godin", "oracle");

    // Cr�ation d'un �nonc� associ� � la Connection
    Statement unEnonc�SQL = uneConnection.createStatement ();
    
    // Insertion d'une ligne dans la table Client
    int n = unEnonc�SQL.executeUpdate
      ("INSERT INTO CLIENT " +
       "VALUES (100, 'G. Lemoyne', '911')");
    System.out.println ("Nombre de lignes inserees:" + n);
    
    // Fermeture de �nonc� et de la connexion
    unEnonc�SQL.close();
    uneConnection.close();
  }
}
