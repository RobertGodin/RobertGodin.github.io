package GererPretSA;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;

public interface FacadeEnrPretSimpleCMTSessionEJBHome extends EJBHome 
{
  FacadeEnrPretSimpleCMTSessionEJB create() throws RemoteException, CreateException;
}