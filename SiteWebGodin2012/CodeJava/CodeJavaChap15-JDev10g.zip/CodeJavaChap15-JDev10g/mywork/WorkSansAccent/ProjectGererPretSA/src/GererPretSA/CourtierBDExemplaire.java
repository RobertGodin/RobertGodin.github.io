package GererPretSA;
import java.sql.*;
// La classe CourtierBDExemplaire est un interm�daire qui encapsule les interactions avec la BD
public class CourtierBDExemplaire {
    private Connection uneConnection;
   
    // Constructeur pour connexion pass�e par le cr�ateur
    public CourtierBDExemplaire(Connection laConnection){
        this.uneConnection = laConnection;
    }
    
    public void setConnection(Connection laConnection){
        this.uneConnection = laConnection;
    }

    public Exemplaire chercherExemplaireParIdExemplaire(String idExemplaire)
    // Ne consid�re pas les r�f�rences au Livre et aux Prets
        throws Exception {
        // Verrouillage de l'exemplaire (FOR UPDATE)pour serialisabilite 
        // (Oracle mode READ COMMITTED)
        PreparedStatement unEnonceSQL = uneConnection.prepareStatement
        ("SELECT statut FROM Exemplaire WHERE idExemplaire = ? FOR UPDATE");
        unEnonceSQL.setString(1,idExemplaire);
        ResultSet resultatSelect = unEnonceSQL.executeQuery();
        if (resultatSelect.next()){
            Exemplaire unExemplaire = 
                new Exemplaire(
                    idExemplaire,
                    resultatSelect.getString("statut"));
            unEnonceSQL.close();
            return unExemplaire;
        }else{
            unEnonceSQL.close();
            throw new Exception("Exemplaire inexistant");
        }
    }
}