package GererPretSA;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import GererPretSA.FacadeEnrPretsSessionEJB;
import GererPretSA.FacadeEnrPretsSessionEJBHome;
import javax.naming.NamingException;

public class FacadeEnrPretsSessionEJBClient 
{
  public static void main(String [] args)
  {
    FacadeEnrPretsSessionEJBClient facadeEnrPretsSessionEJBClient = new FacadeEnrPretsSessionEJBClient();
    try
    {
      Context context = getInitialContext();
      FacadeEnrPretsSessionEJBHome facadeEnrPretsSessionEJBHome = (FacadeEnrPretsSessionEJBHome)PortableRemoteObject.narrow(context.lookup("FacadeEnrPretsSessionEJB"), FacadeEnrPretsSessionEJBHome.class);
      FacadeEnrPretsSessionEJB facadeEnrPretsSessionEJB;

      // Use one of the create() methods below to create a new instance
      facadeEnrPretsSessionEJB = facadeEnrPretsSessionEJBHome.create();

      // Call any of the Remote methods below to access the EJB
      // facadeEnrPretsSessionEJB.insererPretEnCours(  );
      // facadeEnrPretsSessionEJB.getStatutExemplaire( java.lang.String idExemplaire );
      // facadeEnrPretsSessionEJB.confirmerTransaction(  );
      // facadeEnrPretsSessionEJB.chercherOTDUtilisateurPrets( java.lang.String idUtilisateur );

    }
    catch(Throwable ex)
    {
      ex.printStackTrace();
    }

  }

  private static Context getInitialContext() throws NamingException
  {
    // Get InitialContext for Embedded OC4J.
    // The embedded server must be running for lookups to succeed.
    return new InitialContext();
  }
}