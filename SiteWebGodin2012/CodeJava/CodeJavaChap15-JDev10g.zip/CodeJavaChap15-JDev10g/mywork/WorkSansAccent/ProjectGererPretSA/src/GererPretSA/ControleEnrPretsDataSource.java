package GererPretSA;
/* Classe de contr�le simple pour EnregistrerPrets
 * Interface � l'utilisateur minimaliste
 * NB Pas de verification des conditions prealabales dans le programme client
 */
import java.sql.*;
// Le package javax contient les extensions JDBC 2 DataSource
import javax.sql.*;
import javax.naming.*;
import javax.swing.JOptionPane;
import java.util.*;

class ControleEnrPretsDataSource {
    public static void main (String args []) throws Exception {
        // Chercher la Connection � partir d'un DataSource
        InitialContext unContexte = new InitialContext();
        DataSource unDataSource = (DataSource)unContexte.lookup("jdbc/orclcleratsaCoreDS");
        Connection uneConnection = unDataSource.getConnection();

        String idUtilisateur = 
            JOptionPane.showInputDialog("Entrez l'identificateur de l'utilisateur: ");
        Utilisateur unUtilisateur = new Utilisateur(idUtilisateur);
        String idExemplaire = 
            JOptionPane.showInputDialog("Entrez l'identificateur de l'exemplaire:");
        Exemplaire unExemplaire = new Exemplaire(idExemplaire);
        
        // Generer la date du jour et l'objet PretEnCours
        Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
        java.sql.Date dateMaintenant = new java.sql.Date(maintenant.getTime().getTime());
        PretEnCours leNouveauPretEnCours = 
            new PretEnCours(unUtilisateur,dateMaintenant,unExemplaire);

        // Materialiser le PretEnCours dans la BD
        try{
            CourtierBDPretEnCours unCourtierBDPretEnCours = 
                new CourtierBDPretEnCours(uneConnection);
            unCourtierBDPretEnCours.insererPretEnCours(leNouveauPretEnCours);

            JOptionPane.showMessageDialog(null,
            "Pret de l'exemplaire " + idExemplaire +
            " � l'utilisateur " + idUtilisateur + " confirme.\nDate:" + dateMaintenant);
        }
        catch(Exception lException){
            JOptionPane.showMessageDialog(null,lException.getMessage());
            lException.printStackTrace();
        }
        finally{
            // Pas besoin de commit
            uneConnection.close();
            System.exit(0);
        }
    }
}