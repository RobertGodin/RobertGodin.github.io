package GererPretSA;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;
public class PretEnCours extends Pret {
    public PretEnCours(Utilisateur lUtilisateur,java.sql.Date datePret, Exemplaire lExemplaire) {
        super(lUtilisateur,datePret,lExemplaire);
    }
    // Le constructeur suivant ne construit pas le lien vers Exemplaire
    public PretEnCours(Utilisateur lUtilisateur,java.sql.Date datePret) {
        super(lUtilisateur,datePret,null);
    }
}
