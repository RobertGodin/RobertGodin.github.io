package GererPretSA;
import java.sql.*;
import java.util.*;

public class CourtierBDUtilisateur{
    private Connection uneConnection;
   
    // Constructeur pour connexion passee par le createur
    public CourtierBDUtilisateur(Connection laConnection){
        this.uneConnection = laConnection;
    }
    
    public void setConnection(Connection laConnection){
        this.uneConnection = laConnection;
    }
    
    public void chercherVariablesStatiquesDeMembre()
    // Extrait les valeurs actuelles de nbMaxPrets et dureeMaxPrets
    throws Exception{
        // Initialiser les variables statiques de Membre
        PreparedStatement unEnonceSQL = uneConnection.prepareStatement
        ("SELECT nbMaxPrets, dureeMaxPrets FROM MembreGeneral FOR UPDATE");
        ResultSet resultatSelect = unEnonceSQL.executeQuery();
        if (resultatSelect.next ()){
            Membre.setNbMaxPrets(resultatSelect.getInt ("nbMaxPrets"));
            Membre.setDureeMaxPrets(resultatSelect.getInt ("dureeMaxPrets"));
            unEnonceSQL.close();
        }else{
            unEnonceSQL.close();
            throw new Exception("table MembreGeneral corrompue");
        }
    }

    public Utilisateur chercherUtilisateurParIdUtilisateur(String idUtilisateur)
    // Retourne un objet Membre ou un Employe selon le cas
    throws Exception {
        // Verrouillage de l'utilisateur pour serialisabilite (Oracle mode READ COMMITTED)
        PreparedStatement unEnonceSQL = uneConnection.prepareStatement
        ("SELECT motPasse,nom,prenom,categorieUtilisateur,telephoneResidence,codeMatricule,categorieEmploye "+
        "FROM Membre m, Utilisateur u, Employe e WHERE u.idUtilisateur = ? AND "+
        "u.idUtilisateur = m.idUtilisateur (+) AND "+
        "u.idUtilisateur = e.idUtilisateur (+) FOR UPDATE");
        unEnonceSQL.setString(1,idUtilisateur);
        ResultSet resultatSelect = unEnonceSQL.executeQuery();
        if (resultatSelect.next ()){
            if (resultatSelect.getString ("categorieUtilisateur").equals("membre")){
                Membre leMembre = new Membre(
                    idUtilisateur,resultatSelect.getString ("motPasse"),
                    resultatSelect.getString ("nom"),resultatSelect.getString ("prenom"),
                    resultatSelect.getString ("categorieUtilisateur"),
                    resultatSelect.getString ("telephoneResidence"));
                unEnonceSQL.close();
                return leMembre;
            }
            else{// Pas un Membre, doit etre un Employe
                Employe lEmploye = new Employe(idUtilisateur,resultatSelect.getString ("motPasse"),
                    resultatSelect.getString ("nom"),resultatSelect.getString ("prenom"),
                    resultatSelect.getString ("categorieUtilisateur"),
                    resultatSelect.getString ("codeMatricule"),
                    resultatSelect.getString ("categorieEmploye")
                    );
                unEnonceSQL.close();
                return lEmploye;
            }
        } else {
            unEnonceSQL.close();
            throw new Exception("Utilisateur non trouve "+idUtilisateur);
        }
    }
}