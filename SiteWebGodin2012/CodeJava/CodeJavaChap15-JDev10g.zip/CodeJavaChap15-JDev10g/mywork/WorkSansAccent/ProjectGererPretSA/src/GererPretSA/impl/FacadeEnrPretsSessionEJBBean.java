package GererPretSA.impl;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import java.sql.Connection;
import GererPretSA.*;
import java.sql.Date;
import java.util.*;

public class FacadeEnrPretsSessionEJBBean implements SessionBean 
{
  private Connection uneConnection;
  private Utilisateur unUtilisateur;
  private Exemplaire unExemplaire;
  private CourtierBDPretEnCours unCourtierBDPretEnCours;

  public void ejbCreate()throws Exception{}

  public void ejbActivate(){}

  public void ejbPassivate(){}

  public void ejbRemove(){}

  public void setSessionContext(SessionContext ctx) {
    try {
    UsineConnection uneUsineConnection = new UsineConnection();
    uneConnection = 
      uneUsineConnection.getConnectionFromDataSourceSansAutoCommit("jdbc/orclcleratsaCoreDS");
    }
    catch(Exception lException){
      lException.printStackTrace();
    }
  }


  public OTDUtilisateurPrets chercherOTDUtilisateurPrets(String idUtilisateur) throws Exception
  {
    // Creation du courtier et dematerialisation de l'Utilisateur
    CourtierBDUtilisateur unCourtierBDUtilisateur = new CourtierBDUtilisateur(uneConnection);
    unUtilisateur = 
        unCourtierBDUtilisateur.chercherUtilisateurParIdUtilisateur(idUtilisateur);
        
    //Creation du courtier et dematerialisation des PretsEnCours
    unCourtierBDPretEnCours = new CourtierBDPretEnCours(uneConnection);
    unCourtierBDPretEnCours.chercherLesPretsEnCours(unUtilisateur);

    // Retourner l'objet de transfert de donnees OTDUtilisateurPrets
    if (unUtilisateur instanceof Membre){
      unCourtierBDUtilisateur.chercherVariablesStatiquesDeMembre();
      Membre unMembre = (Membre)unUtilisateur;
      return new OTDUtilisateurPrets(
                  unMembre.getCategorie(),
                  unMembre.conditionsPretAcceptees(),
                  unMembre.getNbPretsEnCours(),
                  Membre.getNbMaxPrets(),
                  unMembre.getNbRetards());
    } else {
      return new OTDUtilisateurPrets(
        unUtilisateur.getCategorie(),true,unUtilisateur.getNbPretsEnCours(),0,0);
    }
  }

  public String getStatutExemplaire(String idExemplaire) throws Exception{
    // Chercher l'exemplaire en passant par le courtier et retourner le statut
    CourtierBDExemplaire unCourtierBDExemplaire = new CourtierBDExemplaire(uneConnection);
    unExemplaire = unCourtierBDExemplaire.chercherExemplaireParIdExemplaire(idExemplaire);
    return unExemplaire.getStatut();
  }

  public Date insererPretEnCours() throws Exception  {
    Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
    java.sql.Date dateMaintenant = new java.sql.Date(maintenant.getTime().getTime());
    PretEnCours leNouveauPretEnCours = 
          new PretEnCours(unUtilisateur,dateMaintenant,unExemplaire);

    // Materialiser le PretEnCours dans la BD
    unCourtierBDPretEnCours.insererPretEnCours(leNouveauPretEnCours);
    return dateMaintenant;
  }

  public void confirmerTransaction() throws Exception  {
    uneConnection.commit();
    uneConnection.close();
  }
}