package GererPretSA;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import GererPretSA.FacadeEnrPretsSessionEJB;
import GererPretSA.FacadeEnrPretsSessionEJBHome;

// Fa�ade pour le cas d'utilisation EnregistrerPrets
// Isole la classe de contr�le des d�tails de la gestion de persistence par courtier
// NB Les m�thodes de la fa�ade doivent etre appel�es en s�quence
public class FacadeEJBEnregistrerPrets 
{
  private FacadeEnrPretsSessionEJB uneFacadeEnrPretsSessionEJB;
  public FacadeEJBEnregistrerPrets()throws Exception
  {
      // Le constructeur cr�e l'objet session EJB fa�ade
      Context context = new InitialContext();
      FacadeEnrPretsSessionEJBHome facadeEnrPretsSessionEJBHome = (FacadeEnrPretsSessionEJBHome)PortableRemoteObject.narrow(context.lookup("FacadeEnrPretsSessionEJB"), FacadeEnrPretsSessionEJBHome.class);
      uneFacadeEnrPretsSessionEJB = facadeEnrPretsSessionEJBHome.create();


/*    NB Le code suivant ne fonctionne plus avec JDevelopper 10g (fonctionnait avec 9.0.2)
      Hashtable env = new Hashtable();
      env.put(Context.INITIAL_CONTEXT_FACTORY, "com.evermind.server.rmi.RMIInitialContextFactory");
      env.put(Context.SECURITY_PRINCIPAL, "admin");
      env.put(Context.SECURITY_CREDENTIALS, "welcome");
      env.put(Context.PROVIDER_URL, "ormi://localhost:23893/current-workspace-app");
      Context ctx = new InitialContext(env);
      FacadeEnrPretsSessionEJBHome facadeEnrPretsSessionEJBHome = 
        (FacadeEnrPretsSessionEJBHome)ctx.lookup("FacadeEnrPretsSessionEJB");
      

      uneFacadeEnrPretsSessionEJB = facadeEnrPretsSessionEJBHome.create(  );  
*/
      }
  
  // Cherche un Utilisateur avec ses PretsEnCours et retourne
  // les donn�es n�cessaires pour EnregistrerPrets (OTDUtilisateurPrets)
  // Une exception est lev�e si l'Utilisateur n'existe pas
  public OTDUtilisateurPrets chercherOTDUtilisateurPrets(String idUtilisateur)throws Exception {
    return uneFacadeEnrPretsSessionEJB.
    chercherOTDUtilisateurPrets(idUtilisateur);
  }

  public String getStatutExemplaire(String idExemplaire)throws Exception{
    return uneFacadeEnrPretsSessionEJB.getStatutExemplaire(idExemplaire);
  }

  // Ins�re le pret et retourne la date d'enregistrement
  public java.sql.Date insererPretEnCours() throws Exception{
    return uneFacadeEnrPretsSessionEJB.insererPretEnCours();
  }

  // Confirmer la transaction et fermer la Connection
  public void confirmerTransaction()throws Exception{
    uneFacadeEnrPretsSessionEJB.confirmerTransaction();
  }
}
