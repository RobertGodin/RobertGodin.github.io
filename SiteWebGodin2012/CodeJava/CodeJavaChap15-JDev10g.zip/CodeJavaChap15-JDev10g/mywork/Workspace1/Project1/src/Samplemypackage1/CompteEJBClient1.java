package Samplemypackage1;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import mypackage1.CompteEJB;
import mypackage1.CompteEJBHome;
import java.util.Collection;
import java.util.Iterator;

public class CompteEJBClient1 
{
  public static void main(String [] args)
  {
    CompteEJBClient1 compteEJBClient1 = new CompteEJBClient1();
    try
    {
      Context ctx = new InitialContext();
      CompteEJBHome compteEJBHome = (CompteEJBHome)ctx.lookup("CompteEJB");
      CompteEJB compteEJB;

      // Use one of the create() methods below to create a new instance
      // compteEJB = compteEJBHome.create( int noCompte, java.sql.Date dateOuverture, int noClient );

      // Retrieve all instances using the findAll() method
      // (CMP Entity beans only)
      Collection coll = compteEJBHome.findAll();
      Iterator iter = coll.iterator();
      while (iter.hasNext())
      {
        compteEJB = (CompteEJB)iter.next();
        System.out.println("noCompte = " + compteEJB.getNoCompte());
        System.out.println("solde = " + compteEJB.getSolde());
        System.out.println("dateOuverture = " + compteEJB.getDateOuverture());
        System.out.println("noClient = " + compteEJB.getNoClient());
        System.out.println();
      }

      // Call any of the Remote methods below to access the EJB
      // compteEJB.getNoCompte(  );
      // compteEJB.getSolde(  );
      // compteEJB.setSolde( double newSolde );
      // compteEJB.getDateOuverture(  );
      // compteEJB.setDateOuverture( java.sql.Date newDateouverture );
      // compteEJB.getNoClient(  );
      // compteEJB.setNoClient( int newNoclient );
    }
    catch(Throwable ex)
    {
      ex.printStackTrace();
    }

  }
}