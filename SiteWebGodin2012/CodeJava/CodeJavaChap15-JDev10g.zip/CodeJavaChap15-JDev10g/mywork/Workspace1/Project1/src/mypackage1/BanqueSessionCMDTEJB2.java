package mypackage1;
import javax.ejb.*;
import java.rmi.RemoteException;

public interface BanqueSessionCMDTEJB2 extends EJBObject 
{
  void transferer(int noCompteADebiter, int noCompteACrediter, double montant) throws EJBException, RemoteException;
}