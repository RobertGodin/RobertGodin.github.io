package Samplemypackage1;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import mypackage1.*;
import java.util.*;

public class CompteEJBClient {
  public static void main(String [] args){
    CompteEJBClient compteEJBClient = new CompteEJBClient();
    try{
      // Recherche de l'objet local home
      Context ctx = new InitialContext();
      CompteEJBHome compteEJBHome = (CompteEJBHome)ctx.lookup("CompteEJB");
      CompteEJB compteEJB;

      // Cr�ation d'un Compte
      Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
      java.sql.Date dateMaintenant = 
                        new java.sql.Date(maintenant.getTime().getTime());
      compteEJB = compteEJBHome.create(1000, dateMaintenant, 10);

      // Recherche de tous les Comptes
      Collection uneCollection = compteEJBHome.findAll();
      Iterator unIterator = uneCollection.iterator();
      System.out.println("Liste des comptes");
      System.out.println("noCompte\tsolde\tdateOuverture\tnoClient");      
      while (unIterator.hasNext()){
        compteEJB = (CompteEJB)unIterator.next();
        System.out.println(
          compteEJB.getNoCompte()+"\t"+
          compteEJB.getSolde()+"\t"+
          compteEJB.getDateOuverture()+"\t"+
          compteEJB.getNoClient());
      }

      // Recherche des Comptes du Client 30
      uneCollection = compteEJBHome.findByNoClient(30);
      unIterator = uneCollection.iterator();
      System.out.println("Liste des comptes du client 30");
      System.out.println("noCompte\tsolde\tdateOuverture\tnoClient");      
      while (unIterator.hasNext()){
        compteEJB = (CompteEJB)unIterator.next();
        System.out.println(
          compteEJB.getNoCompte()+"\t"+
          compteEJB.getSolde()+"\t"+
          compteEJB.getDateOuverture()+"\t"+
          compteEJB.getNoClient());
      }

      // Recherche du compte 200
      compteEJB = compteEJBHome.findByPrimaryKey(new CompteEJBPK(200));

      // Extraction du solde
      System.out.println("Solde du compte 200 :"+compteEJB.getSolde());

      // Modification du solde
      compteEJB.setSolde(1000.0);

      // Suppression d'un Compte
      compteEJB = compteEJBHome.findByPrimaryKey(new CompteEJBPK(400));
      compteEJB.remove();
      
    }
    catch(Exception lException){
            lException.printStackTrace();
    }
  }
}