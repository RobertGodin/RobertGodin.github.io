package mypackage1;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;
import java.sql.Date;

public interface Compte extends EJBObject 
{
  int getNocompte() throws RemoteException;

  void setNocompte(int newNocompte) throws RemoteException;

  double getSolde() throws RemoteException;

  void setSolde(double newSolde) throws RemoteException;

  Date getDateouverture() throws RemoteException;

  void setDateouverture(Date newDateouverture) throws RemoteException;

  int getNoclient() throws RemoteException;

  void setNoclient(int newNoclient) throws RemoteException;
}