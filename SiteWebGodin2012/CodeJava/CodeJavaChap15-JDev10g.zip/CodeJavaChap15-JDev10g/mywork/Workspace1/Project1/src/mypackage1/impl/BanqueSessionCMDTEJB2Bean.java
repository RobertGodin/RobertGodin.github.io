package mypackage1.impl;
import javax.ejb.*;
import java.sql.Connection;
import java.util.*;
import java.lang.*;
import javax.naming.*;
import mypackage1.*;

public class BanqueSessionCMDTEJB2Bean implements SessionBean 
{
  private SessionContext sessionContext;

  public void ejbCreate() {}

  public void ejbActivate() {}

  public void ejbPassivate(){}

  public void ejbRemove(){}

  public void setSessionContext(SessionContext ctx){
    this.sessionContext = ctx;
  }

  public void transferer(int noCompteADebiter, int noCompteACrediter, double montant)
  throws EJBException{
      // Cr�er l'objet EJB local (stub RMI)
    try{
      Context ctx = new InitialContext();
      CompteEJBHome compteEJBHome =
        (CompteEJBHome)ctx.lookup("CompteEJB");
      CompteEJB compteADebiter = compteEJBHome.findByPrimaryKey(new CompteEJBPK(noCompteADebiter));
      CompteEJB compteACrediter = compteEJBHome.findByPrimaryKey(new CompteEJBPK(noCompteACrediter));

      // Appel de m�thode sur l'objet EJB local
      compteADebiter.setSolde(compteADebiter.getSolde()-(long)montant);
      compteACrediter.setSolde(compteACrediter.getSolde()+(long)montant);
    }
    catch(Exception lException){
      throw new EJBException(lException);
    }
  }
}