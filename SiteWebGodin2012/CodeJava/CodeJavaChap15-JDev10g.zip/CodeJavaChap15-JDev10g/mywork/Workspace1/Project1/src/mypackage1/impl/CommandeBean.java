package mypackage1.impl;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import mypackage1.CommandePK;

public class CommandeBean implements EntityBean 
{
  public EntityContext entityContext;
  public long nocommande;
  public String datecommande;
  public long noclient;

  public CommandePK ejbCreate()
  {
    return null;
  }

  public void ejbPostCreate()
  {
  }

  public CommandePK ejbCreate(long nocommande, String datecommande, long noclient)
  {
    this.nocommande = nocommande;
    this.datecommande = datecommande;
    this.noclient = noclient;
    return new CommandePK(nocommande);
  }

  public void ejbPostCreate(long nocommande, String datecommande, long noclient)
  {
  }

  public void ejbActivate()
  {
  }

  public void ejbLoad()
  {
  }

  public void ejbPassivate()
  {
  }

  public void ejbRemove()
  {
  }

  public void ejbStore()
  {
  }

  public void setEntityContext(EntityContext ctx)
  {
    this.entityContext = ctx;
  }

  public void unsetEntityContext()
  {
    this.entityContext = null;
  }

  public long getNocommande()
  {
    return nocommande;
  }

  public void setNocommande(long newNocommande)
  {
    nocommande = newNocommande;
  }

  public String getDatecommande()
  {
    return datecommande;
  }

  public void setDatecommande(String newDatecommande)
  {
    datecommande = newDatecommande;
  }

  public long getNoclient()
  {
    return noclient;
  }

  public void setNoclient(long newNoclient)
  {
    noclient = newNoclient;
  }
}