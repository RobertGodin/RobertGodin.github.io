package mypackage1;
import java.sql.*;
import javax.naming.*;
import javax.sql.*;
import oracle.jdbc.pool.*;


public class UsineConnection {
    public UsineConnection() {}
    public Connection getConnectionSansAutoCommit(
        String nomPilote,   // "oracle.jdbc.driver.OracleDriver" pour Oracle
        String URLBD,       // exemple : "jdbc:oracle:thin:@localhost:1521:ora817i"
        String authorizationID,
        String password)
        throws Exception {
            Class.forName (nomPilote);
            Connection uneConnection = DriverManager.getConnection (URLBD, authorizationID,password);
            uneConnection.setAutoCommit(false);
            return uneConnection;
    }
    public Connection getConnection(
        String nomPilote,   // "oracle.jdbc.driver.OracleDriver" pour Oracle
        String URLBD,       // exemple : "jdbc:oracle:thin:@localhost:1521:ora817i"
        String authorizationID,
        String password)
        throws Exception {
            Class.forName (nomPilote);
            Connection uneConnection = DriverManager.getConnection (URLBD, authorizationID,password);
            return uneConnection;
    }
    public Connection getConnectionFromDataSource(
        String nomDataSource)
        throws Exception {
            InitialContext unContexte = new InitialContext();
            DataSource unDataSource = (DataSource)unContexte.lookup(nomDataSource);
            Connection uneConnection = unDataSource.getConnection();
            return uneConnection;
    }
    public Connection getConnectionFromDataSourceSansAutoCommit(
        String nomDataSource)
        throws Exception {
            InitialContext unContexte = new InitialContext();
            DataSource unDataSource = (DataSource)unContexte.lookup(nomDataSource);
            Connection uneConnection = unDataSource.getConnection();
            uneConnection.setAutoCommit(false);
            return uneConnection;
    }
    public Connection getConnectionFromConnectionPoolDataSource(
        String nomDataSource)
        throws Exception {
            InitialContext unContexte = new InitialContext();
            ConnectionPoolDataSource unDataSource = (ConnectionPoolDataSource)unContexte.lookup(nomDataSource);
            PooledConnection unePooledConnection = unDataSource.getPooledConnection();
            Connection uneConnection = unePooledConnection.getConnection();
            return uneConnection;
    }
    public Connection getConnectionFromOracleConnectionPoolDataSource(
        String nomDataSource)
        throws Exception {
            InitialContext unContexte = new InitialContext();
            OracleConnectionPoolDataSource unDataSource = (OracleConnectionPoolDataSource)unContexte.lookup(nomDataSource);
            PooledConnection unePooledConnection = unDataSource.getPooledConnection();
            Connection uneConnection = unePooledConnection.getConnection();
            return uneConnection;
    }
    
}