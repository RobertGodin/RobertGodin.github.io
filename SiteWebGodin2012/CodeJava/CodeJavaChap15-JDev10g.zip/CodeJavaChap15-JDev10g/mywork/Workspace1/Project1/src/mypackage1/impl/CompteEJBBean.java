package mypackage1.impl;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import mypackage1.CompteEJBPK;
import java.sql.Date;

public class CompteEJBBean implements EntityBean 
{
  public EntityContext entityContext;
  public int noCompte;
  public double solde;
  public Date dateOuverture;
  public int noClient;

  public CompteEJBPK ejbCreate(int noCompte, Date dateOuverture, int noClient) {
    this.noCompte = noCompte;
    this.dateOuverture = dateOuverture;
    this.noClient = noClient;
    return null;
//    return new CompteEJBPK(noCompte);
  }

  public void ejbPostCreate(int noCompte, Date dateOuverture, int noClient){}

  public void ejbActivate(){}

  public void ejbLoad(){}

  public void ejbPassivate(){}

  public void ejbRemove() {}

  public void ejbStore(){}

  public void setEntityContext(EntityContext ctx){
    this.entityContext = ctx;
  }

  public void unsetEntityContext(){
    this.entityContext = null;
  }

  public int getNoCompte(){
    return noCompte;
  }

  public double getSolde(){
    return solde;
  }

  public void setSolde(double newSolde){
    solde = newSolde;
  }

  public Date getDateOuverture(){
    return dateOuverture;
  }

  public void setDateOuverture(Date newDateouverture){
    dateOuverture = newDateouverture;
  }

  public int getNoClient(){
    return noClient;
  }

  public void setNoClient(int newNoclient){
    noClient = newNoclient;
  }
}