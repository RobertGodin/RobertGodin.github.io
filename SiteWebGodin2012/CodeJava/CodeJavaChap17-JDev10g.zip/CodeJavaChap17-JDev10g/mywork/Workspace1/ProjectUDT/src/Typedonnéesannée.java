import java.sql.*;

public class Typedonn�esann�e implements SQLData
{
  private String nomUDT = "GODIN.TYPEDONN�ESANN�E";

  private int valeurAnn�e;

  public Typedonn�esann�e(){}

  public int getValeurann�e(){return valeurAnn�e; }
  public void setValeurann�e(int valeurann�e) {this.valeurAnn�e = valeurann�e; }
  
  // M�thodes de l'interface SQLdata � impl�menter
  public String getSQLTypeName() throws SQLException { return nomUDT; } 

  public void readSQL(SQLInput stream, String type)
  throws SQLException{
      setValeurann�e(stream.readInt());
  }

  public void writeSQL(SQLOutput stream)
  throws SQLException{
      stream.writeInt(getValeurann�e());
  }
}
