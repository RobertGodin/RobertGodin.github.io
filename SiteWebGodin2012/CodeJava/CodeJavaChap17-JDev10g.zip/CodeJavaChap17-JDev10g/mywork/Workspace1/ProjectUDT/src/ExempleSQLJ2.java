import java.sql.*;
import java.util.*;
import oracle.sql.*;
import oracle.jdbc.*;
import java.math.*;

public class ExempleSQLJ2 
{
  public static void main (String args []) throws Exception {
    // Cr�ation d'une Connection globale pour l'application
    UsineConnection uneUsineConnection = new UsineConnection();
    Connection uneConnection = uneUsineConnection.getConnectionSansAutoCommit(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:orcl",
            "godin","oracle");
    try{
        // Recherche de la r�f�rence au LivreType ISBN = '0-201-12227-8'
        PreparedStatement unPreparedStatement = uneConnection.prepareStatement
        ("SELECT REF(l) AS refLivre FROM Livre l WHERE l.ISBN = '0-201-12227-8'");
        ResultSet unResultSet = unPreparedStatement.executeQuery();

        //Cr�er un type map qui associe le UDT � la classe SQLdata
        java.util.Map typeMap = uneConnection.getTypeMap();
        
//        typeMap.put("LIVRETYPE",Class.forName("LivreTypePourUDT"));
//        typeMap.put("TYPEDONN�ESANN�E",Class.forName("Typedonn�esann�e"));
        typeMap.put("EDITEURTYPE",Class.forName("EditeurTypePourUDT"));
        
        if (unResultSet.next()){
          // Conversion de la r�f�rence � l'UDT LivreType sous forme d'un objet Java REF
          REF ref = (REF) unResultSet.getObject(1);

          LivreTypePourUDT unLivreType = (LivreTypePourUDT)ref.getValue();
          System.out.println("ISBN :"+unLivreType.getIsbn()); // ISBN CHAR(13)
          System.out.println("titre :"+unLivreType.getTitre()); // titre VARCHAR(50)
          Typedonn�esann�e unTypedonn�esann�e = unLivreType.getAnn�eparution(); // ann�eParution TypeDonn�esAnn�e
          System.out.println("ann�e :"+unTypedonn�esann�e.getValeurann�e()); // valeurAnn�e INTEGER

          REF unEditeurRef = (REF) unLivreType.get�diteur();
          EditeurTypePourUDT unEditeurTypePourUDT = (EditeurTypePourUDT)unEditeurRef.getValue();

          System.out.println("nomEditeur :" + unEditeurTypePourUDT.getNomediteur()); // nomEditeur VARCHAR(20)
          System.out.println("ville :"+unEditeurTypePourUDT.getVille()); // ville VARCHAR(20)

          // Suivre les r�f�rences inverses
          // L'attribut lesLivres est une table ench�ss�e extraite sous forme d'ARRAY
          ARRAY laTableEnchasse =  (ARRAY)unEditeurTypePourUDT.getLeslivres(); //lesLivres tableRefLivresType
                    
          // Extraire les �l�ments sous forme de tableau d'objets
          Object[] lesLivres = (Object[])laTableEnchasse.getArray();

          // Parcours de la table ench�ss�e
          for (int i=0; i<lesLivres.length;i++){
            // Chacun des �l�ments de la table ench�ss�e est un UDT LivreRefType converti en STRUCT
            STRUCT unREFLivreStruct = (STRUCT) lesLivres[i];
            Object attributsDeREFLivreStruct[] = unREFLivreStruct.getAttributes();
            REF refLivre = (REF)attributsDeREFLivreStruct[0]; // livreRef REF LivreType

            LivreTypePourUDT unAutreLivreType = (LivreTypePourUDT)refLivre.getValue();
            System.out.println("ISBN :"+unAutreLivreType.getIsbn()); // ISBN CHAR(13)
            System.out.println("titre :"+unAutreLivreType.getTitre()); // titre VARCHAR(50)
          }
        }else{
            throw new Exception("Livre inexistant");
        }
    }
    catch(Exception lException){
            lException.printStackTrace();
    }
    finally{
            uneConnection.commit();
            uneConnection.close();
            System.exit(0);
    }
  }
}