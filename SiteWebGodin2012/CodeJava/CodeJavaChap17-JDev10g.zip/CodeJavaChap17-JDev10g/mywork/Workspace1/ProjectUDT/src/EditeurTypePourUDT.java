import java.sql.*;

public class EditeurTypePourUDT implements SQLData
{
  private String nomUDT = "GODIN.EDITEURTYPE";

  private String nomEditeur;
  private String ville;
  private java.sql.Array lesLivres;

  public EditeurTypePourUDT(){}

  public String getNomediteur(){return nomEditeur; }
  public void setNomediteur(String nomediteur){ this.nomEditeur = nomediteur; }

  public String getVille(){ return ville; }
  public void setVille(String ville){ this.ville = ville; }

  public java.sql.Array getLeslivres(){ return lesLivres; }
  public void setLeslivres(java.sql.Array leslivres)
  { this.lesLivres = leslivres; }

  // M�thodes de l'interface SQLData � impl�menter
  public String getSQLTypeName() throws SQLException {return nomUDT;}

  public void readSQL(SQLInput stream, String type) throws SQLException{
      setNomediteur(stream.readString());
      setVille(stream.readString());
      setLeslivres(stream.readArray());
  }

  public void writeSQL(SQLOutput stream) throws SQLException{
      stream.writeString(getNomediteur());
      stream.writeString(getVille());
      stream.writeArray(getLeslivres());
  }
}
