package mypackage1;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import java.util.Collection;

public interface CompteHome extends EJBHome 
{
  Compte create() throws RemoteException, CreateException;

  Compte create(int nocompte) throws RemoteException, CreateException;

  Compte findByPrimaryKey(Integer primaryKey) throws RemoteException, FinderException;

  Collection findAll() throws RemoteException, FinderException;
}