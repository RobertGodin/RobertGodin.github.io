package mypackage1;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;

public interface BanqueSessionCMTDEJB extends EJBObject {
  void transferer(int noCompteADebiter, int noCompteACrediter, double montant) throws RemoteException;
}