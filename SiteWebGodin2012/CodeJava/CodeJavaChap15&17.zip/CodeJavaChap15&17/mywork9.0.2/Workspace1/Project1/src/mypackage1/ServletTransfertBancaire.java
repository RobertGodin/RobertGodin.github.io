package mypackage1;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;
import javax.naming.Context;
import javax.naming.InitialContext;

public class ServletTransfertBancaire extends HttpServlet {

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

    String noCompteADebiterString = "";
    try { noCompteADebiterString = request.getParameter("noCompteADebiter"); }
    catch (Exception e) { e.printStackTrace(); }
    int noCompteADebiter = Integer.parseInt(noCompteADebiterString);
    
    String noCompteACrediterString = "";
    try { noCompteACrediterString = request.getParameter("noCompteACrediter"); }
    catch (Exception e) { e.printStackTrace(); }
    int noCompteACrediter = Integer.parseInt(noCompteACrediterString);

    String montantString = "";
    try { montantString = request.getParameter("montant"); }
    catch (Exception e) { e.printStackTrace(); }
    double montant = Double.parseDouble(montantString);

    // Ent�te de la page de r�ponse HTML
    response.setContentType("text/html");
    OutputStreamWriter unOutputStreamWriter =
      new OutputStreamWriter(response.getOutputStream());
    PrintWriter out = new PrintWriter(unOutputStreamWriter);
    out.println("<html>");
    out.println("<head><title>R�ponse de ServletTransfertBancaire</title></head>");
    out.println("<body>");
    try{
      // Cr�er l'objet EJB local (stub RMI)
      Hashtable env = new Hashtable();
      env.put(Context.INITIAL_CONTEXT_FACTORY, "com.evermind.server.rmi.RMIInitialContextFactory");
      env.put(Context.SECURITY_PRINCIPAL, "admin");
      env.put(Context.SECURITY_CREDENTIALS, "welcome");
      env.put(Context.PROVIDER_URL, "ormi://localhost:23893/current-workspace-app");
      Context ctx = new InitialContext(env);
      BanqueSessionBMTDEJBHome banqueSessionBMTDEJBHome =
        (BanqueSessionBMTDEJBHome)ctx.lookup("BanqueSessionBMTDEJB");
      BanqueSessionBMTDEJB unBanqueSessionBMTDEJB = banqueSessionBMTDEJBHome.create();

      // Appel de m�thode sur l'objet EJB local
      unBanqueSessionBMTDEJB.transferer(noCompteADebiter,noCompteACrediter,montant);

      out.println("Transfert de " + montant +
        " du compte " + noCompteADebiter + "(banque 1) au compte " +
        noCompteACrediter + "(banque 2)");
    }
    catch(Exception lException){
      out.println(lException.getMessage());
      lException.printStackTrace();
    }
    finally{
      try{
        // Fin de la page HTML
        out.println("</body></html>");
        out.close();
      }
      catch(Exception lException){
        lException.printStackTrace();
      }
    }
  }
}
