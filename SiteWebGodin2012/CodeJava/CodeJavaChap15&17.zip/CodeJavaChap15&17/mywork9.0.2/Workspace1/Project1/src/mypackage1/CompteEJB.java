package mypackage1;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;
import java.sql.Date;

public interface CompteEJB extends EJBObject 
{
  int getNoCompte() throws RemoteException;

  double getSolde() throws RemoteException;

  void setSolde(double newSolde) throws RemoteException;

  Date getDateOuverture() throws RemoteException;

  void setDateOuverture(Date newDateouverture) throws RemoteException;

  int getNoClient() throws RemoteException;

  void setNoClient(int newNoclient) throws RemoteException;
}