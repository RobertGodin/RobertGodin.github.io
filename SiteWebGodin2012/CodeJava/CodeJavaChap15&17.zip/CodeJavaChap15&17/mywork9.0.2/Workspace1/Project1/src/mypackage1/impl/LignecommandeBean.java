package mypackage1.impl;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import mypackage1.LignecommandePK;

public class LignecommandeBean implements EntityBean 
{
  public EntityContext entityContext;
  public long nocommande;
  public long noarticle;
  public long quantit�;

  public LignecommandePK ejbCreate()
  {
    return null;
  }

  public void ejbPostCreate()
  {
  }

  public LignecommandePK ejbCreate(long nocommande, long noarticle, long quantit�)
  {
    this.nocommande = nocommande;
    this.noarticle = noarticle;
    this.quantit� = quantit�;
    return new LignecommandePK(nocommande, noarticle);
  }

  public void ejbPostCreate(long nocommande, long noarticle, long quantit�)
  {
  }

  public void ejbActivate()
  {
  }

  public void ejbLoad()
  {
  }

  public void ejbPassivate()
  {
  }

  public void ejbRemove()
  {
  }

  public void ejbStore()
  {
  }

  public void setEntityContext(EntityContext ctx)
  {
    this.entityContext = ctx;
  }

  public void unsetEntityContext()
  {
    this.entityContext = null;
  }

  public long getNocommande()
  {
    return nocommande;
  }

  public void setNocommande(long newNocommande)
  {
    nocommande = newNocommande;
  }

  public long getNoarticle()
  {
    return noarticle;
  }

  public void setNoarticle(long newNoarticle)
  {
    noarticle = newNoarticle;
  }

  public long getQuantit�()
  {
    return quantit�;
  }

  public void setQuantit�(long newQuantit�)
  {
    quantit� = newQuantit�;
  }
}