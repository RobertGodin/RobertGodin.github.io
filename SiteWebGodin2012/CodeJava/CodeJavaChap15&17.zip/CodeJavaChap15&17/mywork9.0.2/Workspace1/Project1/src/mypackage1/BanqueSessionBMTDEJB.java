package mypackage1;
import javax.ejb.*;
import java.rmi.RemoteException;
import java.sql.Connection;

public interface BanqueSessionBMTDEJB extends EJBObject {
  void transferer(int noCompteADebiter, int noCompteACrediter, double montant) 
    throws RemoteException, EJBException;
}