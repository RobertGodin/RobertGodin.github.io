package mypackage1.impl;
import javax.ejb.*;
import java.sql.*;
import java.sql.Connection;
import javax.transaction.*;
import mypackage1.UsineConnection;

// Exemple de EJB session qui r�alise une transaction r�partie
// D�marcation d�clarative par le descripteur de d�ploiement XML
public class BanqueSessionCMTDEJBBean implements SessionBean {
  private SessionContext sessionContext;
  private Connection connectionBanqueDebit;
  private Connection connectionBanqueCredit;

  public void ejbCreate() {}

  public void ejbActivate(){ouvrirConnections();}

  public void ejbPassivate(){fermerConnections();}

  public void ejbRemove() {fermerConnections();}

  public void setSessionContext(SessionContext ctx){
    sessionContext = ctx;
    ouvrirConnections();
  }

  // Attribut de transaction RequiresNew dans le descripteur de d�ploiement XML 
  public void transferer(int noCompteADebiter, int noCompteACrediter, double montant) 
    throws EJBException{
    try{
        // D�biter le compte de connectionBanqueDebit
        PreparedStatement preparedStatementDebit = connectionBanqueDebit.prepareStatement
          ("UPDATE Compte SET solde = solde - ? WHERE noCompte = ?");
        preparedStatementDebit.setDouble(1,montant);
        preparedStatementDebit.setInt(2,noCompteADebiter);
        int n = preparedStatementDebit.executeUpdate();
        preparedStatementDebit.close();
        if (n != 1){throw new EJBException("Retrait a �chou�");}

        // Cr�diter le compte de connectionBanqueCredit
        PreparedStatement preparedStatementCredit = connectionBanqueCredit.prepareStatement
          ("UPDATE Compte SET solde = solde + ? WHERE noCompte = ?");
        preparedStatementCredit.setDouble(1,montant);
        preparedStatementCredit.setInt(2,noCompteACrediter);
        n = preparedStatementCredit.executeUpdate();
        if (n != 1){throw new EJBException("D�p�t a �chou�");}
        preparedStatementCredit.close();
    }
    catch(Exception lException){
      throw new EJBException(lException);
    }
  }

  void ouvrirConnections() throws EJBException {
    try{
    UsineConnection uneUsineConnection = new UsineConnection();
    connectionBanqueDebit =
      uneUsineConnection.getConnectionFromDataSource("jdbc/ora9igodinCoreDS");
    connectionBanqueCredit =
      uneUsineConnection.getConnectionFromDataSource("jdbc/ora9igodinCoreDS");
    }
    catch(Exception lException){
      throw new EJBException(lException);
    }
  }

  void fermerConnections() throws EJBException {
    try{
    connectionBanqueDebit.close();
    connectionBanqueCredit.close();
    }
    catch(Exception lException){
      throw new EJBException(lException);
    }
  }
}