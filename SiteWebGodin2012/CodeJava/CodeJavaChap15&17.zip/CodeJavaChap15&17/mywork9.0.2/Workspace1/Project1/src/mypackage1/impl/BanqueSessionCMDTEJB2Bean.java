package mypackage1.impl;
import javax.ejb.*;
import java.sql.Connection;
import java.util.*;
import java.lang.*;
import javax.naming.*;
import mypackage1.*;

public class BanqueSessionCMDTEJB2Bean implements SessionBean 
{
  private SessionContext sessionContext;

  public void ejbCreate() {}

  public void ejbActivate() {}

  public void ejbPassivate(){}

  public void ejbRemove(){}

  public void setSessionContext(SessionContext ctx){
    this.sessionContext = ctx;
  }

  public void transferer(int noCompteADebiter, int noCompteACrediter, double montant)
  throws EJBException{
      // Cr�er l'objet EJB local (stub RMI)
    Hashtable env = new Hashtable();
    env.put(Context.INITIAL_CONTEXT_FACTORY, "com.evermind.server.rmi.RMIInitialContextFactory");
    env.put(Context.SECURITY_PRINCIPAL, "admin");
    env.put(Context.SECURITY_CREDENTIALS, "welcome");
    env.put(Context.PROVIDER_URL, "ormi://localhost:23893/current-workspace-app");
    try{
      Context ctx = new InitialContext(env);
      CompteEJBHome compteEJBHome =
        (CompteEJBHome)ctx.lookup("CompteEJB");
      CompteEJB compteADebiter = compteEJBHome.findByPrimaryKey(new CompteEJBPK(noCompteADebiter));
      CompteEJB compteACrediter = compteEJBHome.findByPrimaryKey(new CompteEJBPK(noCompteACrediter));

      // Appel de m�thode sur l'objet EJB local
      compteADebiter.setSolde(compteADebiter.getSolde()-(long)montant);
      compteACrediter.setSolde(compteACrediter.getSolde()+(long)montant);
    }
    catch(Exception lException){
      throw new EJBException(lException);
    }
  }
}