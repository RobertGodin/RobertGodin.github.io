package mypackage1;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;

public interface Lignecommande extends EJBObject 
{
  long getNocommande() throws RemoteException;

  void setNocommande(long newNocommande) throws RemoteException;

  long getNoarticle() throws RemoteException;

  void setNoarticle(long newNoarticle) throws RemoteException;

  long getQuantit�() throws RemoteException;

  void setQuantit�(long newQuantit�) throws RemoteException;
}