package mypackage1;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;

public interface BanqueSessionCMDTEJB2Home extends EJBHome 
{
  BanqueSessionCMDTEJB2 create() throws RemoteException, CreateException;
}