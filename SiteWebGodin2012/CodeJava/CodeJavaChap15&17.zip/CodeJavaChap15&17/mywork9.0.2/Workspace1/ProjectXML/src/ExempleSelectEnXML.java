import java.sql.*;
import java.math.*;
import oracle.xml.sql.query.*;
import oracle.jdbc.*;
import oracle.jdbc.driver.*;

public class ExempleSelectEnXML
{
  public static void main(String args[]) throws Exception
  {
    UsineConnection uneUsineConnection = new UsineConnection();
    Connection uneConnection = uneUsineConnection.getConnectionSansAutoCommit(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:ora9i",
            "godin","oracle");

    // initialize the OracleXMLQuery
    OracleXMLQuery qry = 
    new OracleXMLQuery(uneConnection,"SELECT * FROM Commande" );

    // structure the generated XML document
//    qry.setMaxRows(10);  // set the maximum number of rows to be returned
//    qry.setRowsetTag("catalogue"); // set the root document tag
//    qry.setRowTag("plant"); // sets the row separator tag
//    qry.setStyleSheet("emp.xsl"); // sets the stylesheet
    
    // get the XML document in string format
    String xmlString = qry.getXMLString();
    
    // print out the XML document
    System.out.println(" OUTPUT IS:\n"+xmlString); 
  }
}
