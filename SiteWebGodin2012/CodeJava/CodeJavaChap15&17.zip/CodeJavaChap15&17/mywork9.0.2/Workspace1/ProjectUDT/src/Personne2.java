import java.sql.*;
import java.io.*;

public class Personne2 implements SQLData {
    // nomUDT contient le nom du UDT qui correspond � la classe
    private String nomUDT = "GODIN.PERSONNE2SQLJ2UDT";
    protected String nom;
    protected String pr�nom;

    public Personne2(){}
    public Personne2(String nom,String pr�nom) {
        this.nom = nom;
        this.pr�nom = pr�nom;
    }
    public String getNom(){return nom;}
    public String getPr�nom(){return pr�nom;}
    public void setNom(String nom){this.nom = nom;}
    public void setPr�nom(String pr�nom){this.pr�nom = pr�nom;}

    public String getPr�nomNom(){
      return pr�nom + " " + nom;
    }

  // M�thodes de l'interface SQLdata � impl�menter

  // Retourne le UDT SQL qui correspond � la classe Java
  public String getSQLTypeName() throws SQLException { return nomUDT; } 

  // M�thode de conversion du stream en valeurs d'attributs
  public void readSQL(SQLInput stream, String nomUDT) throws SQLException { 
    this.nomUDT = nomUDT; 
    nom = stream.readString();
    pr�nom = stream.readString(); 
  } 

  // Conversion des valeurs d'attributs en stream
  public void writeSQL(SQLOutput stream) throws SQLException { 
    stream.writeString (nom); 
    stream.writeString (pr�nom); 
  }
}
