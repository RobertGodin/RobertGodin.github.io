// Exemple d'acc�s aux UDT (relationnel-objet) par la classe STRUCT
import java.sql.*;
import java.util.*;
import oracle.sql.*;
import oracle.jdbc.*;
import java.math.*;

public class ExempleUDTEnStruct 
{
  public static void main (String args []) throws Exception {
    // Cr�ation d'une Connection globale pour l'application
    UsineConnection uneUsineConnection = new UsineConnection();
    Connection uneConnection = uneUsineConnection.getConnectionSansAutoCommit(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:ora9i",
            "godin","oracle");
    try{
        // Recherche de la r�f�rence au LivreType ISBN = '0-201-12227-8'
        PreparedStatement unPreparedStatement = uneConnection.prepareStatement
        ("SELECT REF(l) AS refLivre FROM Livre l WHERE l.ISBN = '0-201-12227-8'");
        ResultSet unResultSet = unPreparedStatement.executeQuery();
        
        if (unResultSet.next()){
          // Conversion de la r�f�rence � l'UDT LivreType sous forme d'un objet Java REF
          REF ref = (REF) unResultSet.getObject(1);

          // Extraire l'objet LivreType r�f�renc� sous forme d'un STRUCT
          STRUCT unLivreSTRUCT = (STRUCT) ref.getValue();

          // Recherche des attributs du UDT LivreType sous forme d'un tableau d'objets
          Object attributsDeLivre[] = unLivreSTRUCT.getAttributes();

          // Cast des attributs selon leur type 
          System.out.println("ISBN :"+(String)attributsDeLivre[0]); // ISBN CHAR(13)
          System.out.println("titre :"+(String)attributsDeLivre[1]); // titre VARCHAR(50)

          // L'attribut ann�eParution est un UDT extrait en STRUCT
          STRUCT uneAnn�eParutionSTRUCT = (STRUCT) attributsDeLivre[2]; // ann�eParution TypeDonn�esAnn�e
          Object attributsDeAnn�eParution[] = uneAnn�eParutionSTRUCT.getAttributes();
          System.out.println((BigDecimal)attributsDeAnn�eParution[0]); // valeurAnn�e INTEGER

          // L'attribut �diteur est un REF � EditeurType
          REF refEditeur = (REF)attributsDeLivre[3]; // �diteur REF EditeurType

          // Extraire le l'objet EditeurType r�f�renc� sous forme de STRUCT
          STRUCT unEditeurSTRUCT = (STRUCT) refEditeur.getValue();

          // Recherche des attributs du UDT EditeurType
          Object attributsDeEditeur[] = unEditeurSTRUCT.getAttributes();
          System.out.println("nomEditeur :"+(String)attributsDeEditeur[0]); // nomEditeur VARCHAR(20)
          System.out.println("ville :"+(String)attributsDeEditeur[1]); // ville VARCHAR(20)

          // Suivre les r�f�rences inverses
          // L'attribut lesLivres est une table ench�ss�e extraite sous forme d'ARRAY
          ARRAY laTableEnchasse =  (ARRAY)attributsDeEditeur[2]; //lesLivres tableRefLivresType

          // Extraire les �l�ments sous forme de tableau d'objets
          Object[] lesLivres = (Object[])laTableEnchasse.getArray();

          // Parcours de la table ench�ss�e
          for (int i=0; i<lesLivres.length;i++){
            // Chacun des �l�ments de la table ench�ss�e est un UDT LivreRefType converti en STRUCT
            STRUCT unREFLivreStruct = (STRUCT) lesLivres[i];
            Object attributsDeREFLivreStruct[] = unREFLivreStruct.getAttributes();
            REF refLivre = (REF)attributsDeREFLivreStruct[0]; // livreRef REF LivreType

          // Extraire l'objet LivreType r�f�renc� sous forme d'un STRUCT
            STRUCT unAutreLivreSTRUCT = (STRUCT) refLivre.getValue();

          // Recherche des attributs du UDT
          Object attributsDeAutreLivre[] = unAutreLivreSTRUCT.getAttributes();

          // Cast des attributs selon leur type 
          System.out.println("ISBN :"+(String)attributsDeAutreLivre[0]); // ISBN CHAR(13)
          System.out.println("titre :"+(String)attributsDeAutreLivre[1]); // titre VARCHAR(50)        
          }       
        }else{
            throw new Exception("Livre inexistant");
        }
    }
    catch(Exception lException){
            lException.printStackTrace();
    }
    finally{
            uneConnection.commit();
            uneConnection.close();
            System.exit(0);
    }
  }
}