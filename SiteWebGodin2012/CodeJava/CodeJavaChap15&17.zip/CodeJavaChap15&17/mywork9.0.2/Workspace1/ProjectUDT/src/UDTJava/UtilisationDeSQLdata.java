import java.sql.*;
import javax.swing.JOptionPane;
import java.util.*;
import oracle.sql.*;
import oracle.jdbc.*;

public class UtilisationDeSQLdata 
{
  public static void main (String args []) throws Exception {
    // Cr�ation d'une Connection globale pour l'application
    UsineConnection uneUsineConnection = new UsineConnection();
    Connection uneConnection = uneUsineConnection.getConnectionSansAutoCommit(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:ora9i",
            "godin","oracle");
    try{
        
/*        PreparedStatement unPreparedStatement = uneConnection.prepareStatement
        ("SELECT l.ann�eParution FROM Livre l WHERE l.ISBN = '0-201-12227-8'");
        ResultSet unResultSet = unPreparedStatement.executeQuery();

        //Cr�er un type map qui associe le UDT � la classe SQLdata
        java.util.Map typeMap = uneConnection.getTypeMap();
        typeMap.put("Typedonn�esann�e",Class.forName("Typedonn�esann�e"));
        
        if (unResultSet.next()){
//           Typedonn�esann�e unTypedonn�esann�e = (Typedonn�esann�e)unResultSet.getObject(1);
           Object unObject = (Object)unResultSet.getObject(1);
          Typedonn�esann�e unTypedonn�esann�e = (Typedonn�esann�e)unObject;
          
           System.out.println(unTypedonn�esann�e.getValeurann�e());
        }else{
            throw new Exception("Livre inexistant");
        }
*/


        PreparedStatement unPreparedStatement = uneConnection.prepareStatement
        ("SELECT REF(l) AS refLivre FROM Livre l WHERE l.ISBN = '0-201-12227-8'");
        ResultSet unResultSet = unPreparedStatement.executeQuery();

        //Cr�er un type map qui associe le UDT � la classe SQLdata
/*        java.util.Map typeMap = uneConnection.getTypeMap();
        typeMap.put("LivreType",Class.forName("LivreType"));*/
        
        if (unResultSet.next()){
//           LivreType unLivreType = (LivreType)unResultSet.getObject(1);
//            REF ref = (REF)unResultSet.getObject(1);
//           System.out.println(unLivreType.getTitre());

          // Conversion de la r�f�rence � l'UDT sous forme d'un objet Java REF
          REF ref = (REF) unResultSet.getObject(1);

//          LivreType unLivreType = (LivreType)ref.getValue();

          // Extraction de l'objet r�f�renc� sous forme d'un STRUCT
          STRUCT unLivreSTRUCT = (STRUCT) ref.getValue();

          // Recherche des attributs du UDT sous forme d'un tableau d'objets
          Object attributs[] = unLivreSTRUCT.getAttributes();

          // Cast des attributs selon leur type 
          System.out.println((String)attributs[0]); // ISBN CHAR(13)
          System.out.println((String)attributs[1]); // titre VARCHAR(50)
//          System.out.println((Typedonn�esann�e)attributs[2]); // ann�eParution TypeDonn�esAnn�e
          System.out.println((REF)attributs[3]); // REF EditeurType
          
        }else{
            throw new Exception("Livre inexistant");
        }
    }
    catch(Exception lException){
            JOptionPane.showMessageDialog(null,lException.getMessage());
            lException.printStackTrace();
    }
    finally{
            uneConnection.commit();
            uneConnection.close();
            System.exit(0);
    }
  }
}