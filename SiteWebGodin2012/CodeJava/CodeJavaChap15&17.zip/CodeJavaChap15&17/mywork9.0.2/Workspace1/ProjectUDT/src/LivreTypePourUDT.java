import java.sql.*;
import java.io.*;
import java.math.*;
import java.lang.*;

public class LivreTypePourUDT implements SQLData {

    // nomUDT contient le nom du UDT qui correspond � la classe
    private String nomUDT = "GODIN.LIVRETYPE";
    protected String ISBN;
    protected String titre;
    protected Typedonn�esann�e ann�eParution;
    protected java.sql.Ref �diteur; 

  public LivreTypePourUDT(){}

  // Lecteurs et modifieurs
  public String getIsbn(){ return ISBN; }
  public void setIsbn(String isbn){ this.ISBN = isbn; }

  public String getTitre(){ return titre; }
  public void setTitre(String titre){ this.titre = titre; }

  public Typedonn�esann�e getAnn�eparution(){ return ann�eParution; }
  public void setAnn�eparution(Typedonn�esann�e ann�eparution)
  { this.ann�eParution = ann�eparution; }

  public java.sql.Ref get�diteur(){ return �diteur; }
  public void set�diteur(java.sql.Ref �diteur){ this.�diteur = �diteur; }

  // M�thode de service
  public oracle.sql.NUMBER getLengthTitre(){ return new oracle.sql.NUMBER(titre.length());}

//  public int getLengthTitre(){ return titre.length();}
  public String getTitreEnMinuscules(){return titre.toLowerCase();}

  // M�thodes de l'interface SQLdata � impl�menter

  // Retourne le UDT SQL qui correspond � la classe Java
  public String getSQLTypeName() throws SQLException { return nomUDT;} 

  public void readSQL(SQLInput stream, String type)
  throws SQLException{
      setIsbn(stream.readString());
      setTitre(stream.readString());
      setAnn�eparution((Typedonn�esann�e)stream.readObject());
      set�diteur(stream.readRef());
  }
  public void writeSQL(SQLOutput stream)
  throws SQLException{
      stream.writeString(getIsbn());
      stream.writeString(getTitre());
      stream.writeObject(getAnn�eparution());
      stream.writeRef(get�diteur());
  }
}
