import java.sql.*;
import javax.swing.JOptionPane;
import java.util.*;
import UDTJava.UsineConnection;

public class UtilisationDeTypeSQLJ 
{
  public static void main (String args []) throws Exception {
    // Cr�ation d'une Connection globale pour l'application
    UsineConnection uneUsineConnection = new UsineConnection();
    Connection uneConnection = uneUsineConnection.getConnectionSansAutoCommit(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:ora9i",
            "godin","oracle");
    try{
      // Cr�er un objet Java  
      Personne2 unePersonne = new Personne2("Gauguin","Paul"); 
      PreparedStatement unPreparedStatement = uneConnection.prepareStatement
        ("INSERT INTO TableDePersonnes VALUES(7,?)");

      // Passer l'objet Java directement comme valeur de la colonne
      unPreparedStatement.setObject(1,unePersonne);
      unPreparedStatement.executeUpdate();

      // Selectionner la colonne du UDT
      unPreparedStatement = uneConnection.prepareStatement
        ("SELECT donn�esPersonne FROM TableDePersonnes");

      ResultSet unResultSet = unPreparedStatement.executeQuery();
      while (unResultSet.next()){
        // Extraire directement le valeur du UDT sous forme d'objet Java
        Personne2 laPersonne2 = (Personne2) unResultSet.getObject(1);
        System.out.println(laPersonne2.getPr�nomNom());
      }
    }
    catch(Exception lException){
            JOptionPane.showMessageDialog(null,lException.getMessage());
            lException.printStackTrace();
    }
    finally{
            uneConnection.commit();
            uneConnection.close();
            System.exit(0);
    }
  }
}