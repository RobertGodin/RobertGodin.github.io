package GererPretSA.impl;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import java.sql.Date;
import GererPretSA.*;
import java.sql.Connection;
import java.util.*;

public class FacadeEnrPretSimpleSessionEJBBean implements SessionBean 
{
  public void ejbCreate()
  {
  }

  public void ejbActivate()
  {
  }

  public void ejbPassivate()
  {
  }

  public void ejbRemove()
  {
  }

  public void setSessionContext(SessionContext ctx)
  {
  }

  public Date insererPretEnCours(String idUtilisateur, String idExemplaire) throws Exception
  {
    UsineConnection uneUsineConnection = new UsineConnection();
    Connection uneConnection = 
      uneUsineConnection.getConnectionFromDataSource("jdbc/ora9icleratsaCoreDS");

    Utilisateur unUtilisateur = new Utilisateur(idUtilisateur);
    Exemplaire unExemplaire = new Exemplaire(idExemplaire);
        
    // Generer la date du jour et l'objet PretEnCours
    Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
    java.sql.Date dateMaintenant = new java.sql.Date(maintenant.getTime().getTime());

    PretEnCours leNouveauPretEnCours = 
            new PretEnCours(unUtilisateur,dateMaintenant,unExemplaire);

    // Materialiser le PretEnCours dans la BD
    CourtierBDPretEnCours unCourtierBDPretEnCours = 
                new CourtierBDPretEnCours(uneConnection);
    unCourtierBDPretEnCours.insererPretEnCours(leNouveauPretEnCours);
    // Pas besoin de commit
    uneConnection.close();
    return dateMaintenant;
  }
}