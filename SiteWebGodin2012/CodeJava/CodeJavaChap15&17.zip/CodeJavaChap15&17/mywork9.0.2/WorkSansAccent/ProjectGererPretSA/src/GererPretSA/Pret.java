package GererPretSA;
import java.sql.Date;
public class Pret {
    protected Utilisateur lUtilisateur;
    protected java.sql.Date datePret;
    protected Exemplaire lExemplaire;

    public Pret(Utilisateur lUtilisateur,java.sql.Date datePret, Exemplaire lExemplaire) {
        this.lUtilisateur = lUtilisateur;
        this.datePret = datePret;
        this.lExemplaire = lExemplaire;
    }
    public java.sql.Date getDatePret(){return datePret;}
    public String getIdExemplaire(){return lExemplaire.getIdExemplaire();}
    public String getIdUtilisateur(){return lUtilisateur.getIdUtilisateur();}
}