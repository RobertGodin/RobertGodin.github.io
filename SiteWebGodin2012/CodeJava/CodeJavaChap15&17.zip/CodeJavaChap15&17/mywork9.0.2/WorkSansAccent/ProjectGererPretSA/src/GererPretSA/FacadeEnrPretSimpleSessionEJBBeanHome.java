package GererPretSA;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;

public interface FacadeEnrPretSimpleSessionEJBBeanHome extends EJBHome 
{
  FacadeEnrPretSimpleSessionEJBBean create() throws RemoteException, CreateException;
}