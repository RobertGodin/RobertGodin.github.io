package GererPretSA;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class ServletEnregistrerPretsSimpleFacade extends HttpServlet {

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    //Chercher le param�tre idUtilisateur de la FORM HTML et cr�er un Utilisateur
    String idUtilisateur = "";
    try { idUtilisateur = request.getParameter("idUtilisateur"); }
    catch (Exception e) { e.printStackTrace(); }
    
    //Chercher le param�tre idExemplaire de la FORM HTML et cr�er un Exemplaire
    String idExemplaire = "";
    try { idExemplaire = request.getParameter("idExemplaire"); }
    catch (Exception e) { e.printStackTrace(); }

    // Entete de la page de r�ponse HTML
    response.setContentType("text/html");
    OutputStreamWriter unOutputStreamWriter =
      new OutputStreamWriter(response.getOutputStream());
    PrintWriter out = new PrintWriter(unOutputStreamWriter);
    out.println("<html>");
    out.println("<head><title>R�ponse de ServletEnregistrerPretsSimpleFacadeEJB</title></head>");
    out.println("<body>");

    FacadeEnregistrerPretsSimple uneFacadeEnregistrerPretsSimple = null;
    try{
    uneFacadeEnregistrerPretsSimple = new FacadeEnregistrerPretsSimple();
    // Enregistrer le pret en passant par la fa�ade
    java.sql.Date datePret = 
        uneFacadeEnregistrerPretsSimple.insererPretEnCours(idUtilisateur,idExemplaire);
    // Message de confirmation du pret
      out.println("Pret de l'exemplaire " + idExemplaire +
        " � l'utilisateur " + idUtilisateur + " confirme.<br>Date :" + datePret);
    }
    catch(Exception lException){
      out.println(lException.getMessage());
      lException.printStackTrace();
    }
    finally{
      try{
        // Fin de la page HTML
        out.println("</body></html>");
        out.close();
      }
      catch(Exception lException){
        lException.printStackTrace();
      }
    }
  }
}