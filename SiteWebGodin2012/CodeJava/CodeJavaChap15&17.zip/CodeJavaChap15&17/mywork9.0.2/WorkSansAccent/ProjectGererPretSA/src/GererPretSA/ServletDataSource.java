package GererPretSA;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;
import javax.naming.*;
import javax.sql.*;

public class ServletDataSource extends HttpServlet {

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    //Chercher le parametre idUtilisateur de la FORM HTML et creer un Utilisateur
    String idUtilisateur = "";
    try { idUtilisateur = request.getParameter("idUtilisateur"); }
    catch (Exception e) { e.printStackTrace(); }
    Utilisateur unUtilisateur = new Utilisateur(idUtilisateur);
    
    //Chercher le parametre idExemplaire de la FORM HTML et creer un Exemplaire
    String idExemplaire = "";
    try { idExemplaire = request.getParameter("idExemplaire"); }
    catch (Exception e) { e.printStackTrace(); }
    Exemplaire unExemplaire = new Exemplaire(idExemplaire);

    // Entete de la page de reponse HTML
    response.setContentType("text/html");
    OutputStreamWriter unOutputStreamWriter =
      new OutputStreamWriter(response.getOutputStream());
    PrintWriter out = new PrintWriter(unOutputStreamWriter);
    out.println("<html>");
    out.println("<head><title>Reponse de ServletEnregistrerPrets</title></head>");
    out.println("<body>");

    UsineConnection uneUsineConnection = new UsineConnection();
    Connection uneConnection = null;
    try{
      // Ouvrir une Connection en passant par un DataSource
        uneConnection = uneUsineConnection.getConnectionFromConnectionPoolDataSource("jdbc/ora9icleratPooledDS");

      // Generer la date du jour et l'objet PretEnCours
      Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
      java.sql.Date dateMaintenant = new java.sql.Date(maintenant.getTime().getTime());
      PretEnCours leNouveauPretEnCours =
        new PretEnCours(unUtilisateur,dateMaintenant,unExemplaire);

      // Materialiser le PretEnCours dans la BD
      CourtierBDPretEnCours unCourtierBDPretEnCours =
          new CourtierBDPretEnCours(uneConnection);
      unCourtierBDPretEnCours.insererPretEnCours(leNouveauPretEnCours);

      // Message de confirmation du pret
      out.println("Pret de l'exemplaire " + idExemplaire +
        " � l'utilisateur " + idUtilisateur + " confirme.<br>Date :" + dateMaintenant);
    }
    catch(Exception lException){
      out.println(lException.getMessage());
      lException.printStackTrace();
    }
    finally{
      try{
        // Fin de la page HTML
        out.println("</body></html>");
        out.close();
        // Pas besoin de commit
        uneConnection.close();
      }
      catch(Exception lException){
        lException.printStackTrace();
      }
    }
  }
}