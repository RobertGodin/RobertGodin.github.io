package GererPretSA;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;

public interface FacadeEnrPretsCMTSessionEJBHome extends EJBHome 
{
  FacadeEnrPretsCMTSessionEJB create() throws RemoteException, CreateException;
}