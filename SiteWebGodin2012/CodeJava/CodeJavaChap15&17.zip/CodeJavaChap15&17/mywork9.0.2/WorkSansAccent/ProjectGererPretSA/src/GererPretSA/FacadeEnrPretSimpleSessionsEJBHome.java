package GererPretSA;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;

public interface FacadeEnrPretSimpleSessionsEJBHome extends EJBHome 
{
  FacadeEnrPretSimpleSessionsEJB create() throws RemoteException, CreateException;
}