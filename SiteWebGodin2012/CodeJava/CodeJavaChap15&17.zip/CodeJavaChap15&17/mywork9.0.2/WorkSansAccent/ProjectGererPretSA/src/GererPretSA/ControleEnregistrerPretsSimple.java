package GererPretSA;
/* Classe de contr�le simple pour EnregistrerPrets
 * Interface � l'utilisateur minimaliste
 * NB Pas de v�rification des conditions pr�alabales dans le programme client
 */
import java.sql.*;
import javax.swing.JOptionPane;
import java.util.*;

class ControleEnregistrerPretsSimple {
    public static void main (String args []) throws Exception {
        // Chercher la Connection (mode autocommit)
        UsineConnection uneUsineConnection = new UsineConnection();
        Connection uneConnection = uneUsineConnection.getConnection(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:ora9i",
            "cleratsa","oracle");

        String idUtilisateur = 
            JOptionPane.showInputDialog("Entrez l'identificateur de l'utilisateur: ");
        Utilisateur unUtilisateur = new Utilisateur(idUtilisateur);
        String idExemplaire = 
            JOptionPane.showInputDialog("Entrez l'identificateur de l'exemplaire:");
        Exemplaire unExemplaire = new Exemplaire(idExemplaire);
        
        // G�n�rer la date du jour et l'objet PretEnCours
        Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
        java.sql.Date dateMaintenant = new java.sql.Date(maintenant.getTime().getTime());
        PretEnCours leNouveauPretEnCours = 
            new PretEnCours(unUtilisateur,dateMaintenant,unExemplaire);

        // Mat�rialiser le PretEnCours dans la BD
        try{
            CourtierBDPretEnCours unCourtierBDPretEnCours = 
                new CourtierBDPretEnCours(uneConnection);
            unCourtierBDPretEnCours.insererPretEnCours(leNouveauPretEnCours);

            JOptionPane.showMessageDialog(null,
            "Pret de l'exemplaire " + idExemplaire +
            " � l'utilisateur " + idUtilisateur + " confirme.\nDate:" + dateMaintenant);
        }
        catch(Exception lException){
            JOptionPane.showMessageDialog(null,lException.getMessage());
            lException.printStackTrace();
        }
        finally{
            // Pas besoin de commit
            uneConnection.close();
            System.exit(0);
        }
    }
}