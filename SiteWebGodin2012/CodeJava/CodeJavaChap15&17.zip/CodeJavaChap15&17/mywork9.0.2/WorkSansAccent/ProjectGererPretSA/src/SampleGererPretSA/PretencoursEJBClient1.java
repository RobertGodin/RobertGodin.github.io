package SampleGererPretSA;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import GererPretSA.PretencoursEJB;
import GererPretSA.PretencoursEJBHome;
import java.util.Collection;
import java.util.Iterator;

public class PretencoursEJBClient1 
{
  public static void main(String [] args)
  {
    PretencoursEJBClient1 pretencoursEJBClient1 = new PretencoursEJBClient1();
    try
    {
      Hashtable env = new Hashtable();
      env.put(Context.INITIAL_CONTEXT_FACTORY, "com.evermind.server.rmi.RMIInitialContextFactory");
      env.put(Context.SECURITY_PRINCIPAL, "admin");
      env.put(Context.SECURITY_CREDENTIALS, "welcome");
      env.put(Context.PROVIDER_URL, "ormi://localhost:23893/current-workspace-app");
      Context ctx = new InitialContext(env);
      PretencoursEJBHome pretencoursEJBHome = (PretencoursEJBHome)ctx.lookup("PretencoursEJB");
      PretencoursEJB pretencoursEJB;

      // Use one of the create() methods below to create a new instance
      // pretencoursEJB = pretencoursEJBHome.create(  );
      // pretencoursEJB = pretencoursEJBHome.create( java.lang.String idexemplaire, java.sql.Date datepret, java.lang.String idutilisateur );

      // Retrieve all instances using the findAll() method
      // (CMP Entity beans only)
      Collection coll = pretencoursEJBHome.findAll();
      Iterator iter = coll.iterator();
      while (iter.hasNext())
      {
        pretencoursEJB = (PretencoursEJB)iter.next();
        System.out.println("idexemplaire = " + pretencoursEJB.getIdexemplaire());
        System.out.println("datepret = " + pretencoursEJB.getDatepret());
        System.out.println("idutilisateur = " + pretencoursEJB.getIdutilisateur());
        System.out.println();
      }

      // Call any of the Remote methods below to access the EJB
      // pretencoursEJB.getIdexemplaire(  );
      // pretencoursEJB.setIdexemplaire( java.lang.String newIdexemplaire );
      // pretencoursEJB.getDatepret(  );
      // pretencoursEJB.setDatepret( java.sql.Date newDatepret );
      // pretencoursEJB.getIdutilisateur(  );
      // pretencoursEJB.setIdutilisateur( java.lang.String newIdutilisateur );
    }
    catch(Throwable ex)
    {
      ex.printStackTrace();
    }

  }
}