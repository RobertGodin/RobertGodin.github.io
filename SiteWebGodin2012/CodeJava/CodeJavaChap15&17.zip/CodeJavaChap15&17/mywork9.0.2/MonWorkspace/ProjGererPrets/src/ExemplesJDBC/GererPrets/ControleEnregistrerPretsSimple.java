package ExemplesJDBC.GererPrets;
/* Classe de contr�le simple pour EnregistrerPr�ts
 * Interface � l'utilisateur minimaliste
 * NB Pas de v�rification des conditions pr�alabales dans le programme client
 */
import java.sql.*;
import javax.swing.JOptionPane;
import java.util.*;

class ControleEnregistrerPretsSimple {
    public static void main (String args []) throws Exception {
        // Chercher la Connection (mode autocommit)
        UsineConnection uneUsineConnection = new UsineConnection();
        Connection uneConnection = uneUsineConnection.getConnection(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:ora9i",
            "clerat","oracle");

        String idUtilisateur = 
            JOptionPane.showInputDialog("Entrez l'identificateur de l'utilisateur: ");
        Utilisateur unUtilisateur = new Utilisateur(idUtilisateur);
        String idExemplaire = 
            JOptionPane.showInputDialog("Entrez l'identificateur de l'exemplaire:");
        Exemplaire unExemplaire = new Exemplaire(idExemplaire);
        
        // G�n�rer la date du jour et l'objet Pr�tEnCours
        Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
        java.sql.Date dateMaintenant = new java.sql.Date(maintenant.getTime().getTime());
        Pr�tEnCours leNouveauPr�tEnCours = 
            new Pr�tEnCours(unUtilisateur,dateMaintenant,unExemplaire);

        // Mat�rialiser le Pr�tEnCours dans la BD
        try{
            CourtierBDPr�tEnCours unCourtierBDPr�tEnCours = 
                new CourtierBDPr�tEnCours(uneConnection);
            unCourtierBDPr�tEnCours.ins�rerPr�tEnCours(leNouveauPr�tEnCours);

            JOptionPane.showMessageDialog(null,
            "Pr�t de l'exemplaire " + idExemplaire +
            " � l'utilisateur " + idUtilisateur + " confirm�.\nDate:" + dateMaintenant);
        }
        catch(Exception lException){
            JOptionPane.showMessageDialog(null,lException.getMessage());
            lException.printStackTrace();
        }
        finally{
            // Pas besoin de commit
            uneConnection.close();
            System.exit(0);
        }
    }
}