package ExemplesJDBC.GererPrets;
import java.sql.*;
import java.util.*;

public class CourtierBDUtilisateur{
    private Connection uneConnection;
   
    // Constructeur pour connexion pass�e par le cr�ateur
    public CourtierBDUtilisateur(Connection laConnection){
        this.uneConnection = laConnection;
    }
    
    public void setConnection(Connection laConnection){
        this.uneConnection = laConnection;
    }
    
    public void chercherVariablesStatiquesDeMembre()
    // Extrait les valeurs actuelles de nbMaxPr�ts et dur�eMaxPr�ts
    throws Exception{
        // Initialiser les variables statiques de Membre
        PreparedStatement unEnonc�SQL = uneConnection.prepareStatement
        ("SELECT nbMaxPr�ts, dur�eMaxPr�ts FROM MembreG�n�ral FOR UPDATE");
        ResultSet r�sultatSelect = unEnonc�SQL.executeQuery();
        if (r�sultatSelect.next ()){
            Membre.setNbMaxPr�ts(r�sultatSelect.getInt ("nbMaxPr�ts"));
            Membre.setDur�eMaxPr�ts(r�sultatSelect.getInt ("dur�eMaxPr�ts"));
            unEnonc�SQL.close();
        }else{
            unEnonc�SQL.close();
            throw new Exception("table MembreG�n�ral corrompue");
        }
    }

    public Utilisateur chercherUtilisateurParIdUtilisateur(String idUtilisateur)
    // Retourne un objet Membre ou un Employ� selon le cas
    throws Exception {
        // Verrouillage de l'utilisateur pour s�rialisabilit� (Oracle mode READ COMMITTED)
        PreparedStatement unEnonc�SQL = uneConnection.prepareStatement
        ("SELECT motPasse,nom,pr�nom,cat�gorieUtilisateur,t�l�phoneR�sidence,codeMatricule,cat�gorieEmploy� "+
        "FROM Membre m, Utilisateur u, Employ� e WHERE u.idUtilisateur = ? AND "+
        "u.idUtilisateur = m.idUtilisateur (+) AND "+
        "u.idUtilisateur = e.idUtilisateur (+) FOR UPDATE");
        unEnonc�SQL.setString(1,idUtilisateur);
        ResultSet r�sultatSelect = unEnonc�SQL.executeQuery();
        if (r�sultatSelect.next ()){
            if (r�sultatSelect.getString ("cat�gorieUtilisateur").equals("membre")){
                Membre leMembre = new Membre(
                    idUtilisateur,r�sultatSelect.getString ("motPasse"),
                    r�sultatSelect.getString ("nom"),r�sultatSelect.getString ("pr�nom"),
                    r�sultatSelect.getString ("cat�gorieUtilisateur"),
                    r�sultatSelect.getString ("t�l�phoneR�sidence"));
                unEnonc�SQL.close();
                return leMembre;
            }
            else{// Pas un Membre, doit �tre un Employ�
                Employ� lEmploy� = new Employ�(idUtilisateur,r�sultatSelect.getString ("motPasse"),
                    r�sultatSelect.getString ("nom"),r�sultatSelect.getString ("pr�nom"),
                    r�sultatSelect.getString ("cat�gorieUtilisateur"),
                    r�sultatSelect.getString ("codeMatricule"),
                    r�sultatSelect.getString ("cat�gorieEmploy�")
                    );
                unEnonc�SQL.close();
                return lEmploy�;
            }
        } else {
            unEnonc�SQL.close();
            throw new Exception("Utilisateur non trouv� "+idUtilisateur);
        }
    }
}