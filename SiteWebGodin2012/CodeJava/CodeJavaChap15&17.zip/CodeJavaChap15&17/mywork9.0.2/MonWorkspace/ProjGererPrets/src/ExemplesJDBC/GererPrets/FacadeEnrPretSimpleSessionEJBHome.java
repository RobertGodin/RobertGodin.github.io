package ExemplesJDBC.GererPrets;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;

public interface FacadeEnrPretSimpleSessionEJBHome extends EJBHome 
{
  FacadeEnrPretSimpleSessionEJB create() throws RemoteException, CreateException;
}