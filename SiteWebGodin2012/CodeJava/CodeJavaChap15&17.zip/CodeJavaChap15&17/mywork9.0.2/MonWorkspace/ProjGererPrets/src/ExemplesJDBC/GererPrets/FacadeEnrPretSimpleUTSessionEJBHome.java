package ExemplesJDBC.GererPrets;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;

public interface FacadeEnrPretSimpleUTSessionEJBHome extends EJBHome 
{
  FacadeEnrPretSimpleUTSessionEJB create() throws RemoteException, CreateException;
}