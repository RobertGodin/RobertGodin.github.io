package ExemplesJDBC.GererPrets;
import java.io.Serializable;
public class OTDUtilisateurPrets implements Serializable
{
  private String categorie;
  private boolean conditionsPretAcceptees;
  private int nbPretsEnCours;
  private int nbMaxPrets;
  private int nbRetards;
  public OTDUtilisateurPrets() {}
  public OTDUtilisateurPrets(String categorie,boolean conditionsPretAcceptees,
   int nbPretsEnCours, int nbMaxPrets, int nbRetards) {
    this.categorie=categorie;
    this.conditionsPretAcceptees=conditionsPretAcceptees;
    this.nbPretsEnCours=nbPretsEnCours;
    this.nbMaxPrets=nbMaxPrets;
    this.nbRetards=nbRetards;
   }
   public String getCategorie(){return categorie;}
   public boolean conditionsPretAcceptees(){return conditionsPretAcceptees;}
   public int getNbPretsEnCours(){return nbPretsEnCours;}
   public int getNbMaxPrets(){return nbMaxPrets;}
   public int getNbRetards(){return nbRetards;}
}