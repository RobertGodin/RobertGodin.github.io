package ExemplesJDBC.GererPrets;
import javax.ejb.EJBObject;

public interface PretEnCoursEJB extends EJBObject 
{
}