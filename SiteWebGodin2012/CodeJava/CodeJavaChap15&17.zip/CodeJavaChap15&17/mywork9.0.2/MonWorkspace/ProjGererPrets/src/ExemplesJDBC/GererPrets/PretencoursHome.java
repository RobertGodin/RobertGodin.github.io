package ExemplesJDBC.GererPrets;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import java.util.Collection;

public interface PretencoursHome extends EJBHome 
{
  Pretencours create() throws RemoteException, CreateException;

  Pretencours create(String idexemplaire, String datepr�t, String idutilisateur) throws RemoteException, CreateException;

  Pretencours findByPrimaryKey(PretencoursPK primaryKey) throws RemoteException, FinderException;

  Collection findAll() throws RemoteException, FinderException;
}