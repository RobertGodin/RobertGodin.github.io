package ExemplesJDBC.GererPrets.impl;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import java.sql.Connection;
import ExemplesJDBC.GererPrets.*;
import java.sql.Date;
import java.util.*;

public class FacadeEnrPretsSessionEJBBean implements SessionBean 
{
  private Connection uneConnection;
  private Utilisateur unUtilisateur;
  private Exemplaire unExemplaire;
  private CourtierBDPr�tEnCours unCourtierBDPretEnCours;

  public void ejbCreate()throws Exception{}

  public void ejbActivate(){}

  public void ejbPassivate(){}

  public void ejbRemove(){}

  public void setSessionContext(SessionContext ctx) {
    try {
    UsineConnection uneUsineConnection = new UsineConnection();
    uneConnection = 
      uneUsineConnection.getConnectionFromDataSourceSansAutoCommit("jdbc/ora9icleratCoreDS");
    }
    catch(Exception lException){
      lException.printStackTrace();
    }
  }


  public OTDUtilisateurPrets chercherOTDUtilisateurPrets(String idUtilisateur) throws Exception
  {
    // Cr�ation du courtier et d�mat�rialisation de l'Utilisateur
    CourtierBDUtilisateur unCourtierBDUtilisateur = new CourtierBDUtilisateur(uneConnection);
    unUtilisateur = 
        unCourtierBDUtilisateur.chercherUtilisateurParIdUtilisateur(idUtilisateur);
        
    //Cr�ation du courtier et d�mat�rialisation des Pr�tsEnCours
    unCourtierBDPretEnCours = new CourtierBDPr�tEnCours(uneConnection);
    unCourtierBDPretEnCours.chercherLesPr�tsEnCours(unUtilisateur);

    // Retourner l'objet de transfert de donn�es OTDUtilisateurPrets
    if (unUtilisateur instanceof Membre){
      unCourtierBDUtilisateur.chercherVariablesStatiquesDeMembre();
      Membre unMembre = (Membre)unUtilisateur;
      return new OTDUtilisateurPrets(
                  unMembre.getCat�gorie(),
                  unMembre.conditionsPr�tAccept�es(),
                  unMembre.getNbPr�tsEnCours(),
                  Membre.getNbMaxPr�ts(),
                  unMembre.getNbRetards());
    } else {
      return new OTDUtilisateurPrets(
        unUtilisateur.getCat�gorie(),true,unUtilisateur.getNbPr�tsEnCours(),0,0);
    }
  }

  public String getStatutExemplaire(String idExemplaire) throws Exception{
    // Chercher l'exemplaire en passant par le courtier et retourner le statut
    CourtierBDExemplaire unCourtierBDExemplaire = new CourtierBDExemplaire(uneConnection);
    unExemplaire = unCourtierBDExemplaire.chercherExemplaireParIdExemplaire(idExemplaire);
    return unExemplaire.getStatut();
  }

  public Date insererPretEnCours() throws Exception  {
    Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
    java.sql.Date dateMaintenant = new java.sql.Date(maintenant.getTime().getTime());
    Pr�tEnCours leNouveauPr�tEnCours = 
          new Pr�tEnCours(unUtilisateur,dateMaintenant,unExemplaire);

    // Mat�rialiser le Pr�tEnCours dans la BD
    unCourtierBDPretEnCours.ins�rerPr�tEnCours(leNouveauPr�tEnCours);
    return dateMaintenant;
  }

  public void confirmerTransaction() throws Exception  {
    uneConnection.commit();
    uneConnection.close();
  }
}