package ExemplesJDBC.GererPrets;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;
import javax.ejb.SessionContext;
import java.sql.Date;

public interface FacadeEnrPretSimpleUTSessionEJB extends EJBObject 
{
  Date insererPretEnCours(String idUtilisateur, String idExemplaire) throws Exception, RemoteException;


}