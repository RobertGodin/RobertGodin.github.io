package ExemplesJDBC.GererPrets.impl;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import ExemplesJDBC.GererPrets.Pr�tEnCoursEJBPK;

public class Pr�tEnCoursEJBBean implements EntityBean 
{
  public EntityContext entityContext;
  public String idexemplaire;
  public String datepr�t;
  public String idutilisateur;

  public Pr�tEnCoursEJBPK ejbCreate()
  {
    return null;
  }

  public void ejbPostCreate()
  {
  }

  public Pr�tEnCoursEJBPK ejbCreate(String idexemplaire, String datepr�t, String idutilisateur)
  {
    this.idexemplaire = idexemplaire;
    this.datepr�t = datepr�t;
    this.idutilisateur = idutilisateur;
    return new Pr�tEnCoursEJBPK(idexemplaire);
  }

  public void ejbPostCreate(String idexemplaire, String datepr�t, String idutilisateur)
  {
  }

  public void ejbActivate()
  {
  }

  public void ejbLoad()
  {
  }

  public void ejbPassivate()
  {
  }

  public void ejbRemove()
  {
  }

  public void ejbStore()
  {
  }

  public void setEntityContext(EntityContext ctx)
  {
    this.entityContext = ctx;
  }

  public void unsetEntityContext()
  {
    this.entityContext = null;
  }

  public String getIdexemplaire()
  {
    return idexemplaire;
  }

  public void setIdexemplaire(String newIdexemplaire)
  {
    idexemplaire = newIdexemplaire;
  }

  public String getDatepr�t()
  {
    return datepr�t;
  }

  public void setDatepr�t(String newDatepr�t)
  {
    datepr�t = newDatepr�t;
  }

  public String getIdutilisateur()
  {
    return idutilisateur;
  }

  public void setIdutilisateur(String newIdutilisateur)
  {
    idutilisateur = newIdutilisateur;
  }
}