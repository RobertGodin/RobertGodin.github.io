package ExemplesJDBC.GererPrets;
import java.io.Serializable;

public class PretencoursPK implements Serializable 
{
  public String idexemplaire;

  public PretencoursPK()
  {
  }

  public PretencoursPK(String idexemplaire)
  {
    this.idexemplaire = idexemplaire;
  }

  public boolean equals(Object other)
  {
    // Add custom equals() impl here
    return super.equals(other);
  }

  public int hashCode()
  {
    // Add custom hashCode() impl here
    return super.hashCode();
  }
}