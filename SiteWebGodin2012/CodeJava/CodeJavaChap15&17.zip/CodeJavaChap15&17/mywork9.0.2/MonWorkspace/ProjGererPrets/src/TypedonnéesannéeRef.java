import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.REF;
import oracle.sql.STRUCT;

public class Typedonn�esann�eRef implements ORAData, ORADataFactory
{
  public static final String _SQL_BASETYPE = "GODIN.TYPEDONN�ESANN�E";
  public static final int _SQL_TYPECODE = OracleTypes.REF;

  REF _ref;

  private static final Typedonn�esann�eRef _Typedonn�esann�eRefFactory = new Typedonn�esann�eRef();

  public static ORADataFactory getORADataFactory()
  { return _Typedonn�esann�eRefFactory; }
  /* constructor */
  public Typedonn�esann�eRef()
  {
  }

  /* ORAData interface */
  public Datum toDatum(Connection c) throws SQLException
  {
    return _ref;
  }

  /* ORADataFactory interface */
  public ORAData create(Datum d, int sqlType) throws SQLException
  {
    if (d == null) return null;
    Typedonn�esann�eRef r = new Typedonn�esann�eRef();
    r._ref = (REF) d;
    return r;
  }

  public Typedonn�esann�e getValue() throws SQLException
  {
     return (Typedonn�esann�e) Typedonn�esann�e.getORADataFactory().create(
       _ref.getSTRUCT(), OracleTypes.REF);
  }

  public void setValue(Typedonn�esann�e c) throws SQLException
  {
    _ref.setValue((STRUCT) c.toDatum(_ref.getJavaSqlConnection()));
  }
}
