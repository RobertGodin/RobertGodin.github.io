package ExemplesJDBC.GererPrets;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import java.util.Collection;

public interface PretEnCoursEJBHome extends EJBHome 
{
  PretEnCoursEJB create() throws RemoteException, CreateException;

  PretEnCoursEJB findByPrimaryKey(PretEnCoursEJBPK primaryKey) throws RemoteException, FinderException;

  Collection findAll() throws RemoteException, FinderException;
}