package ExemplesJDBC.GererPrets;

import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import java.sql.SQLData;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;

public class Typedonn�esann�e implements SQLData
{
  public static final String _SQL_NAME = "GODIN.TYPEDONN�ESANN�E";
  public static final int _SQL_TYPECODE = OracleTypes.STRUCT;

  private int m_valeurann�e;

  /* constructor */
  public Typedonn�esann�e()
  {
  }

  public void readSQL(SQLInput stream, String type)
  throws SQLException
  {
      setValeurann�e(stream.readInt());
  }

  public void writeSQL(SQLOutput stream)
  throws SQLException
  {
      stream.writeInt(getValeurann�e());
  }

  public String getSQLTypeName() throws SQLException
  {
    return _SQL_NAME;
  }

  /* accessor methods */
  public int getValeurann�e()
  { return m_valeurann�e; }

  public void setValeurann�e(int valeurann�e)
  { m_valeurann�e = valeurann�e; }

}
