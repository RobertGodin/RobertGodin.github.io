package ExemplesJDBC.GererPrets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class ServletIdentificationUtilisateur extends HttpServlet {

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    //Chercher le param�tre idUtilisateur de la form
    String idUtilisateur = "";
    try { idUtilisateur = request.getParameter("idUtilisateur"); }
    catch (Exception e) { e.printStackTrace(); }

    // Cr�er un objet session si non existant
    HttpSession uneSession = request.getSession(true);

    // Ent�te de la page de r�ponse html
    response.setContentType("text/html");
    OutputStreamWriter unOutputStreamWriter = new OutputStreamWriter(response.getOutputStream());
    PrintWriter out = new PrintWriter(unOutputStreamWriter);
      out.println("<html>");
      out.println("<head><title>R�ponse de ServletIdentificationUtilisateur</title></head>");
      out.println("<body>");

    UsineConnection uneUsineConnection = new UsineConnection();
    Connection uneConnection = null;

    try{
      // Ouvrir une Connection
      uneConnection = uneUsineConnection.getConnectionSansAutoCommit(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:ora9i",
            "clerat","oracle");
      // D�mat�rialiser l'Utilisateur et ses Pr�tsEnCours
      Membre unMembre = null;

      // Cr�ation du courtier et d�mat�rialisation de l'Utilisateur
      CourtierBDUtilisateur unCourtierBDUtilisateur =
        new CourtierBDUtilisateur(uneConnection);
      Utilisateur unUtilisateur = unCourtierBDUtilisateur.chercherUtilisateurParIdUtilisateur(idUtilisateur);

      //Cr�ation du courtier et d�mat�rialisation des Pr�tsEnCours
      CourtierBDPr�tEnCours unCourtierBDPr�tEnCours =
        new CourtierBDPr�tEnCours(uneConnection);
      unCourtierBDPr�tEnCours.chercherLesPr�tsEnCours(unUtilisateur);

      // Affichage de l'idUtilisateur et du nombre de pr�ts
      out.println("Utilisateur :" + idUtilisateur);
      out.println(" Nombre de pr�ts en cours :" + unUtilisateur.getNbPr�tsEnCours()+"<br>");

      // V�rifier si les conditions pr�alables sont viol�es
      boolean conditionsAccept�es = false;
      if (unUtilisateur instanceof Membre){
        unCourtierBDUtilisateur.chercherVariablesStatiquesDeMembre();
        unMembre = (Membre)unUtilisateur;
        if (!unMembre.conditionsPr�tAccept�es()){
          out.println("Pr�t refus�.<br>Nb de pr�ts :" + unMembre.getNbPr�tsEnCours()+
                ". Maximum :" + Membre.getNbMaxPr�ts() +
                ". Nb de retards :" + unMembre.getNbRetards());
          // Lib�rer la Connection
          uneConnection.commit();
          uneConnection.close();
        }else {conditionsAccept�es = true;}
      }else{conditionsAccept�es = true;}// Pas de contrainte pour un employ�
      if(conditionsAccept�es){

        // Sauvegarder les objets du contexte de la session
        uneSession.setAttribute("uneConnection", uneConnection);
        uneSession.setAttribute("unUtilisateur", unUtilisateur);
        uneSession.setAttribute("unCourtierBDPr�tEnCours", unCourtierBDPr�tEnCours);


        // Construire la FORM pour saisir l'idExemplaire
        out.println("<form action = \"ServletIdentificationExemplaire\" method = \"post\">");
        out.println("<p>Entrez l'identifiant de l'exemplaire et cliquez Soumettre</p>");
        out.println("<input type = \"text\" name = \"idExemplaire\" />");
        out.println("<input type = \"submit\" value = \"Soumettre\" />");
        out.println("</form>");
      }
    }catch (Exception e) {
      out.println(e.getMessage());
      e.printStackTrace();
    }
    finally{
        out.println("</body></html>");
        out.close();
      // NB garder la connexion ouverte et ne pas terminer la transaction
    }
  }
}