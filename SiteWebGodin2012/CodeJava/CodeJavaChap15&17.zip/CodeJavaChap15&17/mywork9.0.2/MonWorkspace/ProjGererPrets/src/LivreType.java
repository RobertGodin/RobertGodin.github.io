import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;

public class LivreType implements ORAData, ORADataFactory
{
  public static final String _SQL_NAME = "GODIN.LIVRETYPE";
  public static final int _SQL_TYPECODE = OracleTypes.STRUCT;

  protected MutableStruct _struct;

  private static int[] _sqlType =  { 1,12,2002,2006 };
  private static ORADataFactory[] _factory = new ORADataFactory[4];
  static
  {
    _factory[2] = Typedonn�esann�e.getORADataFactory();
    _factory[3] = EditeurtypeRef.getORADataFactory();
  }
  protected static final LivreType _LivreTypeFactory = new LivreType(false);

  public static ORADataFactory getORADataFactory()
  { return _LivreTypeFactory; }
  /* constructor */
  protected LivreType(boolean init)
  { if(init) _struct = new MutableStruct(new Object[4], _sqlType, _factory); }
  public LivreType()
  { this(true); }

  /* ORAData interface */
  public Datum toDatum(Connection c) throws SQLException
  {
    return _struct.toDatum(c, _SQL_NAME);
  }

  /* ORADataFactory interface */
  public ORAData create(Datum d, int sqlType) throws SQLException
  { return create(null, d, sqlType); }
  protected ORAData create(LivreType o, Datum d, int sqlType) throws SQLException
  {
    if (d == null) return null; 
    if (o == null) o = new LivreType(false);
    o._struct = new MutableStruct((STRUCT) d, _sqlType, _factory);
    return o;
  }
  /* accessor methods */
  public String getIsbn() throws SQLException
  { return (String) _struct.getAttribute(0); }

  public void setIsbn(String isbn) throws SQLException
  { _struct.setAttribute(0, isbn); }


  public String getTitre() throws SQLException
  { return (String) _struct.getAttribute(1); }

  public void setTitre(String titre) throws SQLException
  { _struct.setAttribute(1, titre); }


  public Typedonn�esann�e getAnn�eparution() throws SQLException
  { return (Typedonn�esann�e) _struct.getAttribute(2); }

  public void setAnn�eparution(Typedonn�esann�e ann�eparution) throws SQLException
  { _struct.setAttribute(2, ann�eparution); }


  public EditeurtypeRef get�diteur() throws SQLException
  { return (EditeurtypeRef) _struct.getAttribute(3); }

  public void set�diteur(EditeurtypeRef �diteur) throws SQLException
  { _struct.setAttribute(3, �diteur); }

}
