package ExemplesJDBC.GererPrets;

import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import java.sql.SQLData;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;

public class Editeurtype implements SQLData
{
  public static final String _SQL_NAME = "GODIN.EDITEURTYPE";
  public static final int _SQL_TYPECODE = OracleTypes.STRUCT;

  private String m_nomediteur;
  private String m_ville;
  private java.sql.Array m_leslivres;

  /* constructor */
  public Editeurtype()
  {
  }

  public void readSQL(SQLInput stream, String type)
  throws SQLException
  {
      setNomediteur(stream.readString());
      setVille(stream.readString());
      setLeslivres(stream.readArray());
  }

  public void writeSQL(SQLOutput stream)
  throws SQLException
  {
      stream.writeString(getNomediteur());
      stream.writeString(getVille());
      stream.writeArray(getLeslivres());
  }

  public String getSQLTypeName() throws SQLException
  {
    return _SQL_NAME;
  }

  /* accessor methods */
  public String getNomediteur()
  { return m_nomediteur; }

  public void setNomediteur(String nomediteur)
  { m_nomediteur = nomediteur; }


  public String getVille()
  { return m_ville; }

  public void setVille(String ville)
  { m_ville = ville; }


  public java.sql.Array getLeslivres()
  { return m_leslivres; }

  public void setLeslivres(java.sql.Array leslivres)
  { m_leslivres = leslivres; }

}
