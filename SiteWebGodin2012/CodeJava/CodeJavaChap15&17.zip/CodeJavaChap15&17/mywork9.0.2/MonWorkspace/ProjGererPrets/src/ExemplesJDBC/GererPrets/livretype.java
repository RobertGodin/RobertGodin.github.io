package ExemplesJDBC.GererPrets;

import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import java.sql.SQLData;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;

public class livretype implements SQLData
{
  public static final String _SQL_NAME = "GODIN.LIVRETYPE";
  public static final int _SQL_TYPECODE = OracleTypes.STRUCT;

  private String m_isbn;
  private String m_titre;
  private Typedonn�esann�e m_ann�eparution;
  private java.sql.Ref m_�diteur;

  /* constructor */
  public livretype()
  {
  }

  public void readSQL(SQLInput stream, String type)
  throws SQLException
  {
      setIsbn(stream.readString());
      setTitre(stream.readString());
      setAnn�eparution((Typedonn�esann�e) stream.readObject());
      set�diteur(stream.readRef());
  }

  public void writeSQL(SQLOutput stream)
  throws SQLException
  {
      stream.writeString(getIsbn());
      stream.writeString(getTitre());
      stream.writeObject(getAnn�eparution());
      stream.writeRef(get�diteur());
  }

  public String getSQLTypeName() throws SQLException
  {
    return _SQL_NAME;
  }

  /* accessor methods */
  public String getIsbn()
  { return m_isbn; }

  public void setIsbn(String isbn)
  { m_isbn = isbn; }


  public String getTitre()
  { return m_titre; }

  public void setTitre(String titre)
  { m_titre = titre; }


  public Typedonn�esann�e getAnn�eparution()
  { return m_ann�eparution; }

  public void setAnn�eparution(Typedonn�esann�e ann�eparution)
  { m_ann�eparution = ann�eparution; }


  public java.sql.Ref get�diteur()
  { return m_�diteur; }

  public void set�diteur(java.sql.Ref �diteur)
  { m_�diteur = �diteur; }

}
