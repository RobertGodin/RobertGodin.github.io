package ExemplesJDBC.GererPrets;
import java.io.Serializable;

public class Pr�tEnCoursEJBPK implements Serializable 
{
  public String idexemplaire;

  public Pr�tEnCoursEJBPK()
  {
  }

  public Pr�tEnCoursEJBPK(String idexemplaire)
  {
    this.idexemplaire = idexemplaire;
  }

  public boolean equals(Object other)
  {
    // Add custom equals() impl here
    return super.equals(other);
  }

  public int hashCode()
  {
    // Add custom hashCode() impl here
    return super.hashCode();
  }
}