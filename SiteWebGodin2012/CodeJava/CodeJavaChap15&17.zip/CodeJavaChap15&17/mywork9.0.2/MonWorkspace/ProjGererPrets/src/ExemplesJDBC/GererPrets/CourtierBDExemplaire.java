package ExemplesJDBC.GererPrets;
import java.sql.*;
// La classe CourtierBDExemplaire est un interm�daire qui encapsule les interactions avec la BD
public class CourtierBDExemplaire {
    private Connection uneConnection;
   
    // Constructeur pour connexion pass�e par le cr�ateur
    public CourtierBDExemplaire(Connection laConnection){
        this.uneConnection = laConnection;
    }
    
    public void setConnection(Connection laConnection){
        this.uneConnection = laConnection;
    }

    public Exemplaire chercherExemplaireParIdExemplaire(String idExemplaire)
    // Ne consid�re pas les r�f�rences au Livre et aux Pr�ts
        throws Exception {
        // Verrouillage de l'exemplaire (FOR UPDATE)pour s�rialisabilit� 
        // (Oracle mode READ COMMITTED)
        PreparedStatement unEnonc�SQL = uneConnection.prepareStatement
        ("SELECT statut FROM Exemplaire WHERE idExemplaire = ? FOR UPDATE");
        unEnonc�SQL.setString(1,idExemplaire);
        ResultSet r�sultatSelect = unEnonc�SQL.executeQuery();
        if (r�sultatSelect.next()){
            Exemplaire unExemplaire = 
                new Exemplaire(
                    idExemplaire,
                    r�sultatSelect.getString("statut"));
            unEnonc�SQL.close();
            return unExemplaire;
        }else{
            unEnonc�SQL.close();
            throw new Exception("Exemplaire inexistant");
        }
    }
}