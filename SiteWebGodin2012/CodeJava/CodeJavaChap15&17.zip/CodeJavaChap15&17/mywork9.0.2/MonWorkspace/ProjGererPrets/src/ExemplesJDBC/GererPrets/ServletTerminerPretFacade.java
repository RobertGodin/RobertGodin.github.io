package ExemplesJDBC.GererPrets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class ServletTerminerPretFacade extends HttpServlet {

  public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    //Chercher le param�tre idUtilisateur de la form
    String idExemplaire = "";
    try { idExemplaire = request.getParameter("idExemplaire"); }
    catch (Exception e) { e.printStackTrace(); }

    // Chercher l'objet de la session en cours
    HttpSession uneSession = request.getSession(false);
    
    // Chercher les objets du contexte de la session en cours
    FacadeEnregistrerPrets uneFacadeEnregistrerPrets =
      (FacadeEnregistrerPrets)uneSession.getAttribute("uneFacadeEnregistrerPrets");
    String idUtilisateur = (String)uneSession.getAttribute("idUtilisateur");

    // Ent�te de la page de r�ponse html
    response.setContentType("text/html");
    OutputStreamWriter unOutputStreamWriter =
      new OutputStreamWriter(response.getOutputStream());
    PrintWriter out = new PrintWriter(unOutputStreamWriter);
      out.println("<html>");
      out.println("<head><title>R�ponse de ServletIdentificationExemplaire</title></head>");
      out.println("<body>");

    try{
        // V�rifier statut de l'exemplaire
        String statut = uneFacadeEnregistrerPrets.getStatutExemplaire(idExemplaire);
        if (statut.equals("disponible")){

          // Enregistrer le pr�t en passant par la fa�ade
          java.sql.Date datePret = 
            uneFacadeEnregistrerPrets.insererPretEnCours();

          out.println("Pr�t de l'exemplaire " + idExemplaire +
              " � l'utilisateur " + idUtilisateur + " confirm�.\nDate:" + datePret);
        }else{
            out.println("Exemplaire non disponible:"+idExemplaire);
        }
    }catch (Exception e) {
      out.println(e.getMessage());
      e.printStackTrace();
    }
    finally{
      try{
        out.println("</body></html>");
        out.close();
        uneFacadeEnregistrerPrets.confirmerTransaction();
      }
      catch(Exception lException){
        lException.printStackTrace();
      }
    }
  }
}