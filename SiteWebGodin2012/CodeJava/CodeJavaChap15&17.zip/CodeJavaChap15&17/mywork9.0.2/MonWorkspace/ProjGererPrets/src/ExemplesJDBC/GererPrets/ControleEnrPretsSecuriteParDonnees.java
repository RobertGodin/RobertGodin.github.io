package ExemplesJDBC.GererPrets;
/* Classe de contr�le simple pour EnregistrerPr�ts
 * S�curit� �par les donn�es�
 * Interface � l'utilisateur minimaliste
 * NB V�rifie les conditions de pr�t et le statut de l'exemplaire au niveau du programme client
 */
import java.sql.*;
import javax.swing.JOptionPane;
import java.util.*;

class ControleEnrPretsSecuriteParDonnees {
    public static void main (String args []) throws Exception {
        String idCommis = 
            JOptionPane.showInputDialog("Entrez l'identificateur du commis au pr�t: ");
        String motDePasse = 
            JOptionPane.showInputDialog("Entrez le mot de passe : ");

        // Cr�ation d'une Connection � partir du idCommis et de son motDePasse
        UsineConnection uneUsineConnection = new UsineConnection();
        Connection uneConnection = uneUsineConnection.getConnectionSansAutoCommit(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:ora9i",
            idCommis, motDePasse);
        try{
            // D�mat�rialiser l'Utilisateur et ses Pr�tsEnCours
            Membre unMembre = null;
            String idUtilisateur = 
                JOptionPane.showInputDialog("Entrez l'identificateur de l'utilisateur: ");

            // Cr�ation du courtier et d�mat�rialisation de l'Utilisateur
            CourtierBDUtilisateur unCourtierBDUtilisateur = 
                new CourtierBDUtilisateur(uneConnection);
            Utilisateur unUtilisateur = 
                unCourtierBDUtilisateur.chercherUtilisateurParIdUtilisateur(idUtilisateur);

            //Cr�ation du courtier et d�mat�rialisation des Pr�tsEnCours
            CourtierBDPr�tEnCours unCourtierBDPr�tEnCours = 
                new CourtierBDPr�tEnCours(uneConnection);
            unCourtierBDPr�tEnCours.chercherLesPr�tsEnCours(unUtilisateur);
            JOptionPane.showMessageDialog(null,
            "Nombre de pr�ts en cours :" + unUtilisateur.getNbPr�tsEnCours());

            // V�rifier si les conditions pr�alables sont accept�es
            boolean conditionsAccept�es = false;
            if (unUtilisateur instanceof Membre){
                unCourtierBDUtilisateur.chercherVariablesStatiquesDeMembre();
                unMembre = (Membre)unUtilisateur;
                if (!unMembre.conditionsPr�tAccept�es()){
                    JOptionPane.showMessageDialog(null,
                    "Pr�t refus�\nNb de pr�ts :" + unMembre.getNbPr�tsEnCours()+
                    ". Maximum :" + Membre.getNbMaxPr�ts() +
                    "\nNb de retards :" + unMembre.getNbRetards());
                } else {conditionsAccept�es = true;}
            } else {conditionsAccept�es = true;}// Pas de contrainte pour un employ�
            if(conditionsAccept�es){
                String idExemplaire = JOptionPane.showInputDialog("Entrez l'identificateur de l'exemplaire:");

                // V�rifier statut de l'exemplaire
                CourtierBDExemplaire unCourtierBDExemplaire = 
                    new CourtierBDExemplaire(uneConnection);
                Exemplaire unExemplaire = 
                    unCourtierBDExemplaire.chercherExemplaireParIdExemplaire(idExemplaire);
                if (unExemplaire.getStatut().equals("disponible")){

                    // G�n�rer la date du jour et l'objet Pr�tEnCours
                    Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
                    java.sql.Date dateMaintenant = 
                        new java.sql.Date(maintenant.getTime().getTime());
                    Pr�tEnCours leNouveauPr�tEnCours = 
                        new Pr�tEnCours(unUtilisateur,dateMaintenant,unExemplaire);

                    // Mat�rialiser le Pr�tEnCours dans la BD
                    unCourtierBDPr�tEnCours.ins�rerPr�tEnCours(leNouveauPr�tEnCours);

                    JOptionPane.showMessageDialog(null,
                    "Pr�t de l'exemplaire " + idExemplaire +
                    " � l'utilisateur " + idUtilisateur + " confirm�.\nDate:" + dateMaintenant
                    );
                }else{
                    JOptionPane.showMessageDialog(null,"Exemplaire non disponible:"+idExemplaire);
                }
            }
        }
        catch(Exception lException){
            JOptionPane.showMessageDialog(null,lException.getMessage());
            lException.printStackTrace();
        }
        finally{
            uneConnection.commit();
            uneConnection.close();
            System.exit(0);
        }
    }
}