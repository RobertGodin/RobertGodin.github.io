package ExemplesJDBC.GererPrets.impl;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import ExemplesJDBC.GererPrets.PretEnCoursEJBPK;

public class PretEnCoursEJBBean implements EntityBean 
{
  public EntityContext entityContext;

  public PretEnCoursEJBPK ejbCreate()
  {
    return null;
  }

  public void ejbPostCreate()
  {
  }

  public void ejbActivate()
  {
  }

  public void ejbLoad()
  {
  }

  public void ejbPassivate()
  {
  }

  public void ejbRemove()
  {
  }

  public void ejbStore()
  {
  }

  public void setEntityContext(EntityContext ctx)
  {
    this.entityContext = ctx;
  }

  public void unsetEntityContext()
  {
    this.entityContext = null;
  }
}