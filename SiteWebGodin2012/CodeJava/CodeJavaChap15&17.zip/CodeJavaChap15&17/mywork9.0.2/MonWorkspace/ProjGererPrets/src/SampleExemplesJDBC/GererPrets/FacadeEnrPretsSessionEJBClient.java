package SampleExemplesJDBC.GererPrets;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import ExemplesJDBC.GererPrets.FacadeEnrPretsSessionEJB;
import ExemplesJDBC.GererPrets.FacadeEnrPretsSessionEJBHome;

public class FacadeEnrPretsSessionEJBClient 
{
  public static void main(String [] args)
  {
    FacadeEnrPretsSessionEJBClient facadeEnrPretsSessionEJBClient = new FacadeEnrPretsSessionEJBClient();
    try
    {
      Hashtable env = new Hashtable();
      env.put(Context.INITIAL_CONTEXT_FACTORY, "com.evermind.server.rmi.RMIInitialContextFactory");
      env.put(Context.SECURITY_PRINCIPAL, "admin");
      env.put(Context.SECURITY_CREDENTIALS, "welcome");
      env.put(Context.PROVIDER_URL, "ormi://localhost:23893/current-workspace-app");
      Context ctx = new InitialContext(env);
      FacadeEnrPretsSessionEJBHome facadeEnrPretsSessionEJBHome = (FacadeEnrPretsSessionEJBHome)ctx.lookup("FacadeEnrPretsSessionEJB");
      FacadeEnrPretsSessionEJB facadeEnrPretsSessionEJB;

      // Use one of the create() methods below to create a new instance
      // facadeEnrPretsSessionEJB = facadeEnrPretsSessionEJBHome.create(  );


      // No Remote methods found!
    }
    catch(Throwable ex)
    {
      ex.printStackTrace();
    }

  }
}