package ExemplesJDBC.GererPrets;
import java.util.*;
public class Employ� extends Utilisateur {

    private String codeMatricule;
    private String cat�gorieEmploy�;

    public Employ�(String idUtilisateur, String motPasse, String nom,
        String pr�nom, String cat�gorie, String codeMatricule, String cat�gorieEmploy�){
        super(idUtilisateur, motPasse, nom, pr�nom, cat�gorie);
        this.codeMatricule = codeMatricule;
        this.cat�gorieEmploy� = cat�gorieEmploy�;    
    }

    public String getCodeMatricule(){return codeMatricule;}
    public String getCat�gorieEmploy�(){return cat�gorieEmploy�;}
    public void setCodeMatricule(String codeMatricule)
        {this.codeMatricule = codeMatricule;}
    public void setCat�gorieEmploy�(String cat�gorieEmploy�)
        {this.cat�gorieEmploy� = cat�gorieEmploy�;}
}