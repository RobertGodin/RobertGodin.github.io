package ExemplesJDBC.GererPrets;
import java.io.Serializable;

public class PretEnCoursEJBPK implements Serializable 
{
  public PretEnCoursEJBPK()
  {
  }

  public boolean equals(Object other)
  {
    // Add custom equals() impl here
    return super.equals(other);
  }

  public int hashCode()
  {
    // Add custom hashCode() impl here
    return super.hashCode();
  }
}