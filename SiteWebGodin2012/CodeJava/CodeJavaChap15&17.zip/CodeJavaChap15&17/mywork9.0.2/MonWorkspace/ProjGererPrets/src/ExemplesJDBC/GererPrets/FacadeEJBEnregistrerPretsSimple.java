package ExemplesJDBC.GererPrets;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import ExemplesJDBC.GererPrets.FacadeEnrPretSimpleSessionEJB;
import ExemplesJDBC.GererPrets.FacadeEnrPretSimpleSessionEJBHome;

// Fa�ade pour le cas d'utilisation EnregistrerPretsSimple
// La fa�ade utilise les services du EJB session FacadeEnrPretSimpleSessionEJB
public class FacadeEJBEnregistrerPretsSimple 
{
  public FacadeEJBEnregistrerPretsSimple()throws Exception
  {
 }
  // Ins�re le pr�t et retourne la date d'enregistrement
  public java.sql.Date insererPretEnCours(
    String  idUtilisateur, String idExemplaire) throws Exception{
      // Chercher une r�f�rence au EJB session
      FacadeEnrPretSimpleCMTSessionEJB uneFacadeEnrPretSimpleSessionEJB;
      Hashtable env = new Hashtable();
      env.put(Context.INITIAL_CONTEXT_FACTORY, "com.evermind.server.rmi.RMIInitialContextFactory");
      env.put(Context.SECURITY_PRINCIPAL, "admin");
      env.put(Context.SECURITY_CREDENTIALS, "welcome");
      env.put(Context.PROVIDER_URL, "ormi://localhost:23893/current-workspace-app");
      Context ctx = new InitialContext(env);
      FacadeEnrPretSimpleCMTSessionEJBHome facadeEnrPretSimpleSessionEJBHome =
        (FacadeEnrPretSimpleCMTSessionEJBHome)ctx.lookup("FacadeEnrPretSimpleCMTSessionEJB");
      uneFacadeEnrPretSimpleSessionEJB = facadeEnrPretSimpleSessionEJBHome.create(  ); 
      // D�l�guer l'insertion du Pr�tEnCours � la m�thode du EJB
      return uneFacadeEnrPretSimpleSessionEJB.insererPretEnCours(idUtilisateur,idExemplaire);
  }
}
