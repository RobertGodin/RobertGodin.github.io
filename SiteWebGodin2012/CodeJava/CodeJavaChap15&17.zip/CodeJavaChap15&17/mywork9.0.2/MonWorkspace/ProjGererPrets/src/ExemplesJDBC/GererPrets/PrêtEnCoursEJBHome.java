package ExemplesJDBC.GererPrets;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import java.util.Collection;

public interface Pr�tEnCoursEJBHome extends EJBHome 
{
  Pr�tEnCoursEJB create() throws RemoteException, CreateException;

  Pr�tEnCoursEJB create(String idexemplaire, String datepr�t, String idutilisateur) throws RemoteException, CreateException;

  Pr�tEnCoursEJB findByPrimaryKey(Pr�tEnCoursEJBPK primaryKey) throws RemoteException, FinderException;

  Collection findAll() throws RemoteException, FinderException;

  Collection findByIdutilisateur(String idutilisateur) throws RemoteException, FinderException;
}