package ExemplesJDBC.GererPrets;
/* Classe de contr�le pour EnregistrerPr�ts qui passe par FacadeEnregistrerPrets 
 * pour les services m�tiers
 * Interface � l'utilisateur minimaliste
 * NB V�rifie les conditions de pr�t et le statut de l'exemplaire au niveau du programme client
 */
import java.sql.*;
import javax.swing.JOptionPane;
import java.util.*;

class ControleEnregistrerPretsAvecFacade {
  public static void main (String args []) throws Exception {
    FacadeEnregistrerPrets uneFacadeEnregistrerPrets = new FacadeEnregistrerPrets();
    String idUtilisateur = JOptionPane.showInputDialog("Entrez l'identificateur de l'utilisateur: ");
    try{
      // Chercher les donn�es de l'utilisateur en passant par la fa�ade
      OTDUtilisateurPrets unOTDUtilisateurPrets = uneFacadeEnregistrerPrets.chercherOTDUtilisateurPrets(idUtilisateur);
      JOptionPane.showMessageDialog(null,
            "Nombre de pr�ts en cours :" + unOTDUtilisateurPrets.getNbPretsEnCours());

      // V�rifier si les conditions de pr�t sont accept�es
      if (!unOTDUtilisateurPrets.conditionsPretAcceptees()){
        JOptionPane.showMessageDialog(null,
            "Pr�t refus�\nNb de pr�ts :" + unOTDUtilisateurPrets.getNbPretsEnCours()+
            ". Maximum :" + unOTDUtilisateurPrets.getNbMaxPrets() +
            "\nNb de retards :" + unOTDUtilisateurPrets.getNbRetards());
      } else {
        String idExemplaire = 
          JOptionPane.showInputDialog("Entrez l'identificateur de l'exemplaire:");

        // V�rifier le statut de l'exemplaire en passant par la fa�ade
        String statut = uneFacadeEnregistrerPrets.getStatutExemplaire(idExemplaire);
        if (statut.equals("disponible")){

          // Enregistrer le pr�t en passant par la fa�ade
          java.sql.Date datePret = 
            uneFacadeEnregistrerPrets.insererPretEnCours();

          JOptionPane.showMessageDialog(null,"Pr�t de l'exemplaire " + idExemplaire +
              " � l'utilisateur " + idUtilisateur + " confirm�.\nDate:" + datePret);
        }else{
            JOptionPane.showMessageDialog(null,"Exemplaire non disponible:"+idExemplaire);
        }
      }
    }
    catch(Exception lException){
            JOptionPane.showMessageDialog(null,lException.getMessage());
            lException.printStackTrace();
    }
    finally{
      uneFacadeEnregistrerPrets.confirmerTransaction();
      System.exit(0);
    }
  }
}