package ExemplesJDBC.GererPrets;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;

public interface Pretencours extends EJBObject 
{
  String getIdexemplaire() throws RemoteException;

  void setIdexemplaire(String newIdexemplaire) throws RemoteException;

  String getDatepr�t() throws RemoteException;

  void setDatepr�t(String newDatepr�t) throws RemoteException;

  String getIdutilisateur() throws RemoteException;

  void setIdutilisateur(String newIdutilisateur) throws RemoteException;
}