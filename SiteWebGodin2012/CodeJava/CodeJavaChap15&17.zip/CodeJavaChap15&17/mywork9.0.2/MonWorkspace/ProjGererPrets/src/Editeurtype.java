import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;

public class Editeurtype implements ORAData, ORADataFactory
{
  public static final String _SQL_NAME = "GODIN.EDITEURTYPE";
  public static final int _SQL_TYPECODE = OracleTypes.STRUCT;

  protected MutableStruct _struct;

  private static int[] _sqlType =  { 12,12,2003 };
  private static ORADataFactory[] _factory = new ORADataFactory[3];
  static
  {
    _factory[2] = Tablereflivrestype.getORADataFactory();
  }
  protected static final Editeurtype _EditeurtypeFactory = new Editeurtype(false);

  public static ORADataFactory getORADataFactory()
  { return _EditeurtypeFactory; }
  /* constructor */
  protected Editeurtype(boolean init)
  { if(init) _struct = new MutableStruct(new Object[3], _sqlType, _factory); }
  public Editeurtype()
  { this(true); }

  /* ORAData interface */
  public Datum toDatum(Connection c) throws SQLException
  {
    return _struct.toDatum(c, _SQL_NAME);
  }

  /* ORADataFactory interface */
  public ORAData create(Datum d, int sqlType) throws SQLException
  { return create(null, d, sqlType); }
  protected ORAData create(Editeurtype o, Datum d, int sqlType) throws SQLException
  {
    if (d == null) return null; 
    if (o == null) o = new Editeurtype(false);
    o._struct = new MutableStruct((STRUCT) d, _sqlType, _factory);
    return o;
  }
  /* accessor methods */
  public String getNomediteur() throws SQLException
  { return (String) _struct.getAttribute(0); }

  public void setNomediteur(String nomediteur) throws SQLException
  { _struct.setAttribute(0, nomediteur); }


  public String getVille() throws SQLException
  { return (String) _struct.getAttribute(1); }

  public void setVille(String ville) throws SQLException
  { _struct.setAttribute(1, ville); }


  public Tablereflivrestype getLeslivres() throws SQLException
  { return (Tablereflivrestype) _struct.getAttribute(2); }

  public void setLeslivres(Tablereflivrestype leslivres) throws SQLException
  { _struct.setAttribute(2, leslivres); }

}
