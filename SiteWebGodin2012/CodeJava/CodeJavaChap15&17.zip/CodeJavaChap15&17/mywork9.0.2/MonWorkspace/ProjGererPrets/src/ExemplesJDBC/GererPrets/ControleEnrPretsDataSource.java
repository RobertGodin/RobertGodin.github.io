package ExemplesJDBC.GererPrets;
/* Classe de contr�le simple pour EnregistrerPr�ts
 * Interface � l'utilisateur minimaliste
 * NB Pas de v�rification des conditions pr�alabales dans le programme client
 */
import java.sql.*;
// Le package javax contient les extensions JDBC 2 DataSource
import javax.sql.*;
import javax.naming.*;
import javax.swing.JOptionPane;
import java.util.*;

class ControleEnrPretsDataSource {
    public static void main (String args []) throws Exception {
        // Chercher la Connection � partir d'un DataSource
      Hashtable env = new Hashtable();
      env.put(Context.INITIAL_CONTEXT_FACTORY, "com.evermind.server.rmi.RMIInitialContextFactory");
      env.put(Context.SECURITY_PRINCIPAL, "admin");
      env.put(Context.SECURITY_CREDENTIALS, "welcome");
      env.put(Context.PROVIDER_URL, "ormi://localhost:23892/current-workspace-app");
        InitialContext unContexte = new InitialContext(env);
        DataSource unDataSource = (DataSource)unContexte.lookup("ora9iclerat");
        
        Connection uneConnection = unDataSource.getConnection();

        String idUtilisateur = 
            JOptionPane.showInputDialog("Entrez l'identificateur de l'utilisateur: ");
        Utilisateur unUtilisateur = new Utilisateur(idUtilisateur);
        String idExemplaire = 
            JOptionPane.showInputDialog("Entrez l'identificateur de l'exemplaire:");
        Exemplaire unExemplaire = new Exemplaire(idExemplaire);
        
        // G�n�rer la date du jour et l'objet Pr�tEnCours
        Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
        java.sql.Date dateMaintenant = new java.sql.Date(maintenant.getTime().getTime());
        Pr�tEnCours leNouveauPr�tEnCours = 
            new Pr�tEnCours(unUtilisateur,dateMaintenant,unExemplaire);

        // Mat�rialiser le Pr�tEnCours dans la BD
        try{
            CourtierBDPr�tEnCours unCourtierBDPr�tEnCours = 
                new CourtierBDPr�tEnCours(uneConnection);
            unCourtierBDPr�tEnCours.ins�rerPr�tEnCours(leNouveauPr�tEnCours);

            JOptionPane.showMessageDialog(null,
            "Pr�t de l'exemplaire " + idExemplaire +
            " � l'utilisateur " + idUtilisateur + " confirm�.\nDate:" + dateMaintenant);
        }
        catch(Exception lException){
            JOptionPane.showMessageDialog(null,lException.getMessage());
            lException.printStackTrace();
        }
        finally{
            // Pas besoin de commit
            uneConnection.close();
            System.exit(0);
        }
    }
}