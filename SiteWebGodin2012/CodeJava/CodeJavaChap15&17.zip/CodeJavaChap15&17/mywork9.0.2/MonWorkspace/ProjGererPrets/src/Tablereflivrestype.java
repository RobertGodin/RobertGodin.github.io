import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.jpub.runtime.MutableArray;

public class Tablereflivrestype implements ORAData, ORADataFactory
{
  public static final String _SQL_NAME = "GODIN.TABLEREFLIVRESTYPE";
  public static final int _SQL_TYPECODE = OracleTypes.ARRAY;

  MutableArray _array;

  private static final Tablereflivrestype _TablereflivrestypeFactory = new Tablereflivrestype();

  public static ORADataFactory getORADataFactory()
  { return _TablereflivrestypeFactory; }
  /* constructors */
  public Tablereflivrestype()
  {
    this((Livrereftype[])null);
  }

  public Tablereflivrestype(Livrereftype[] a)
  {
    _array = new MutableArray(2002, a, Livrereftype.getORADataFactory());
  }

  /* ORAData interface */
  public Datum toDatum(Connection c) throws SQLException
  {
    return _array.toDatum(c, _SQL_NAME);
  }

  /* ORADataFactory interface */
  public ORAData create(Datum d, int sqlType) throws SQLException
  {
    if (d == null) return null;
    Tablereflivrestype a = new Tablereflivrestype();
    a._array = new MutableArray(2002, (ARRAY) d, Livrereftype.getORADataFactory());
    return a;
  }

  public int length() throws SQLException
  {
    return _array.length();
  }

  public int getBaseType() throws SQLException
  {
    return _array.getBaseType();
  }

  public String getBaseTypeName() throws SQLException
  {
    return _array.getBaseTypeName();
  }

  public ArrayDescriptor getDescriptor() throws SQLException
  {
    return _array.getDescriptor();
  }

  /* array accessor methods */
  public Livrereftype[] getArray() throws SQLException
  {
    return (Livrereftype[]) _array.getObjectArray(
      new Livrereftype[_array.length()]);
  }

  public void setArray(Livrereftype[] a) throws SQLException
  {
    _array.setObjectArray(a);
  }

  public Livrereftype[] getArray(long index, int count) throws SQLException
  {
    return (Livrereftype[]) _array.getObjectArray(index,
      new Livrereftype[_array.sliceLength(index, count)]);
  }

  public void setArray(Livrereftype[] a, long index) throws SQLException
  {
    _array.setObjectArray(a, index);
  }

  public Livrereftype getElement(long index) throws SQLException
  {
    return (Livrereftype) _array.getObjectElement(index);
  }

  public void setElement(Livrereftype a, long index) throws SQLException
  {
    _array.setObjectElement(a, index);
  }

}
