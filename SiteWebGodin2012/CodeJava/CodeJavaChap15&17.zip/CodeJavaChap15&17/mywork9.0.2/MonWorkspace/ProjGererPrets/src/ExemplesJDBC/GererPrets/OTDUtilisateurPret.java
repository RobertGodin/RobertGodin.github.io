package ExemplesJDBC.GererPrets;

public class OTDUtilisateurPret 
{
    protected String idUtilisateur;
    protected String categorie;
    protected boolean conditionsAcceptees;
    protected int nbPrets;
    protected int nbRetards;
    protected int nbMaxPrets;

  public OTDUtilisateurPret(
    String idUtilisateur, String categorie, boolean conditionsAcceptees, int nbPrets, 
     int nbRetards, int nbMaxPrets) {
    this.idUtilisateur=idUtilisateur;
    this.categorie=categorie;
    this.conditionsAcceptees=conditionsAcceptees;
    this.nbPrets=nbPrets;
    this.nbRetards=nbRetards;
    this.nbMaxPrets=nbMaxPrets;
  }
}