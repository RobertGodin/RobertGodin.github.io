package ExemplesJDBC.GererPrets;
public class Pr�tEnCours extends Pr�t {
    public Pr�tEnCours(Utilisateur lUtilisateur,java.sql.Date datePr�t, Exemplaire lExemplaire) {
        super(lUtilisateur,datePr�t,lExemplaire);
    }
    // Le constructeur suivant ne construit pas le lien vers Exemplaire
    public Pr�tEnCours(Utilisateur lUtilisateur,java.sql.Date datePr�t) {
        super(lUtilisateur,datePr�t,null);
    }
}