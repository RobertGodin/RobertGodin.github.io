package ExemplesJDBC.GererPrets.impl;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import java.sql.Date;
import ExemplesJDBC.GererPrets.*;
import java.sql.Connection;
import java.util.*;

public class FacadeEnrPretSimpleSessionEJBBean implements SessionBean 
{
  public void ejbCreate()
  {
  }

  public void ejbActivate()
  {
  }

  public void ejbPassivate()
  {
  }

  public void ejbRemove()
  {
  }

  public void setSessionContext(SessionContext ctx)
  {
  }

  public Date insererPretEnCours(String idUtilisateur, String idExemplaire) throws Exception
  {
    UsineConnection uneUsineConnection = new UsineConnection();
//    Connection uneConnection = uneUsineConnection.getConnection(
//            "oracle.jdbc.driver.OracleDriver",
//            "jdbc:oracle:thin:@localhost:1521:ora9i",
//            "clerat","oracle");
    Connection uneConnection = 
      uneUsineConnection.getConnectionFromDataSourceSansAutoCommit("jdbc/ora9icleratCoreDS");

    Utilisateur unUtilisateur = new Utilisateur(idUtilisateur);
    Exemplaire unExemplaire = new Exemplaire(idExemplaire);
        
    // G�n�rer la date du jour et l'objet Pr�tEnCours
    Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
    java.sql.Date dateMaintenant = new java.sql.Date(maintenant.getTime().getTime());

    Pr�tEnCours leNouveauPr�tEnCours = 
            new Pr�tEnCours(unUtilisateur,dateMaintenant,unExemplaire);

    // Mat�rialiser le Pr�tEnCours dans la BD
    CourtierBDPr�tEnCours unCourtierBDPr�tEnCours = 
                new CourtierBDPr�tEnCours(uneConnection);
    unCourtierBDPr�tEnCours.ins�rerPr�tEnCours(leNouveauPr�tEnCours);
    // Pas besoin de commit
    uneConnection.close();
    return dateMaintenant;
  }
}