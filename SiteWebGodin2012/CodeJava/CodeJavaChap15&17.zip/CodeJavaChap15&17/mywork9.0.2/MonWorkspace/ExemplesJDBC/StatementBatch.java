// Exemple d'ex�cution par lot (batch)
package ExemplesJDBC;
import java.sql.*;

class StatementBatch
{
  public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    // Connection � une BD
    Connection uneConnection =
      DriverManager.getConnection ("jdbc:oracle:oci8:@", "godin", "oracle");

    // Cr�ation d'un PreparedStatement associ� � la Connection
    PreparedStatement unEnonc�SQL = uneConnection.prepareStatement
      ("INSERT INTO Client VALUES(?,?,?)");
    
    // Ajout d'un INSERT dans le lot
    unEnonc�SQL.setInt(1,90);
    unEnonc�SQL.setString(2,"Edgar Degas");
    unEnonc�SQL.setString(3,"(222)222-2222");
    unEnonc�SQL.addBatch();
    
    // Ajout d'un autre INSERT dans le lot
    unEnonc�SQL.setInt(1,100);
    unEnonc�SQL.setString(2,"Claude Monet");
    unEnonc�SQL.setString(3,"(111)111-1111");
    unEnonc�SQL.addBatch();
    
    // Ex�cution du lot en un appel
    int [] r�sultats = unEnonc�SQL.executeBatch();

    // Fermeture de �nonc� et de la connexion
    unEnonc�SQL.close();
    uneConnection.close();
  }
}