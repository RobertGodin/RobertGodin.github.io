package ExemplesJDBC;
// Exemple d'insertion d'une valeur (image GIF) dans une colonne BLOB
import java.sql.*;
import oracle.sql.*;
import oracle.jdbc.driver.*;
import java.io.*;

class JDBCInsertBlob
{
    public static void main (String args [])
    throws Exception, SQLException, ClassNotFoundException, java.io.IOException
    {
        Class.forName ("oracle.jdbc.driver.OracleDriver");
        Connection uneConnection =
        DriverManager.getConnection ("jdbc:oracle:thin:@127.0.0.1:1521:ora817i", "godin", "oracle");
        uneConnection.setAutoCommit(false);
        Statement unEnonc�SQL = uneConnection.createStatement ();

        // On doit d'abord ins�rer une valeur de BLOB vide
        unEnonc�SQL.execute ("INSERT INTO tableBlob VALUES (1, empty_blob())");

        // Chercher le "BLOB locator" par un SELECT
        BLOB unBlob;
        ResultSet unResultSet = unEnonc�SQL.executeQuery("SELECT * FROM tableBlob WHERE idBlob=1");
        if(unResultSet.next()){
            unBlob = ((OracleResultSet)unResultSet).getBLOB(2);

            // Ouvrir le fichier contenant l'image et en cr�er un FileInputStream
            File unFichier = new File("C:/forte4j/Development/ExemplesJDBC/coq1.gif");
            System.out.println("Taille de coq1.gif : " + unFichier.length());
            FileInputStream unFileInputStream = new FileInputStream(unFichier);

            // Cr�er un OutPutStream � partir du BLOB locator pour y �crire l'image
            OutputStream unOutputStream = unBlob.getBinaryOutputStream();

            // Appeler getBufferSize() afin de d�terminer la taille id�ale de tampon
            // (selon des calculs faits par le pilote JDBC) pour �crire dans le OutputStream
            int tailleTampon = unBlob.getBufferSize();
            byte[] octets = new byte[tailleTampon];
            int tailleLue = -1;

            // Lecture et �criture de l'image un tampon � la fois
            while ((tailleLue = unFileInputStream.read(octets)) != -1)
            unOutputStream.write(octets, 0, tailleLue);

            // Fermer les Stream, confirmer la transaction et fermer la connection
            unFileInputStream.close();
            unOutputStream.close();
            uneConnection.commit();
            unEnonc�SQL.close();
            uneConnection.close();
        }else{throw new Exception("Le BLOB vide n'a pas �t� ins�r� auparavant");}
    }
}




