// Exemple de programme JAVA qui illustre l'utilisation du ResultSetMetaData
package ExemplesJDBC;
import java.sql.*;

class ExempleRSMetaData
{
  public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    Connection uneConnection =
      DriverManager.getConnection ("jdbc:oracle:oci8:@", "godin", "oracle");
    
    Statement unEnonc�SQL = uneConnection.createStatement ();
    // Ex�cution d'un SELECT
    ResultSet r�sultatSelect = unEnonc�SQL.executeQuery
      ("SELECT noClient, nomClient "+
      "FROM CLIENT " +
      "WHERE noClient > 40");
    
    // Consultation de quelques m�ta-donn�es du ResultSetMetaData
    ResultSetMetaData unRSMD = r�sultatSelect.getMetaData();
    int nombreColonnes = unRSMD.getColumnCount();
    System.out.println("Le r�sultat du SELECT contient "+nombreColonnes+" colonnes");
    for (int indice = 1; indice <= nombreColonnes; indice++){
        System.out.println("La colonne "+indice+
            " qui se nomme "+unRSMD.getColumnName(indice)+
            " est de type "+unRSMD.getColumnTypeName(indice));
    }
    unEnonc�SQL.close();
    uneConnection.close();
  }
}
