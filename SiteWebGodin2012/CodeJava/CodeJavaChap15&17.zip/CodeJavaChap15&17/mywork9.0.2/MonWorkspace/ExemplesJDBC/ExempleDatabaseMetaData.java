// Exemple de programme JAVA qui illustre l'utilisation du DatabaseMetaData
package ExemplesJDBC;
import java.sql.*;

class ExempleDatabaseMetaData
{
  public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    Class.forName ("oracle.jdbc.driver.OracleDriver");
    Connection uneConnection =
      DriverManager.getConnection ("jdbc:oracle:oci8:@", "godin", "oracle");
    
    // Consultation de quelques m�ta-donn�es de la BD
    DatabaseMetaData unDBM = uneConnection.getMetaData();
    System.out.println("Nom du SGBD :"+unDBM.getDatabaseProductName());
    System.out.println("Version du SGBD :"+unDBM.getDatabaseProductVersion());
    System.out.println("Niveau d'isolation par d�faut :"+unDBM.getDefaultTransactionIsolation());
    System.out.println("Support du niveau entr�e de SQL2 :"+unDBM.supportsANSI92EntryLevelSQL());
    System.out.println("Nom du pilote JDBC :"+unDBM.getDriverName());
    uneConnection.close();
  }
}