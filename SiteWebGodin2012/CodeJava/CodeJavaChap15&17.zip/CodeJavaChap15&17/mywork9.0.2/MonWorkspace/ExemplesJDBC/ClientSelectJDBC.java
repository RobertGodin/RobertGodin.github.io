// Exemple de programme JAVA qui utilise le pilote JDBC OCI8 d'Oracle
// pour effectuer un SELECT et it�rer sur les lignes du r�sultat

// Il faut importer le paquetage java.sql pour utiliser JDBC
package ExemplesJDBC;
import java.sql.*;

class ClientSelectJDBC
{
  public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    // Connexion � une BD
    Connection uneConnection =
      DriverManager.getConnection ("jdbc:oracle:oci8:@", "godin", "oracle");

    // Cr�ation d'un �nonc� associ� � la Connexion
    Statement unEnonc�SQL = uneConnection.createStatement();

    // Ex�cution d'un SELECT
    ResultSet r�sultatSelect = unEnonc�SQL.executeQuery
     ("SELECT noClient, nomClient "+
     "FROM CLIENT " +
     "WHERE noClient > 40");

    // It�rer sur les lignes du r�sultat du SELECT et extraire les valeurs
    // des colonnes dans des variables JAVA
    
    while (r�sultatSelect.next ()){
      int noClient = r�sultatSelect.getInt ("noClient");
      String nomClient = r�sultatSelect.getString ("nomClient");
      System.out.println ("Num�ro du client:" + noClient);
      System.out.println ("Nom du client:" + nomClient);
    }
    // Fermeture de l'�nonc� et de la connexion
    unEnonc�SQL.close();
    uneConnection.close();
  }
}
