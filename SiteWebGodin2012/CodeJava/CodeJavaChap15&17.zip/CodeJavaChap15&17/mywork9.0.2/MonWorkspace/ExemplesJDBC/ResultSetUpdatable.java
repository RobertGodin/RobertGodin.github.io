// Exemples de mises-�-jour dans un ResultSet updatable JDBC 2

package ExemplesJDBC;
import java.sql.*;

class ResultSetUpdatable
{
    public static void main (String args [])
    throws SQLException, ClassNotFoundException, java.io.IOException
    {
        // Charger le pilote JDBC d'Oracle
        Class.forName ("oracle.jdbc.driver.OracleDriver");

        // Connexion � une BD
        Connection uneConnection =
        DriverManager.getConnection ("jdbc:oracle:oci8:@", "godin", "oracle");

        // Cr�ation d'un �nonc� avec ResultSet d�filable (srollable)
        Statement unEnonc�SQL =
        uneConnection.createStatement(
            ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);

        // Ex�cution d'un SELECT
        ResultSet r�sultatSelect = unEnonc�SQL.executeQuery
        ("SELECT noClient, nomClient, noT�l�phone FROM CLIENT");
        
        // Exemples de mises-�-jour par ResultSet updatable
        
        //Positionnement � la premi�re ligne du ResultSet
        r�sultatSelect.first();
        // Mise-�-jour de la colonne noT�l�phone de la ligne courante
        r�sultatSelect.updateString("noT�l�phone","(111)111-1111");
        // Effectuer le UPDATE
        r�sultatSelect.updateRow();
                
        // Positionnement � la derni�re ligne de la table
        r�sultatSelect.last();
        // Supprimer la ligne courante
        r�sultatSelect.deleteRow();
        
        // Insertion d'une nouvelle ligne
        r�sultatSelect.moveToInsertRow();
        r�sultatSelect.updateInt("noClient", 100);
        r�sultatSelect.updateString("nomClient", "G. Lemoyne-Allaire");
        r�sultatSelect.updateString("noT�l�phone", "911");
        r�sultatSelect.insertRow();
        
        // Fermeture de l'�nonc� et de la connexion
        unEnonc�SQL.close();
        uneConnection.close();
    }
}