/*@lineinfo:filename=ExecuteProcedureSQLJ*//*@lineinfo:user-code*//*@lineinfo:1^1*///Exemple d'appel d'une proc�dure stock�e avec SQLJ
package ExemplesSQLJ;

import sqlj.runtime.*;
import sqlj.runtime.ref.*;
import java.sql.*;

public class ExecuteProcedureSQLJ{
    public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    // Cr�ation du contexte de connexion de d�faut avec autocommit (true)
    DefaultContext unContexte = new DefaultContext
          ("jdbc:oracle:thin:@localhost:1521:ora817i", "godin", "oracle", true);
    DefaultContext.setDefaultContext(unContexte);

    int noArticle = 10 ;
    int laQuantite = 20;

    // Appel de la proc�dure stock�e
    /*@lineinfo:generated-code*//*@lineinfo:24^5*/

//  ************************************************************
//  #sql { CALL pModifierQuantit�EnStock(:noArticle,:laQuantite) };
//  ************************************************************

{
  sqlj.runtime.ConnectionContext __sJT_connCtx = sqlj.runtime.ref.DefaultContext.getDefaultContext();
  if (__sJT_connCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext __sJT_execCtx = __sJT_connCtx.getExecutionContext();
  if (__sJT_execCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_EXEC_CTX();
  int __sJT_1 = noArticle;
  int __sJT_2 = laQuantite;
  synchronized (__sJT_execCtx) {
    sqlj.runtime.profile.RTStatement __sJT_stmt = __sJT_execCtx.registerStatement(__sJT_connCtx, ExecuteProcedureSQLJ_SJProfileKeys.getKey(0), 0);
    try 
    {
      __sJT_stmt.setInt(1, __sJT_1);
      __sJT_stmt.setInt(2, __sJT_2);
      __sJT_execCtx.execute();
    }
    finally 
    {
      __sJT_execCtx.releaseStatement();
    }
  }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:24^70*/

    // Fermeture du contexte de connexion
    unContexte.close();
  }
}/*@lineinfo:generated-code*/class ExecuteProcedureSQLJ_SJProfileKeys 
{
  private static ExecuteProcedureSQLJ_SJProfileKeys inst = null;
  public static java.lang.Object getKey(int keyNum) 
    throws java.sql.SQLException 
  {
    if (inst == null)
    {
      inst = new ExecuteProcedureSQLJ_SJProfileKeys();
    }
    return inst.keys[keyNum];
  }
  private final sqlj.runtime.profile.Loader loader = sqlj.runtime.RuntimeContext.getRuntime().getLoaderForClass(getClass());
  private java.lang.Object[] keys;
  private ExecuteProcedureSQLJ_SJProfileKeys() 
    throws java.sql.SQLException 
  {
    keys = new java.lang.Object[1];
    keys[0] = sqlj.runtime.ref.DefaultContext.getProfileKey(loader, "ExemplesSQLJ.ExecuteProcedureSQLJ_SJProfile0");
  }
}
