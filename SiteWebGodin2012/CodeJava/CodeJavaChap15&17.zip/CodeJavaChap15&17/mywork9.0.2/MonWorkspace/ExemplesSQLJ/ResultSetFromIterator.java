/*@lineinfo:filename=ResultSetFromIterator*//*@lineinfo:user-code*//*@lineinfo:1^1*///Exemple d'utilisation d'un it�rateur de r�sultat d'un SELECT avec SQLJ
package ExemplesSQLJ;

import sqlj.runtime.*;
import sqlj.runtime.ref.*;
import java.sql.*;

public class ResultSetFromIterator{
    public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    // Cr�ation du contexte de connexion de d�faut avec autocommit (true)
    DefaultContext unContext = new DefaultContext
          ("jdbc:oracle:thin:@localhost:1521:ora817i", "godin", "oracle", true);
    DefaultContext.setDefaultContext(unContext);

    // D�finition de la classe IteratorClient avec liaison par nom
    /*@lineinfo:generated-code*//*@lineinfo:21^5*/

//  ************************************************************
//  SQLJ iterator declaration:
//  ************************************************************

class IteratorClient 
extends sqlj.runtime.ref.ResultSetIterImpl
implements sqlj.runtime.NamedIterator
{
  public IteratorClient(sqlj.runtime.profile.RTResultSet resultSet) 
    throws java.sql.SQLException 
  {
    super(resultSet);
    noClientNdx = findColumn("noClient");
    nomClientNdx = findColumn("nomClient");
  }
  public int noClient() 
    throws java.sql.SQLException 
  {
    return resultSet.getIntNoNull(noClientNdx);
  }
  private int noClientNdx;
  public String nomClient() 
    throws java.sql.SQLException 
  {
    return resultSet.getString(nomClientNdx);
  }
  private int nomClientNdx;
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:21^64*/

    // Cr�ation d'un objet it�rateur
    IteratorClient unIteratorClient;

    // Liaison de l'�nonc� SELECT de l'it�rateur
    /*@lineinfo:generated-code*//*@lineinfo:27^5*/

//  ************************************************************
//  #sql unIteratorClient = { SELECT noClient, nomClient
//            FROM Client WHERE noClient > 40 };
//  ************************************************************

{
  sqlj.runtime.ConnectionContext __sJT_connCtx = sqlj.runtime.ref.DefaultContext.getDefaultContext();
  if (__sJT_connCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext __sJT_execCtx = __sJT_connCtx.getExecutionContext();
  if (__sJT_execCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_EXEC_CTX();
  synchronized (__sJT_execCtx) {
    sqlj.runtime.profile.RTStatement __sJT_stmt = __sJT_execCtx.registerStatement(__sJT_connCtx, ResultSetFromIterator_SJProfileKeys.getKey(0), 0);
    try 
    {
      sqlj.runtime.profile.RTResultSet __sJT_result = __sJT_execCtx.executeQuery();
      unIteratorClient = new IteratorClient(__sJT_result);
    }
    finally 
    {
      __sJT_execCtx.releaseStatement();
    }
  }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:29^42*/

    // Conversion de l'it�rateur en ResultSet JDBC
    ResultSet r�sultatSelect = unIteratorClient.getResultSet();

    // Acc�s au ResultSet
    while (r�sultatSelect.next ()){
      int noClient = r�sultatSelect.getInt ("noClient");
      String nomClient = r�sultatSelect.getString ("nomClient");
      System.out.println ("Num�ro du client:" + noClient);
      System.out.println ("Nom du client:" + nomClient);
    }

    // Fermer l'it�rateur
    unIteratorClient.close();
  }
}/*@lineinfo:generated-code*/class ResultSetFromIterator_SJProfileKeys 
{
  private static ResultSetFromIterator_SJProfileKeys inst = null;
  public static java.lang.Object getKey(int keyNum) 
    throws java.sql.SQLException 
  {
    if (inst == null)
    {
      inst = new ResultSetFromIterator_SJProfileKeys();
    }
    return inst.keys[keyNum];
  }
  private final sqlj.runtime.profile.Loader loader = sqlj.runtime.RuntimeContext.getRuntime().getLoaderForClass(getClass());
  private java.lang.Object[] keys;
  private ResultSetFromIterator_SJProfileKeys() 
    throws java.sql.SQLException 
  {
    keys = new java.lang.Object[1];
    keys[0] = sqlj.runtime.ref.DefaultContext.getProfileKey(loader, "ExemplesSQLJ.ResultSetFromIterator_SJProfile0");
  }
}
