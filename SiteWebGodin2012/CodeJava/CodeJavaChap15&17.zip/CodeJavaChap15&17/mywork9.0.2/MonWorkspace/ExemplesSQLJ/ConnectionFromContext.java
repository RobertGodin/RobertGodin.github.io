/*@lineinfo:filename=ConnectionFromContext*//*@lineinfo:user-code*//*@lineinfo:1^1*///Exemple d'utilisation de la Connection d'un contexte SQLJ
package ExemplesSQLJ;

import sqlj.runtime.*;
import sqlj.runtime.ref.*;
import java.sql.*;

// D�claration de la classe du contexte explicite
/*@lineinfo:generated-code*//*@lineinfo:9^1*/

//  ************************************************************
//  SQLJ context declaration:
//  ************************************************************

class ContexteTemp 
extends sqlj.runtime.ref.ConnectionContextImpl
implements sqlj.runtime.ConnectionContext
{
  public ContexteTemp(java.sql.Connection conn) 
    throws java.sql.SQLException 
  {
    super(profiles, conn);
  }
  public ContexteTemp(java.lang.String url, java.lang.String user, java.lang.String password, boolean autoCommit) 
    throws java.sql.SQLException 
  {
    super(profiles, url, user, password, autoCommit);
  }
  public ContexteTemp(java.lang.String url, java.util.Properties info, boolean autoCommit) 
    throws java.sql.SQLException 
  {
    super(profiles, url, info, autoCommit);
  }
  public ContexteTemp(java.lang.String url, boolean autoCommit) 
    throws java.sql.SQLException 
  {
    super(profiles, url, autoCommit);
  }
  public ContexteTemp(sqlj.runtime.ConnectionContext other) 
    throws java.sql.SQLException 
  {
    super(profiles, other);
  }
  public java.util.Dictionary getTypeMap() 
  {
    return m_typeMap;
  }
  private static java.util.Dictionary m_typeMap = null;
  public static ContexteTemp getDefaultContext() 
  {
    if (defaultContext == null)
    {
      java.sql.Connection conn = sqlj.runtime.RuntimeContext.getRuntime().getDefaultConnection();
      if (conn != null)
      {
        try 
        {
          defaultContext = new ContexteTemp(conn);
        }
        catch (java.sql.SQLException e) 
        {
        }
      }
    }
    return defaultContext;
  }
  public static void setDefaultContext(ContexteTemp ctx) 
  {
    defaultContext = ctx;
  }
  private static ContexteTemp defaultContext = null;
  public static java.lang.Object getProfileKey(sqlj.runtime.profile.Loader loader, java.lang.String profileName) 
    throws java.sql.SQLException 
  {
    return profiles.getProfileKey(loader, profileName);
  }
  private static final sqlj.runtime.ref.ProfileGroup profiles = new sqlj.runtime.ref.ProfileGroup();
  public static sqlj.runtime.profile.Profile getProfile(java.lang.Object profileKey) 
  {
    return profiles.getProfile(profileKey);
  }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:9^25*/

public class ConnectionFromContext{
    public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    // Cr�ation du contexte de connexion avec autocommit (true)
    ContexteTemp unContexte = new ContexteTemp
          ("jdbc:oracle:thin:@localhost:1521:ora817i", "godin", "oracle", true);

    // Chercher la Connection de unContexte
    Connection uneConnection = unContexte.getConnection();

    // Cr�ation d'un �nonc� associ� � la Connection
    Statement unEnonc�SQL = uneConnection.createStatement ();

    // Insertion d'une ligne dans la table Client
    int n = unEnonc�SQL.executeUpdate
      ("INSERT INTO CLIENT " +
       "VALUES (100, 'G. Lemoyne-Allaire', '911')");
    System.out.println ("Nombre de lignes inserees:" + n);

    // Fermeture de l'�nonc� et de la connexion
    unEnonc�SQL.close();
    uneConnection.close();
    
    System.out.println("Insertion r�ussie !");
  }
}/*@lineinfo:generated-code*/