/*@lineinfo:filename=ContexteExpliciteSQLJ*//*@lineinfo:user-code*//*@lineinfo:1^1*///Exemple d'utilisation d'un contexte explicite avec SQLJ
package ExemplesSQLJ;

import sqlj.runtime.*;
import sqlj.runtime.ref.*;
import java.sql.*;

// D�claration de la classe du contexte explicite

public class ContexteExpliciteSQLJ{
    public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");
/*@lineinfo:generated-code*//*@lineinfo:16^1*/

//  ************************************************************
//  SQLJ context declaration:
//  ************************************************************

class Contexte 
extends sqlj.runtime.ref.ConnectionContextImpl
implements sqlj.runtime.ConnectionContext
{
  public Contexte(java.sql.Connection conn) 
    throws java.sql.SQLException 
  {
    super(profiles, conn);
  }
  public Contexte(java.lang.String url, java.lang.String user, java.lang.String password, boolean autoCommit) 
    throws java.sql.SQLException 
  {
    super(profiles, url, user, password, autoCommit);
  }
  public Contexte(java.lang.String url, java.util.Properties info, boolean autoCommit) 
    throws java.sql.SQLException 
  {
    super(profiles, url, info, autoCommit);
  }
  public Contexte(java.lang.String url, boolean autoCommit) 
    throws java.sql.SQLException 
  {
    super(profiles, url, autoCommit);
  }
  public Contexte(sqlj.runtime.ConnectionContext other) 
    throws java.sql.SQLException 
  {
    super(profiles, other);
  }
  public java.util.Dictionary getTypeMap() 
  {
    return m_typeMap;
  }
  private static java.util.Dictionary m_typeMap = null;
  public static Contexte getDefaultContext() 
  {
    if (defaultContext == null)
    {
      java.sql.Connection conn = sqlj.runtime.RuntimeContext.getRuntime().getDefaultConnection();
      if (conn != null)
      {
        try 
        {
          defaultContext = new Contexte(conn);
        }
        catch (java.sql.SQLException e) 
        {
        }
      }
    }
    return defaultContext;
  }
  public static void setDefaultContext(Contexte ctx) 
  {
    defaultContext = ctx;
  }
  private static Contexte defaultContext = null;
  public static java.lang.Object getProfileKey(sqlj.runtime.profile.Loader loader, java.lang.String profileName) 
    throws java.sql.SQLException 
  {
    return profiles.getProfileKey(loader, profileName);
  }
  private static final sqlj.runtime.ref.ProfileGroup profiles = new sqlj.runtime.ref.ProfileGroup();
  public static sqlj.runtime.profile.Profile getProfile(java.lang.Object profileKey) 
  {
    return profiles.getProfile(profileKey);
  }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:16^21*/

    // Cr�ation du contexte de connexion avec autocommit (true)
    Contexte unContexte = new Contexte
          ("jdbc:oracle:thin:@localhost:1521:ora817i", "godin", "oracle", true);

    // Insertion en utilisant le contexte explicite unContexte
    /*@lineinfo:generated-code*//*@lineinfo:23^5*/

//  ************************************************************
//  #sql [unContexte] { INSERT INTO CLIENT VALUES (100, 'G. Lemoyne-Allaire', '911') };
//  ************************************************************

{
  sqlj.runtime.ConnectionContext __sJT_connCtx = unContexte;
  if (__sJT_connCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext __sJT_execCtx = __sJT_connCtx.getExecutionContext();
  if (__sJT_execCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_EXEC_CTX();
  synchronized (__sJT_execCtx) {
    sqlj.runtime.profile.RTStatement __sJT_stmt = __sJT_execCtx.registerStatement(__sJT_connCtx, ContexteExpliciteSQLJ_SJProfileKeys.getKey(0), 0);
    try 
    {
      __sJT_execCtx.executeUpdate();
    }
    finally 
    {
      __sJT_execCtx.releaseStatement();
    }
  }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:23^84*/

    // Fermeture du contexte de connexion
    unContexte.close();
    
    System.out.println("Insertion r�ussie !");
  }
}/*@lineinfo:generated-code*/class ContexteExpliciteSQLJ_SJProfileKeys 
{
  private static ContexteExpliciteSQLJ_SJProfileKeys inst = null;
  public static java.lang.Object getKey(int keyNum) 
    throws java.sql.SQLException 
  {
    if (inst == null)
    {
      inst = new ContexteExpliciteSQLJ_SJProfileKeys();
    }
    return inst.keys[keyNum];
  }
  private final sqlj.runtime.profile.Loader loader = sqlj.runtime.RuntimeContext.getRuntime().getLoaderForClass(getClass());
  private java.lang.Object[] keys;
  private ContexteExpliciteSQLJ_SJProfileKeys() 
    throws java.sql.SQLException 
  {
    keys = new java.lang.Object[1];
    keys[0] = ExemplesSQLJ.ContexteExpliciteSQLJ.0$Contexte.getProfileKey(loader, "ExemplesSQLJ.ContexteExpliciteSQLJ_SJProfile0");
  }
}
