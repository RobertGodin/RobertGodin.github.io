/*@lineinfo:filename=ClientSelectIntoSQLJ*//*@lineinfo:user-code*//*@lineinfo:1^1*///Exemple d'utilisation de la clause INTO dans un SELECT avec SQLJ
package ExemplesSQLJ;

import sqlj.runtime.*;
import sqlj.runtime.ref.*;
import java.sql.*;

public class ClientSelectIntoSQLJ{
    public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    // Cr�ation du contexte de connexion de d�faut avec autocommit (true)
    DefaultContext unContext = new DefaultContext
          ("jdbc:oracle:thin:@localhost:1521:ora817i", "godin", "oracle", true);
    DefaultContext.setDefaultContext(unContext);

    String nom;
    String tel;

    // Utilisation de la clause INTO
    /*@lineinfo:generated-code*//*@lineinfo:24^5*/

//  ************************************************************
//  #sql { SELECT nomClient, noT�l�phone
//              
//              FROM Client WHERE noClient = 10 };
//  ************************************************************

{
  sqlj.runtime.profile.RTResultSet __sJT_rtRs;
  sqlj.runtime.ConnectionContext __sJT_connCtx = sqlj.runtime.ref.DefaultContext.getDefaultContext();
  if (__sJT_connCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext __sJT_execCtx = __sJT_connCtx.getExecutionContext();
  if (__sJT_execCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_EXEC_CTX();
  synchronized (__sJT_execCtx) {
    sqlj.runtime.profile.RTStatement __sJT_stmt = __sJT_execCtx.registerStatement(__sJT_connCtx, ClientSelectIntoSQLJ_SJProfileKeys.getKey(0), 0);
    try 
    {
      sqlj.runtime.profile.RTResultSet __sJT_result = __sJT_execCtx.executeQuery();
      __sJT_rtRs = __sJT_result;
    }
    finally 
    {
      __sJT_execCtx.releaseStatement();
    }
  }
  try 
  {
    sqlj.runtime.ref.ResultSetIterImpl.checkColumns(__sJT_rtRs, 2);
    if (!__sJT_rtRs.next())
    {
      sqlj.runtime.error.RuntimeRefErrors.raise_NO_ROW_SELECT_INTO();
    }
    nom = __sJT_rtRs.getString(1);
    tel = __sJT_rtRs.getString(2);
    if (__sJT_rtRs.next())
    {
      sqlj.runtime.error.RuntimeRefErrors.raise_MULTI_ROW_SELECT_INTO();
    }
  }
  finally 
  {
    __sJT_rtRs.close();
  }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:26^44*/
    System.out.println("Nom : "+ nom + " T�l�phone : " + tel);
  }
}/*@lineinfo:generated-code*/class ClientSelectIntoSQLJ_SJProfileKeys 
{
  private static ClientSelectIntoSQLJ_SJProfileKeys inst = null;
  public static java.lang.Object getKey(int keyNum) 
    throws java.sql.SQLException 
  {
    if (inst == null)
    {
      inst = new ClientSelectIntoSQLJ_SJProfileKeys();
    }
    return inst.keys[keyNum];
  }
  private final sqlj.runtime.profile.Loader loader = sqlj.runtime.RuntimeContext.getRuntime().getLoaderForClass(getClass());
  private java.lang.Object[] keys;
  private ClientSelectIntoSQLJ_SJProfileKeys() 
    throws java.sql.SQLException 
  {
    keys = new java.lang.Object[1];
    keys[0] = sqlj.runtime.ref.DefaultContext.getProfileKey(loader, "ExemplesSQLJ.ClientSelectIntoSQLJ_SJProfile0");
  }
}
