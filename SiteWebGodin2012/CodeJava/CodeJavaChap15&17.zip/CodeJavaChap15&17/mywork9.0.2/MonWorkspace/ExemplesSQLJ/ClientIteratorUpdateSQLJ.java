/*@lineinfo:filename=ClientIteratorUpdateSQLJ*//*@lineinfo:user-code*//*@lineinfo:1^1*///Exemple d'utilisation d'un it�rateur avec mise-�-jour en SQLJ
package ExemplesSQLJ;

import sqlj.runtime.*;
import sqlj.runtime.ref.*;
import java.sql.*;

public class ClientIteratorUpdateSQLJ{
    public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    // Cr�ation du contexte de connexion de d�faut avec autocommit (true)
    DefaultContext unContext = new DefaultContext
          ("jdbc:oracle:thin:@localhost:1521:ora817i", "godin", "oracle", false);
    DefaultContext.setDefaultContext(unContext);

    // D�finition de la classe IteratorClient avec liaison par nom
    /*@lineinfo:generated-code*//*@lineinfo:21^5*/

//  ************************************************************
//  SQLJ iterator declaration:
//  ************************************************************

class IteratorClient 
extends sqlj.runtime.ref.ResultSetIterImpl
implements sqlj.runtime.NamedIterator, sqlj.runtime.ForUpdate
{
  public IteratorClient(sqlj.runtime.profile.RTResultSet resultSet) 
    throws java.sql.SQLException 
  {
    super(resultSet);
    noClientNdx = findColumn("noClient");
    nomClientNdx = findColumn("nomClient");
  }
  public int noClient() 
    throws java.sql.SQLException 
  {
    return resultSet.getIntNoNull(noClientNdx);
  }
  private int noClientNdx;
  public String nomClient() 
    throws java.sql.SQLException 
  {
    return resultSet.getString(nomClientNdx);
  }
  private int nomClientNdx;
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:22^38*/

    // Cr�ation d'un objet it�rateur
    IteratorClient unIteratorClient;

    // Liaison de l'�nonc� SELECT de l'it�rateur
    /*@lineinfo:generated-code*//*@lineinfo:28^5*/

//  ************************************************************
//  #sql unIteratorClient = { SELECT noClient, nomClient, noT�l�phone
//            FROM Client WHERE noClient > 40 };
//  ************************************************************

{
  sqlj.runtime.ConnectionContext __sJT_connCtx = sqlj.runtime.ref.DefaultContext.getDefaultContext();
  if (__sJT_connCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext __sJT_execCtx = __sJT_connCtx.getExecutionContext();
  if (__sJT_execCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_EXEC_CTX();
  synchronized (__sJT_execCtx) {
    sqlj.runtime.profile.RTStatement __sJT_stmt = __sJT_execCtx.registerStatement(__sJT_connCtx, ClientIteratorUpdateSQLJ_SJProfileKeys.getKey(0), 0);
    try 
    {
      sqlj.runtime.profile.RTResultSet __sJT_result = __sJT_execCtx.executeQuery();
      unIteratorClient = new IteratorClient(__sJT_result);
    }
    finally 
    {
      __sJT_execCtx.releaseStatement();
    }
  }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:30^42*/

    // Acc�s au r�sultat du SELECT par it�ration sur les lignes
    while (unIteratorClient.next()){
      if (unIteratorClient.noClient()== 60){
        /*@lineinfo:generated-code*//*@lineinfo:35^9*/

//  ************************************************************
//  #sql { UPDATE Client
//                SET noT�l�phone = '(111)111-1111'
//                WHERE CURRENT of :unIteratorClient };
//  ************************************************************

{
  sqlj.runtime.ConnectionContext __sJT_connCtx = sqlj.runtime.ref.DefaultContext.getDefaultContext();
  if (__sJT_connCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext __sJT_execCtx = __sJT_connCtx.getExecutionContext();
  if (__sJT_execCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_EXEC_CTX();
  IteratorClient __sJT_1 = unIteratorClient;
  synchronized (__sJT_execCtx) {
    sqlj.runtime.profile.RTStatement __sJT_stmt = __sJT_execCtx.registerStatement(__sJT_connCtx, ClientIteratorUpdateSQLJ_SJProfileKeys.getKey(0), 1);
    try 
    {
      __sJT_stmt.setObject(1, __sJT_1);
      __sJT_execCtx.executeUpdate();
    }
    finally 
    {
      __sJT_execCtx.releaseStatement();
    }
  }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:37^49*/
      } else if (unIteratorClient.noClient()== 80){
        /*@lineinfo:generated-code*//*@lineinfo:39^9*/

//  ************************************************************
//  #sql { DELETE FROM Client
//                WHERE CURRENT of :unIteratorClient };
//  ************************************************************

{
  sqlj.runtime.ConnectionContext __sJT_connCtx = sqlj.runtime.ref.DefaultContext.getDefaultContext();
  if (__sJT_connCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext __sJT_execCtx = __sJT_connCtx.getExecutionContext();
  if (__sJT_execCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_EXEC_CTX();
  IteratorClient __sJT_1 = unIteratorClient;
  synchronized (__sJT_execCtx) {
    sqlj.runtime.profile.RTStatement __sJT_stmt = __sJT_execCtx.registerStatement(__sJT_connCtx, ClientIteratorUpdateSQLJ_SJProfileKeys.getKey(0), 2);
    try 
    {
      __sJT_stmt.setObject(1, __sJT_1);
      __sJT_execCtx.executeUpdate();
    }
    finally 
    {
      __sJT_execCtx.releaseStatement();
    }
  }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:40^49*/
      }
      System.out.println("Num�ro du client : " + unIteratorClient.noClient());
      System.out.println("Nom du client : " + unIteratorClient.nomClient());
    }

    // Fermer l'it�rateur
    unIteratorClient.close();
  }
}/*@lineinfo:generated-code*/class ClientIteratorUpdateSQLJ_SJProfileKeys 
{
  private static ClientIteratorUpdateSQLJ_SJProfileKeys inst = null;
  public static java.lang.Object getKey(int keyNum) 
    throws java.sql.SQLException 
  {
    if (inst == null)
    {
      inst = new ClientIteratorUpdateSQLJ_SJProfileKeys();
    }
    return inst.keys[keyNum];
  }
  private final sqlj.runtime.profile.Loader loader = sqlj.runtime.RuntimeContext.getRuntime().getLoaderForClass(getClass());
  private java.lang.Object[] keys;
  private ClientIteratorUpdateSQLJ_SJProfileKeys() 
    throws java.sql.SQLException 
  {
    keys = new java.lang.Object[1];
    keys[0] = sqlj.runtime.ref.DefaultContext.getProfileKey(loader, "ExemplesSQLJ.ClientIteratorUpdateSQLJ_SJProfile0");
  }
}
