/*@lineinfo:filename=ExecuteFunctionSQLJ*//*@lineinfo:user-code*//*@lineinfo:1^1*///Exemple d'appel d'une fonction stock�e avec SQLJ
package ExemplesSQLJ;

import sqlj.runtime.*;
import sqlj.runtime.ref.*;
import java.sql.*;

public class ExecuteFunctionSQLJ{
    public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    // Cr�ation du contexte de connexion de d�faut avec autocommit (true)
    DefaultContext unContexte = new DefaultContext
          ("jdbc:oracle:thin:@localhost:1521:ora817i", "godin", "oracle", true);
    DefaultContext.setDefaultContext(unContexte);

    int laQuantite = 0;
    int noArticle = 10 ;

    // Appel de la fonction stock�e
    /*@lineinfo:generated-code*//*@lineinfo:24^5*/

//  ************************************************************
//  #sql laQuantite = { VALUES (fQuantit�EnStock(:noArticle)) };
//  ************************************************************

{
  sqlj.runtime.ConnectionContext __sJT_connCtx = sqlj.runtime.ref.DefaultContext.getDefaultContext();
  if (__sJT_connCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext __sJT_execCtx = __sJT_connCtx.getExecutionContext();
  if (__sJT_execCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_EXEC_CTX();
  int __sJT_2 = noArticle;
  synchronized (__sJT_execCtx) {
    sqlj.runtime.profile.RTStatement __sJT_stmt = __sJT_execCtx.registerStatement(__sJT_connCtx, ExecuteFunctionSQLJ_SJProfileKeys.getKey(0), 0);
    try 
    {
      __sJT_stmt.setInt(2, __sJT_2);
      __sJT_execCtx.executeUpdate();
      int __sJT_result;
      __sJT_result = __sJT_stmt.getIntNoNull(1);
      laQuantite = __sJT_result;
    }
    finally 
    {
      __sJT_execCtx.releaseStatement();
    }
  }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:24^61*/

    // Fermeture du contexte de connexion
    unContexte.close();
    System.out.println("Quantit� en stock :" + laQuantite);  }
}/*@lineinfo:generated-code*/class ExecuteFunctionSQLJ_SJProfileKeys 
{
  private static ExecuteFunctionSQLJ_SJProfileKeys inst = null;
  public static java.lang.Object getKey(int keyNum) 
    throws java.sql.SQLException 
  {
    if (inst == null)
    {
      inst = new ExecuteFunctionSQLJ_SJProfileKeys();
    }
    return inst.keys[keyNum];
  }
  private final sqlj.runtime.profile.Loader loader = sqlj.runtime.RuntimeContext.getRuntime().getLoaderForClass(getClass());
  private java.lang.Object[] keys;
  private ExecuteFunctionSQLJ_SJProfileKeys() 
    throws java.sql.SQLException 
  {
    keys = new java.lang.Object[1];
    keys[0] = sqlj.runtime.ref.DefaultContext.getProfileKey(loader, "ExemplesSQLJ.ExecuteFunctionSQLJ_SJProfile0");
  }
}
