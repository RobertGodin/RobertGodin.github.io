SET ECHO ON
-- Script Oracle SQL*plus de creation du schema SyLeRat 
-- Les TRIGGER ne sont pas tous implementes

-- Creation des tables
CREATE TABLE Utilisateur
(idUtilisateur 			VARCHAR(10)	NOT NULL,
 motPasse	 			VARCHAR(10)	NOT NULL,
 nom 					VARCHAR(10)	NOT NULL,
 prenom 				VARCHAR(10)	NOT NULL,
 categorieUtilisateur 	VARCHAR(14)  	NOT NULL
 	CHECK(categorieUtilisateur IN ('employe', 'membre')),
 PRIMARY KEY (idUtilisateur)
)
/
CREATE TABLE Employe
(idUtilisateur 			VARCHAR(10)	NOT NULL,
 codeMatricule	 		CHAR(6)	NOT NULL,
 categorieEmploye			VARCHAR(15) NOT NULL 
	CHECK(categorieEmploye IN ('biblothecaire', 'commis')),
 PRIMARY KEY (idUtilisateur),
 UNIQUE (codeMatricule),
 FOREIGN KEY (idUtilisateur) REFERENCES Utilisateur
)
/
CREATE OR REPLACE TRIGGER AIEmployeModifierCategorie
AFTER INSERT ON Employe
REFERENCING
	NEW AS ligneApres
FOR EACH ROW
BEGIN
	UPDATE 	Utilisateur
	SET 		categorieUtilisateur = 'employe'
	WHERE 	idUtilisateur = :ligneApres.idUtilisateur;
END AIEmployeModifierCategorie ;
/
CREATE OR REPLACE TRIGGER BDUEmployeInterdiction
BEFORE DELETE OR UPDATE ON Employe
BEGIN
	raise_application_error(-20200,'DELETE et UPDATE interdit pour Employe');
END BDUEmployeInterdiction;
/
CREATE TABLE Membre
(idUtilisateur 			VARCHAR(10)	NOT NULL,
 telephoneResidence	 	VARCHAR(15)	NOT NULL,
 PRIMARY KEY (idUtilisateur),
 FOREIGN KEY (idUtilisateur) REFERENCES Utilisateur
)
/
CREATE OR REPLACE TRIGGER AIMembreModifierCategorie
AFTER INSERT ON Membre
REFERENCING
	NEW AS ligneApres
FOR EACH ROW
BEGIN
	UPDATE 	Utilisateur
	SET 		categorieUtilisateur = 'membre'
	WHERE 	idUtilisateur = :ligneApres.idUtilisateur;
END AIMembreModifierCategorie ;
/
CREATE OR REPLACE TRIGGER BDUMembreInterdiction
BEFORE DELETE OR UPDATE ON Membre
BEGIN
	raise_application_error(-20201,'DELETE et UPDATE interdit pour Membre');
END BDUMembreInterdiction;
/
CREATE TABLE MembreGeneral
(noSequence 			NUMBER(10)		NOT NULL,
 nbMaxPrets	 			NUMBER(10)		DEFAULT 5 NOT NULL,
 dureeMaxPrets			NUMBER(10)		DEFAULT 7 NOT NULL,
 PRIMARY KEY (noSequence)
)
/
CREATE OR REPLACE TRIGGER BDMembreGeneral
BEFORE DELETE ON MembreGeneral
BEGIN
	raise_application_error(-20201,'DELETE interdit pour MembreGeneral');
END BDMembreGeneral;
/
CREATE OR REPLACE TRIGGER BUMembreGeneral
BEFORE UPDATE OF nbMaxPrets ON MembreGeneral
FOR EACH ROW
WHEN (NEW.nbMaxPrets < OLD.nbMaxPrets)
BEGIN
	raise_application_error(-20212,'Interdit de diminuer nbMaxPrets');
END BUMembreGeneral;
/
CREATE TABLE Editeur
(nomEditeur 			VARCHAR(20)	NOT NULL,
 ville 				VARCHAR(20)	NOT NULL,
 PRIMARY KEY (nomEditeur)
)
/
CREATE TABLE Categorie
(code					VARCHAR(10)	NOT NULL,
 descripteur 			VARCHAR(20)	NOT NULL,
 codeParent				VARCHAR(10),
 PRIMARY KEY (code),
 FOREIGN KEY (codeParent) REFERENCES Categorie
)
/
CREATE TABLE Livre
(ISBN 				CHAR(13)		NOT NULL,
 titre 				VARCHAR(50)		NOT NULL,
 anneeParution 			NUMBER(4)		NOT NULL
CHECK(anneeParution > 0),
 nomEditeur 			VARCHAR(20)	NOT NULL,
 code					VARCHAR(10)	NOT NULL,
 PRIMARY KEY (ISBN),
 FOREIGN KEY (nomEditeur) REFERENCES Editeur
 	DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY (code) REFERENCES Categorie
)
/
CREATE OR REPLACE TRIGGER BDULivreInterdiction
BEFORE DELETE OR UPDATE ON Livre
BEGIN
	raise_application_error(-20202,'DELETE et UPDATE interdit pour Livre');
END BDULivreInterdiction;
/
CREATE TABLE Exemplaire
(idExemplaire 			VARCHAR(10)		NOT NULL,
 dateAchat 				DATE			NOT NULL,
 statut 				VARCHAR(15)		NOT NULL
	CHECK(statut IN ('prete', 'disponible','retire')),
 ISBN 				CHAR(13)		NOT NULL,
 PRIMARY KEY (idExemplaire),
 FOREIGN KEY (ISBN) REFERENCES Livre
)
/
CREATE OR REPLACE TRIGGER BIEditeurAuMoinsUnLivre
BEFORE INSERT ON Editeur
FOR EACH ROW
DECLARE
	nbEditeur 		INTEGER;
	editeurSansLivre 	EXCEPTION;
BEGIN
	SELECT COUNT(*) INTO nbEditeur FROM Livre
	WHERE nomEditeur = :NEW.nomEditeur;
	IF nbEditeur = 0 THEN
		RAISE editeurSansLivre;
	END IF;
EXCEPTION
	WHEN editeurSansLivre THEN
		raise_application_error(-20110,'l''editeur doit avoir au moins un livre');
	WHEN	OTHERS THEN
		raise_application_error(-20105,'erreur interne');
END BIEditeurAuMoinsUnLivre;
/
CREATE TABLE PretEnCours
(idExemplaire 			VARCHAR(10)	NOT NULL,
 datePret 				DATE	DEFAULT SYSDATE NOT NULL,
 idUtilisateur 			VARCHAR(10)	NOT NULL,
 PRIMARY KEY (idExemplaire),
 FOREIGN KEY (idUtilisateur) REFERENCES Utilisateur,
 FOREIGN KEY (idExemplaire) REFERENCES Exemplaire
)
/
CREATE OR REPLACE TRIGGER BIPretEnCoursVerifier
 BEFORE INSERT ON PretEnCours
 FOR EACH ROW
DECLARE
	statutExemplaire 		Exemplaire.statut%TYPE;
	idUtilisateurMembre	Membre.idUtilisateur%TYPE;
	datePret			PretEnCours.datePret%TYPE;
	nombrePretsEnCours 	INTEGER;
	nombreMaximalPrets 	INTEGER;
	dureeMaximalePrets 	INTEGER;
	exemplaireNonDisponible EXCEPTION;
	nombreMaximalAtteint 	EXCEPTION;
	pretEnRetard 		EXCEPTION;
	-- Curseur pour verifier si membre
	CURSOR leMembre(unIdUtilisateur PretEnCours.idUtilisateur%TYPE)IS
		SELECT idUtilisateur
		FROM Membre WHERE idUtilisateur = unIdUtilisateur;
	-- Curseur (CURSOR) PL/SQL pour iterer sur les prets
	CURSOR lignesPrets(unIdUtilisateur PretEnCours.idUtilisateur%TYPE)IS
    		SELECT 	datePret
    		FROM		PretEnCours
    		WHERE 	idUtilisateur = unIdUtilisateur;
BEGIN
	--  Verifier si statut de l'exemplaire = disponible
	SELECT 	statut
	INTO 		statutExemplaire
	FROM 		Exemplaire
	WHERE 	idExemplaire = :NEW.idExemplaire
	FOR UPDATE; /* pour serialisabilite*/
	IF statutExemplaire <> 'disponible' THEN
		RAISE exemplaireNonDisponible;
	END IF;
	-- Verifier si l'emprunteur est un membre
	OPEN leMembre(:NEW.idUtilisateur);
	FETCH leMembre INTO idUtilisateurMembre;
	IF leMembre%FOUND THEN
	-- Verifier si le nombre maximal d'emprunts est atteint ou si un retard existe
		SELECT	nbMaxPrets, dureeMaxPrets
		INTO		nombreMaximalPrets, dureeMaximalePrets
		FROM		MembreGeneral;
		LOCK TABLE PretEnCours IN SHARE ROW EXCLUSIVE MODE;
		nombrePretsEnCours := 0;
		OPEN lignesPrets(:NEW.idUtilisateur);
		LOOP
			FETCH lignesPrets INTO datePret;
			EXIT WHEN lignesPrets%NOTFOUND;
			IF (SYSDATE-datePret > dureeMaximalePrets) THEN
				RAISE pretEnRetard;
			END IF;
			nombrePretsEnCours := nombrePretsEnCours + 1;
		END LOOP;
		CLOSE lignesPrets;
		IF nombrePretsEnCours >= nombreMaximalPrets THEN
			RAISE nombreMaximalAtteint;
		END IF;
	END IF;
	CLOSE leMembre;
EXCEPTION
	WHEN exemplaireNonDisponible THEN
		raise_application_error(-20103,'l''exemplaire n''a pas le statut disponible');
	WHEN nombreMaximalAtteint THEN
		raise_application_error(-20101,'le nombre maximal d''emprunts est atteint');
	WHEN pretEnRetard THEN
		raise_application_error(-20104,'emprunt interdit � cause de retard');
	WHEN	OTHERS THEN
		raise_application_error(-20105,'erreur interne');
END BIPretEnCoursVerifier;
/
CREATE OR REPLACE TRIGGER BUPretEnCours
BEFORE UPDATE ON PretEnCours
BEGIN
	raise_application_error(-20203,'UPDATE interdit pour PretEnCours');
END BUPretEnCours;
/
CREATE OR REPLACE TRIGGER AIPretEnCoursModifStatutEx
AFTER INSERT ON PretEnCours
REFERENCING
	NEW AS ligneApres
FOR EACH ROW
BEGIN
	UPDATE 	Exemplaire
	SET 		statut = 'prete'
	WHERE 	idExemplaire = :ligneApres.idExemplaire;
END AIPretEnCoursModifStatutEx;
/
-- On utilise le mecanisme de SEQUENCE Oracle pour generer les valeurs de
-- la cle primaire noSequence de la table PretArchive
CREATE SEQUENCE SequenceNoPretArchive
/
CREATE TABLE PretArchive
(noSequence				NUMBER(10)		NOT NULL,
 datePret 				DATE			NOT NULL,
 dateRetour 			DATE			NOT NULL,
 idUtilisateur 			VARCHAR(10)		NOT NULL,
 idExemplaire 			VARCHAR(10)		NOT NULL,
 PRIMARY KEY (noSequence),
 FOREIGN KEY (idUtilisateur) REFERENCES Utilisateur,
 FOREIGN KEY (idExemplaire) REFERENCES Exemplaire,
 CHECK (dateRetour >= datePret)
)
/
CREATE OR REPLACE TRIGGER ADPretEnCours
AFTER DELETE ON PretEnCours
FOR EACH ROW
BEGIN
 	UPDATE 	Exemplaire
 	SET 		statut = 'disponible'
 	WHERE 	idExemplaire = :OLD.idExemplaire;

 	INSERT INTO PretArchive VALUES
 		(SequenceNoPretArchive.NEXTVAL, :OLD.datePret, SYSDATE,
		:OLD.idUtilisateur,:OLD.idExemplaire);
	-- SequenceNoPretArchive.NEXTVAL retourne la prochaine valeur de la SEQUENCE
END ADPretEnCours;
/

CREATE TABLE Auteur
(noSequence				NUMBER(10)		NOT NULL,
 nom	 				VARCHAR(20)		NOT NULL,
 prenom 				VARCHAR(20)		NOT NULL,
 PRIMARY KEY (noSequence)
)
/
CREATE TABLE AuteurLivre
(noSequence				NUMBER(10)		NOT NULL,
 ISBN 				CHAR(13)		NOT NULL,
 ordreAuteur 			NUMBER(10)		NOT NULL,
 PRIMARY KEY (noSequence, ISBN),
 UNIQUE (ISBN, ordreAuteur),
 FOREIGN KEY (noSequence) REFERENCES Auteur,
 FOREIGN KEY (ISBN) REFERENCES Livre
)
/
PROMPT Quelques exemples de manipulations de donnees
ALTER SESSION SET NLS_DATE_FORMAT = 'DD-MON-YYYY'
/
ALTER SESSION SET NLS_DATE_LANGUAGE = ENGLISH
/

INSERT INTO Categorie VALUES('10','Sciences',NULL)
/
INSERT INTO Categorie VALUES('20','Philosophie',NULL)
/
INSERT INTO Categorie VALUES('30','Histoire', NULL)
/
INSERT INTO Categorie VALUES('40','Arts', NULL)
/
INSERT INTO Categorie VALUES('50','Litterature', NULL) 
/
INSERT INTO Categorie VALUES('101','Informatique','10')
/
INSERT INTO Categorie VALUES('102','Mathematiques','10')
/
INSERT INTO Categorie VALUES('103','Chimie','10')
/
INSERT INTO Categorie VALUES('501','Roman','50') 
/
INSERT INTO Categorie VALUES('502','Poesie','50')
/
COMMIT
/
SELECT * FROM Categorie
/

INSERT INTO Auteur VALUES(1,'Knuth','Donald') 
/
INSERT INTO Auteur VALUES(2,'Salton','Gerard') 
/
INSERT INTO Auteur VALUES(3,'Blaha','Michael') 
/
INSERT INTO Auteur VALUES(4,'Premerlani','Henry F.') 
/
INSERT INTO Auteur VALUES(5,'Hofstadter','Douglas,R.')
/
COMMIT
/
SELECT * FROM Auteur
/

INSERT INTO Livre VALUES('3-333-3333333', 'The Art of Computer Programming',1973, 'Addison Wesley', '101') 
/
INSERT INTO Livre VALUES('0-201-12227-8','Automatic Text Processing',1989, 'Addison Wesley', '101') 
/
INSERT INTO Livre VALUES('0-13-123829-9','Object-Oriented Modeling and Design for DB App.',1998, 'Prentice Hall', '101') 
/
INSERT INTO Livre VALUES('0-394-74502-7', 'G�del, Escher, Bach : An Eternal Golden Braid', 1980, 'Random House', '20')
/
SELECT * FROM Livre
/

INSERT INTO Editeur VALUES ('Addison Wesley', 'Reading,MA')
/
INSERT INTO Editeur VALUES ('Prentice Hall', 'U.Sad.Riv.')
/
INSERT INTO Editeur VALUES ('Random House', 'NewYork,NY')
/
COMMIT
/
SELECT * FROM Editeur
/

INSERT INTO AuteurLivre VALUES(1, '3-333-3333333', 1)
/
INSERT INTO AuteurLivre VALUES(2, '0-201-12227-8', 1)
/
INSERT INTO AuteurLivre VALUES(3, '0-13-123829-9', 1)
/
INSERT INTO AuteurLivre VALUES(4, '0-13-123829-9', 2)
/
INSERT INTO AuteurLivre VALUES(5, '0-394-74502-7', 1)
/
COMMIT
/

INSERT INTO Exemplaire VALUES(1, '10-dec-1975', 'disponible','3-333-3333333')
/
INSERT INTO Exemplaire VALUES(2, '10-dec-1975', 'disponible','3-333-3333333')
/
INSERT INTO Exemplaire VALUES(3, '15-jan-1990', 'disponible','0-201-12227-8')
/
INSERT INTO Exemplaire VALUES(4, '20-mar-1999', 'disponible', '0-13-123829-9')
/
INSERT INTO Exemplaire VALUES(5, '22-mar-1999', 'disponible', '0-13-123829-9')
/
INSERT INTO Exemplaire VALUES(6, '12-sep-1982', 'disponible', '0-394-74502-7')
/
COMMIT
/
SELECT * FROM Exemplaire;
/

INSERT INTO MembreGeneral VALUES(1, 2, 7)
/
COMMIT
/
SELECT * FROM MembreGeneral
/

INSERT INTO Utilisateur VALUES(1,'cocorico','Marshal', 'Amanda', 'membre')
/
INSERT INTO Membre VALUES(1,'(111)111-1111')
/

INSERT INTO Utilisateur VALUES(2,'cocorico','Degas', 'Edgar', 'membre')
/
INSERT INTO Membre VALUES(2,'(222)222-2222')
/

INSERT INTO Utilisateur VALUES(3,'cocorico','Lecommis', 'Coco', 'employe')
/
INSERT INTO Employe VALUES(3,'LECC01','commis')
/
INSERT INTO Utilisateur VALUES(4,'cocorico','Lecommis', 'Toto', 'employe')
/
INSERT INTO Employe VALUES(4,'LECT01','commis')
/
SELECT * FROM Utilisateur
/
COMMIT
/

PROMPT Editeur sans Livre
INSERT INTO Editeur VALUES ('Eyrolles','Paris')
/
PROMPT Pret correct
INSERT INTO PretEnCours VALUES(1,'20-jul-1999',1)
/
PROMPT cas de retard
INSERT INTO PretEnCours VALUES(3,'30-jul-1999',1)
/
PROMPT cas non disponible
INSERT INTO PretEnCours VALUES(1,'30-jul-1999',2)
/
DELETE FROM PretEnCours WHERE idExemplaire = 1
/
SELECT * FROM PretEnCours
/
SELECT * FROM PretArchive
/
PROMPT defaut pour la date de pret
INSERT INTO PretEnCours(idExemplaire, idUtilisateur) VALUES(1,1)
/
INSERT INTO PretEnCours(idExemplaire, idUtilisateur) VALUES(3,1)
/
PROMPT cas de maximum atteint (2 dans cet essai)
INSERT INTO PretEnCours(idExemplaire, idUtilisateur) VALUES(5,1)
/
SELECT * FROM PretEnCours
/
PROMPT maximum depasse pour Commis
INSERT INTO PretEnCours(idExemplaire, idUtilisateur) VALUES(2,3)
/
INSERT INTO PretEnCours(idExemplaire, idUtilisateur) VALUES(4,3)
/
INSERT INTO PretEnCours(idExemplaire, idUtilisateur) VALUES(5,3)
/

