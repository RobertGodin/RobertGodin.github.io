package GererPretSA;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import GererPretSA.FacadeEnrPretSimpleSessionEJB;
import GererPretSA.FacadeEnrPretSimpleSessionEJBHome;
import javax.naming.NamingException;

public class FacadeEnrPretSimpleSessionEJBClient 
{
  public static void main(String [] args)
  {
    FacadeEnrPretSimpleSessionEJBClient facadeEnrPretSimpleSessionEJBClient = new FacadeEnrPretSimpleSessionEJBClient();
    try
    {
      Context context = getInitialContext();
      FacadeEnrPretSimpleSessionEJBHome facadeEnrPretSimpleSessionEJBHome = (FacadeEnrPretSimpleSessionEJBHome)PortableRemoteObject.narrow(context.lookup("FacadeEnrPretSimpleSessionEJB"), FacadeEnrPretSimpleSessionEJBHome.class);
      FacadeEnrPretSimpleSessionEJB facadeEnrPretSimpleSessionEJB;

      // Use one of the create() methods below to create a new instance
      facadeEnrPretSimpleSessionEJB = facadeEnrPretSimpleSessionEJBHome.create();

      // Call any of the Remote methods below to access the EJB
      // facadeEnrPretSimpleSessionEJB.insererPretEnCours( java.lang.String idUtilisateur, java.lang.String idExemplaire );

    }
    catch(Throwable ex)
    {
      ex.printStackTrace();
    }

  }

  private static Context getInitialContext() throws NamingException
  {
    // Get InitialContext for Embedded OC4J.
    // The embedded server must be running for lookups to succeed.
    return new InitialContext();
  }
}