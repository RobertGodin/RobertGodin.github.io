// Exemple de programme JAVA qui utilise le pilote JDBC thin d'Oracle
// pour effectuer un SELECT et it�rer sur les lignes du r�sultat

// Il faut importer le paquetage java.sql pour utiliser JDBC
package ExemplesJDBC;
import java.sql.*;
import java.math.BigDecimal;

class ExempleSelectCompte
{
  public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    Class.forName ("oracle.jdbc.driver.OracleDriver");

    // Connection � une BD avec un pilote thin
    Connection uneConnection =
      DriverManager.getConnection ("jdbc:oracle:thin:@127.0.0.1:1521:orcl", "idutil1", "oracle");

    // Cr�ation d'un �nonc� associ� � la Connection
    Statement unEnonc�SQL = uneConnection.createStatement ();

    // Ex�cution d'un SELECT
    // Le code du SELECT est pass� en param�tre sous forme d'un String
    ResultSet r�sultatSelect = unEnonc�SQL.executeQuery
      ("SELECT noCompte, solde FROM Compte WHERE noClient = 10");

    // It�rer sur les lignes du r�sultat du SELECT et extraire les valeurs
    // des colonnes dans des variables JAVA   
    while (r�sultatSelect.next ()){
      int noCompte = r�sultatSelect.getInt ("noCompte");
      BigDecimal solde = r�sultatSelect.getBigDecimal ("solde");

      System.out.println ("Num�ro du compte:" + noCompte);
      System.out.println ("Solde:" + solde);
    }
        // Fermeture de l'�nonc� et de la connexion
    unEnonc�SQL.close();
    uneConnection.close();
  }
}