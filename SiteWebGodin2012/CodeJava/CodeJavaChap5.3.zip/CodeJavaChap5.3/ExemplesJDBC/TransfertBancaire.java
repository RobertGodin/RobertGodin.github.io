package ExemplesJDBC;
import java.sql.*;
import java.util.*;
import java.math.*;
import javax.swing.JOptionPane;

public class TransfertBancaire 
{
  public static void main (String args []) throws Exception
  {
    String stringCompte1 = 
      JOptionPane.showInputDialog("Entrez le num�ro du compte � vider :");
    int noCompte1 = Integer.parseInt(stringCompte1);
    String stringCompte2 = 
      JOptionPane.showInputDialog("Entrez le num�ro du compte � cr�diter  :");
    int noCompte2 = Integer.parseInt(stringCompte2);

    Class.forName ("oracle.jdbc.driver.OracleDriver");
    Connection uneConnection = DriverManager.getConnection
      ("jdbc:oracle:thin:@localhost:1521:orcl", "idutil1", "oracle");
    uneConnection.setAutoCommit(false);

    // Afficher le solde du compte 1
    PreparedStatement unPreparedStatement= uneConnection.prepareStatement
      ("SELECT solde FROM Compte WHERE noCompte = ? FOR UPDATE ");
    unPreparedStatement.setInt(1,noCompte1);  
    ResultSet r�sultatSelect = unPreparedStatement.executeQuery();
    BigDecimal leSolde;
    if (r�sultatSelect.next ()){
      leSolde = r�sultatSelect.getBigDecimal("solde");
      System.out.println("solde du compte � vider :"+leSolde);
    } else throw new Exception("pas de compte");
    
    // Vide compte1
    unPreparedStatement= uneConnection.prepareStatement
      ("UPDATE Compte SET solde = 0 WHERE noCompte = ?");
    unPreparedStatement.setInt(1,noCompte1);  
    int n = unPreparedStatement.executeUpdate();

    // Transfert dans le compte2
    unPreparedStatement = uneConnection.prepareStatement
      ("UPDATE Compte SET solde = solde + ? WHERE noCompte = ?");
    unPreparedStatement.setBigDecimal(1,leSolde);
    unPreparedStatement.setInt(2,noCompte2);
    n = unPreparedStatement.executeUpdate();

    uneConnection.commit();    
    unPreparedStatement.close();
    uneConnection.close();
    System.exit(0);
  }
}
