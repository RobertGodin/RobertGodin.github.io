package ExemplesJDBC;
// Exemple d'extraction d'un BLOB Oracle avec java.sql.Blob (JDBC 2) et
// cr�ation d'un fichier contenant une copie du Blob
import java.sql.*;
import java.io.*;

class JDBCSelectGetBlob
{
    public static void main (String args [])
    throws Exception
    {
        Class.forName ("oracle.jdbc.driver.OracleDriver");
        Connection uneConnection =
        DriverManager.getConnection ("jdbc:oracle:thin:@127.0.0.1:1521:orcl", "godin", "oracle");
        Statement unEnonc�SQL = uneConnection.createStatement ();

        // Chercher le BLOB locator
        ResultSet unResultSet = unEnonc�SQL.executeQuery ("SELECT *  FROM tableBlob WHERE idBlob = 1");
        if (unResultSet.next()){

            int idBlob = unResultSet.getInt(1);
            Blob unBlob = unResultSet.getBlob(2);

            // Chercher la taille du BLOB et l'afficher
            int taille = (int)unBlob.length();
            System.out.println("Taille du BLOB" + taille);

            // Lire le BLOB dans un tableau d'octets
            byte octets[] = unBlob.getBytes(1, taille);

            // Cr�er un fichier contenant les octets lus
            FileOutputStream unFichier = new FileOutputStream("C:/forte4j/Development/ExemplesJDBC/CopieCoq1.gif");
            unFichier.write(octets);
            unFichier.close();

            unEnonc�SQL.close();
            uneConnection.close();
        }else{throw new Exception("R�sultat de SELECT vide");}
    }
}