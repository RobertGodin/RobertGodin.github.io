// Exemples de positionnements dans un ResultSet JDBC 2

package ExemplesJDBC;
import java.sql.*;

class ResultSetScrollable
{
    public static void main (String args [])
    throws SQLException, ClassNotFoundException, java.io.IOException
    {
        // Charger le pilote JDBC d'Oracle
        Class.forName ("oracle.jdbc.driver.OracleDriver");

        // Connexion � une BD
        Connection uneConnection =
        DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:orcl", "godin", "oracle");

        // Cr�ation d'un �nonc� avec ResultSet d�filable (srollable)
        Statement unEnonc�SQL =
        uneConnection.createStatement(
            ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

        // Ex�cution d'un SELECT
        ResultSet r�sultatSelect = unEnonc�SQL.executeQuery
        ("SELECT noClient, nomClient FROM CLIENT");

        // Affichage des lignes du ResultSet
        int noClient;
        String nomClient;
        System.out.println("Liste des clients");
        System.out.println("Position\tNoClient\tNomClient");
        int position = 1;
        while (r�sultatSelect.next ()){
            noClient = r�sultatSelect.getInt ("noClient");
            nomClient = r�sultatSelect.getString ("nomClient");
            System.out.println(position+"\t"+noClient+"\t"+nomClient);
            position++;
        }
        
        // Exemples de positionnement de curseur (scrollable)
        //Positionnement � la premi�re ligne du ResultSet
        r�sultatSelect.first();
        System.out.println("Premier client :");
        noClient = r�sultatSelect.getInt ("noClient");
        nomClient = r�sultatSelect.getString ("nomClient");
        System.out.println(noClient+"\t"+nomClient);
        
        // Positionnement � la derni�re ligne du ResultSet
        r�sultatSelect.last();
        System.out.println("Dernier client :");
        noClient = r�sultatSelect.getInt ("noClient");
        nomClient = r�sultatSelect.getString ("nomClient");
        System.out.println(noClient+"\t"+nomClient);

        // Positionnement � la troisi�me ligne
        r�sultatSelect.absolute(3);
        System.out.println("3ieme client :");
        noClient = r�sultatSelect.getInt ("noClient");
        nomClient = r�sultatSelect.getString ("nomClient");
        System.out.println(noClient+"\t"+nomClient);
        
        // Positionnement relatif (avancer de 2 lignes)
        r�sultatSelect.relative(2);
        System.out.println("Avancer de deux :");
        noClient = r�sultatSelect.getInt ("noClient");
        nomClient = r�sultatSelect.getString ("nomClient");
        System.out.println(noClient+"\t"+nomClient);

        // Positionnement � la ligne pr�c�dente
        r�sultatSelect.previous();
        System.out.println("Client pr�c�dent :");
        noClient = r�sultatSelect.getInt ("noClient");
        nomClient = r�sultatSelect.getString ("nomClient");
        System.out.println(noClient+"\t"+nomClient);

        // Fermeture de l'�nonc� et de la connexion
        unEnonc�SQL.close();
        uneConnection.close();
    }
}