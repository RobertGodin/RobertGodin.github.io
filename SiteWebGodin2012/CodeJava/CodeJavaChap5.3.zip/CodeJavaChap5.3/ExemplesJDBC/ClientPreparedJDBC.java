// Exemple de programme JAVA qui utilise le pilote JDBC OCI8 d'Oracle
// pour effectuer un SELECT et it�rer sur les lignes du r�sultat
// Utilisation de PreparedStatement
// Il faut importer le paquetage java.sql pour utiliser JDBC
package ExemplesJDBC;
import java.sql.*;

class ClientPreparedJDBC
{
  public static void main (String args [])
       throws SQLException, java.io.IOException
  {
    // Charger le pilote JDBC d'Oracle
    try
      {Class.forName ("oracle.jdbc.driver.OracleDriver");
      }
    catch(ClassNotFoundException e)
      {System.err.println(" ClassNotFoundException:" + e.getMessage());
      }

    // Connection � une BD
    Connection uneConnection =
      DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:orcl", "godin", "oracle");

    // Compilation de l'�nonc� SQL param�tris� avec PreparedStatement
    PreparedStatement unEnonc�SQL = uneConnection.prepareStatement
      ("SELECT noClient, nomClient "+
       "FROM CLIENT " +
       "WHERE noClient > ?");

    // Sp�cification du param�tre
    unEnonc�SQL.setInt(1,40);

    // Ex�cution du SELECT
    ResultSet r�sultatSelect = unEnonc�SQL.executeQuery();
    
    // It�rer sur les lignes du r�sultat du SELECT et extraire les valeurs
    // des colonnes dans des variables JAVA
    
    while (r�sultatSelect.next ()){
      int noClient = r�sultatSelect.getInt ("noClient");
      String nomClient = r�sultatSelect.getString ("nomClient");

      System.out.println ("Num�ro du client:" + noClient);
      System.out.println ("Nom du client:" + nomClient);
    }
    unEnonc�SQL.close();
    uneConnection.close();
  }
}

