package ExemplesJDBC;
// Exemple d'ex�cution d'une proc�dure PL/SQL stock�e avec CallableStatement
import java.sql.*;

class ExecuteProcedure
{
  public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    Class.forName ("oracle.jdbc.driver.OracleDriver");
    Connection uneConnection =
      DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:orcl", "godin", "oracle");

    // Cr�ation d'un appel de fonction associ� � la Connection
    CallableStatement unCall = uneConnection.prepareCall("{call pModifierQuantit�EnStock(?,?)}");

    // Sp�cification des param�tres d'entr�e
    unCall.setInt(1,10);
    unCall.setInt(2,20);
    // Ex�cution de l'appel
    unCall.execute();
    unCall.close();
    uneConnection.close();
    }
}