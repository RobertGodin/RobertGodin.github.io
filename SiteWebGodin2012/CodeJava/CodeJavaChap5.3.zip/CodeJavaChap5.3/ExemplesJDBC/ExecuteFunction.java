package ExemplesJDBC;
// Exemple d'ex�cution d'une fonction PL/SQL stock�e avec CallableStatement
import java.sql.*;

class ExecuteFunction
{
  public static void main (String args [])
       throws SQLException, ClassNotFoundException, java.io.IOException
  {
    Class.forName ("oracle.jdbc.driver.OracleDriver");
    Connection uneConnection =
      DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:orcl", "godin", "oracle");

    // Cr�ation d'un appel de fonction associ� � la Connection
    CallableStatement unCall = uneConnection.prepareCall("{ ? = call fQuantit�EnStock(?)}");

    // Sp�cification du param�tre d'entr�e
    unCall.setInt(2,10);
    // Inscription de la sortie
    unCall.registerOutParameter(1, java.sql.Types.INTEGER);
    // Ex�cution de l'appel
    unCall.execute();
    // R�cup�ration de la sortie
    int laQuantite = unCall.getInt(1);
    
    System.out.println("Quantit� en stock :"+laQuantite);
    unCall.close();
    uneConnection.close();
    }
}