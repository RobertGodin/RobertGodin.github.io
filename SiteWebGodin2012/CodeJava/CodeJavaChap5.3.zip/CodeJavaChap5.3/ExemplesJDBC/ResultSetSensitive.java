// Effets des mises-�-jour dans un ResultSet sensitive JDBC 2

package ExemplesJDBC;
import java.sql.*;

class ResultSetSensitive
{
    public static void main (String args [])
    throws SQLException, ClassNotFoundException, java.io.IOException
    {
        // Charger le pilote JDBC d'Oracle
        Class.forName ("oracle.jdbc.driver.OracleDriver");

        // Connexion � une BD
        Connection uneConnection =
        DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:orcl", "godin", "oracle");

        // Cr�ation d'un �nonc� avec ResultSet d�filable (srollable)
        Statement unEnonc�SQL =
        uneConnection.createStatement(
            ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);

        // Ex�cution d'un SELECT
        ResultSet r�sultatSelect = unEnonc�SQL.executeQuery
        ("SELECT noClient, nomClient, noT�l�phone FROM CLIENT");
        
        // Affichage des lignes du ResultSet
        int noClient;
        String nomClient;
        String noT�l�phone;
        System.out.println("ResultSet avant mise-�-jour");
        System.out.println("Position\tNoClient\tNomClient\tNoT�l�phone");
        int position = 1;
        while (r�sultatSelect.next ()){
            noClient = r�sultatSelect.getInt ("noClient");
            nomClient = r�sultatSelect.getString ("nomClient");
            noT�l�phone = r�sultatSelect.getString ("noT�l�phone");
            System.out.println(position+"\t"+noClient+"\t"+nomClient+"\t"+noT�l�phone);
            position++;
        }
  
        // Exemples de mises-�-jour par ResultSet updatable
        
        //Positionnement � la premi�re ligne du ResultSet
        r�sultatSelect.first();
        // Mise-�-jour de la colonne noT�l�phone de la ligne courante
        r�sultatSelect.updateString("noT�l�phone","(111)111-1111");
        // Effectuer le UPDATE
        r�sultatSelect.updateRow();
                
        // Positionnement � la derni�re ligne de la table
        r�sultatSelect.last();
        // Supprimer la ligne courante
        r�sultatSelect.deleteRow();
        
        // Insertion d'une nouvelle ligne
        r�sultatSelect.moveToInsertRow();
        r�sultatSelect.updateInt("noClient", 100);
        r�sultatSelect.updateString("nomClient", "G. Lemoyne-Allaire");
        r�sultatSelect.updateString("noT�l�phone", "911");
        r�sultatSelect.insertRow();
        
        
        DatabaseMetaData unDBMD = uneConnection.getMetaData();
        if (unDBMD.othersUpdatesAreVisible(ResultSet.TYPE_SCROLL_SENSITIVE)){
            System.out.println("Les UPDATE des autres sont visibles");
        }
        if (unDBMD.othersDeletesAreVisible(ResultSet.TYPE_SCROLL_SENSITIVE)){
            System.out.println("Les DELETE des autres sont visibles");
        }
        if (unDBMD.othersInsertsAreVisible(ResultSet.TYPE_SCROLL_SENSITIVE)){
            System.out.println("Les INSERT des autres sont visibles");
        }
        if (unDBMD.ownUpdatesAreVisible(ResultSet.TYPE_SCROLL_SENSITIVE)){
            System.out.println("Les UPDATE du ResultSet sont visibles");
        }
        if (unDBMD.ownDeletesAreVisible(ResultSet.TYPE_SCROLL_SENSITIVE)){
            System.out.println("Les DELETE du ResultSet sont visibles");
        }
        if (unDBMD.ownInsertsAreVisible(ResultSet.TYPE_SCROLL_SENSITIVE)){
            System.out.println("Les INSERT du ResultSet sont visibles");
        }
        
        System.out.println("ResultSet apr�s mise-�-jour");
        System.out.println("Position\tNoClient\tNomClient\tNoT�l�phone");
        position = 1;
        r�sultatSelect.beforeFirst();
        while (r�sultatSelect.next ()){
            noClient = r�sultatSelect.getInt ("noClient");
            nomClient = r�sultatSelect.getString ("nomClient");
            noT�l�phone = r�sultatSelect.getString ("noT�l�phone");
            System.out.println(position+"\t"+noClient+"\t"+nomClient+"\t"+noT�l�phone);
            position++;
        }

        // Fermeture de l'�nonc� et de la connexion
        unEnonc�SQL.close();
        uneConnection.close();
    }
}